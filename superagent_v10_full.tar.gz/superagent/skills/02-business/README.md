# 02-business — Business & Monetization

Turn output into revenue: pricing, monetization engines, client revenue pipelines.

**3 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`auto-monetization`](auto-monetization.md) | Autonomous Monetization Engine | monetize otomatis, auto revenue, passive income, auto jual, auto prici… |
| [`client-revenue`](client-revenue.md) | Client Revenue Engine | client revenue, garapan, harvest, scrape API, anti-browser, parse curl… |
| [`monetization`](monetization.md) | Value Generation & Monetization | monetize, pricing, jual, cuan, business, income, funnel… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).
