# 05-engineering — Engineering & Data

Build software and move data: coding, data insight, API integration, batch ops, MCP, compliance/CI-CD.

**6 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`api-integration`](api-integration.md) | Protocol Binding & Service Bridge | API, REST, webhook, midtrans, integrasi, endpoint, SDK, integration… |
| [`batch-parallel`](batch-parallel.md) | Batch / Parallel Operations | batch, parallel, bulk, mass, queue, worker, concurrent, throughput… |
| [`data-insight`](data-insight.md) | Data Transformation & Insight | spreadsheet, excel, csv, dataset, snapshot, data, analytics, report, l… |
| [`power-planner-swarm`](power-planner-swarm.md) | Power Pack: Planner/Swarm/Automation | rencanain, workflow, otomatis kalau, backtest, dashboard, swarm, voice… |
| [`product-spec`](product-spec.md) | Product & Spec Workflows | PRD, to-issues, grill me, spec, user story, TDD, product requirement, … |
| [`software-engineering`](software-engineering.md) | Software Engineering & Coding | coding, bikin app, backend, API, database, testing, fastapi, express, … |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).
