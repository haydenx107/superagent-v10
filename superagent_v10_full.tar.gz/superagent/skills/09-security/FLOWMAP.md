# 🗺️ FLOWMAP — the interconnected flow graph

Every node below is a real file. Every arrow is a documented handoff. Nothing is a dead end: each step names where its output goes next. Read this to understand how the whole pack moves as one machine.

## Master loop (autonomous, 24/7)

```
╔═══════════════════════════════ AUTONOMY ENGINE (autonomy/) ═══════════════════════════════╗
║                                                                                            ║
║  ┌────────────────┐   ┌────────────────┐   ┌─────────────────┐                             ║
║  │ 00 DISCOVERY   │──▶│ 01 QUALIFIER   │──▶│ 02 AUTH-GATE    │── fail ──▶ drop + log       ║
║  │ find fields    │   │ score & filter │   │ legal checkpoint│                             ║
║  │ on the internet│   │                │   │                 │                             ║
║  └────────────────┘   └────────────────┘   └───────┬─────────┘                             ║
║        ▲                                            │ pass                                 ║
║        │                                            ▼                                       ║
║        │                                   ╔════════════════════ ENGAGEMENT (phases/) ════╗ ║
║        │                                   ║ 00 scope → 01 recon → 02 surface → 03 hunt  ║ ║
║        │                                   ║   → 04 chain → 05 exploit → 06 triage        ║ ║
║        │                                   ║   → 07 report → 08 retest → 09 disclose      ║ ║
║        │                                   ╚═════════════════════════════╦════════════════╝ ║
║        │                                                                 ▼                  ║
║  ┌─────┴──────────┐   ┌────────────────┐                        ┌────────────────┐          ║
║  │ 04 MEMORY +    │◀──│ 10 LEARN       │◀───────────────────────│ outcomes       │          ║
║  │    DEDUPE      │   │ extract patterns│                        │ (ledger)       │          ║
║  └────────────────┘   └────────────────┘                        └────────────────┘          ║
║        │  feeds next discovery cycle (priority, exclusions, learned signals)                ║
║        └───────────────────────────────────────────────────────────────────────────────────╝
║                                                                                            ║
║  05 SAFETY-KILLSWITCH wraps EVERYTHING: rate caps · scope fence · abort · human-confirm     ║
╚════════════════════════════════════════════════════════════════════════════════════════════╝
```

## Phase chain (the engagement timeline, phases/)

```
00-scope ─▶ 01-recon ─▶ 02-surface ─▶ 03-hunt ─▶ 04-chain ─▶ 05-exploit
   │           │            │            │           │            │
 which      inventory    prioritize   per-class    escalate    safe PoC
 assets     of attack    hunt plan    discovery    impact
   ▼           ▼            ▼            ▼           ▼            ▼
 scope-     recon/*      references/   skills/*    _core/      exploit-dev/*
 guard                   severity                  chaining

03-hunt ─▶ 06-triage ─▶ 07-report ─▶ 08-retest ─▶ 09-disclose ─▶ (loop to 01 or autonomy/00)
             │             │            │             │
          validate      writeup      verify fix    coordinated
          (7-gate)      template                   disclosure
```

## Skill routing (which signal → which skill)

See `references/bug-class-matrix.md` for the full "signal → class → skill" table. Phase `03-hunt` consumes it to pick skills; `04-chain` uses `core/chaining.md` to connect findings.

## Handoff contract

Each phase/skill ends with a **"→ next"** line naming the exact file its output flows into. Each autonomy module ends with **"→ feeds"**. Follow those lines and you can never get stranded.

## Entry points

| You want… | Start at |
|---|---|
| Full autonomous 24/7 operation | `commands/autohunt.md` → `autonomy/scheduler-loop.md` |
| Just discover fields (no testing) | `commands/discover.md` → `autonomy/program-discovery.md` |
| Hunt one target you provide | `commands/hunt.md` → `phases/00-scope.md` |
| Reverse a binary/app | `commands/reverse.md` → `../reverse-engineering/*` |
| Understand the design | `MANIFESTO.md` |
