# Memory & Dedupe

**Goal:** make the agent compound — never re-hunt, get sharper each cycle.

## Stores (`memory/`)
- `bounty_programs.jsonl` — every field + status (candidate/qualified/authorized/exhausted/blacklisted).
- `bounty_assets.jsonl` — per program: hosts/endpoints/params seen, last tested, result.
- `bounty_findings.jsonl` — confirmed findings (class, asset, severity, report id, payout).
- `bounty_patterns.jsonl` — reusable signals (vendor X ships GraphQL introspection, etc.).
- `bounty_blacklist.jsonl` — gate-failed / forbade testing → never re-queue.

## Dedupe
- **Program:** skip ids already present (except re-open on policy change).
- **Asset:** skip endpoints tested within `recheck_interval` with no change.
- **Finding:** check findings + public disclosures before drafting (avoid self-dupe).

## Learning
After each engagement: which skills hit on which stacks → raise weight; low-yield field → down-rank similar; new bypass → `bounty_patterns.jsonl`.

## Hygiene
Cap stores; keep backups; redact secrets/PII (never store live creds or real victim data).

## Hard rule
Memory informs **priority**, never **authorization** — a remembered "good" field still re-passes the gate each cycle.

→ feeds next discovery cycle
