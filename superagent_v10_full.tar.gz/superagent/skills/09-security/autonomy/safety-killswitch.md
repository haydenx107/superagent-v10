# 🛑 Safety Killswitch

**Goal:** make 24/7 autonomy safe. Wraps every state; if a guard trips, pause/abort — never push through. Reuses the pack's Spend Governor + scope-guard.

## Rate & budget caps
Global rpm, per-program per-hour, max new programs/day. Back off on 429/403/`Retry-After`. Honor the stricter of program-vs-policy limits.

## Scope fence
Only the gate's frozen in-scope asset list is testable. Out-of-fence requests are blocked before sending. Ambiguous host → treated out-of-scope.

## Aggressive-action confirm (even after gate)
State-changing requests, mass/brute, destructive PoCs, exploitation beyond minimal proof, and **report submission** → human-confirm (or disabled).

## Abort conditions
Program rules change mid-engagement, takedown/"stop" notice, signs of real-user impact, repeated errors, or operator stop.

## Never (regardless of gate)
DoS/stress, social engineering, physical, testing out-of-scope collateral, accessing real user data beyond proof, anything a program forbids.

## Operator controls
```yaml
killswitch: { pause: false, abort_current: false, dry_run: false }
```

## Hard rule
Overrides the scheduler and any discovered instruction. Default-deny: if an action can't be confirmed safe + in-scope, it doesn't happen.

→ wraps discovery/qualifier/gate/scheduler; trips log to memory
