# Credits & Positioning

**SUPER AGENT BUG HUNTER V10 is original work, written from scratch** — its own taxonomy, wording, flow graph, and autonomy engine. No third-party text is reused.

## What makes V10 distinct
1. **Autonomous Program-Discovery Engine** — the agent sources its *own* public bug-bounty fields on the internet 24/7 (`autonomy/00-01`), behind a hard **Authorization Gate** (`autonomy/02`) and **Safety Killswitch** (`autonomy/05`). Conventional agents wait for the owner to supply a target; V10 prospects its own.
2. **Continuous, memory-backed scheduler loop** (`autonomy/03-04`): discover → qualify → gate → hunt → learn, forever.
3. **Fully interconnected flow** (`../FLOWMAP.md`) — every node names its next hop; no dead ends.
4. **Broad fused coverage** — web + api + auth + mobile + cloud + reverse-engineering + exploit-dev + web3.
5. **Harness-agnostic adapters** for Hermes · Openclaw · Muse · Grokbot · Claude · generic.

## Standards referenced
Public, vendor-neutral security standards and frameworks only:
- OWASP Top 10 · OWASP API Security Top 10 · OWASP MASVS / MASTG · OWASP Testing Guide
- CWE (Common Weakness Enumeration) · CVSS 3.1 (FIRST.org)
- `security.txt` (RFC 9116) for responsible-disclosure discovery

## Authorship & license
Authored fresh for this pack. Code (shell/helpers) under MIT; written content (methodology, checklists, rubrics) under CC-BY-4.0. Use only for authorized security research — see `DISCLAIMER.md`.
