# 09-security/cloud-infra — Cloud & infra (misconfig, CI/CD, K8s)

3 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`ci-cd`](ci-cd.md) | CI/CD & Supply Chain | Public repos, build configs, package manifests.… |
| [`cloud-misconfig`](cloud-misconfig.md) | Cloud Misconfiguration | AWS/GCP/Azure target; after SSRF or when buckets/keys surfac… |
| [`container-k8s`](container-k8s.md) | Container / Kubernetes | Containers/K8s; exposed kubelet/dashboard/etcd or SSRF into … |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).
