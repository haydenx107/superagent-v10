---
skill: enterprise-defense
title: "Enterprise & Defensive Ops"
category: "Security"
load_when: "KQL, azure, log analytics, HIDS, auto firewall, intrusion, kusto, sentinel"
pack: SUPERAGENT V10
---

# Enterprise & Defensive Ops

Troubleshooting enterprise (Azure / KQL) + keamanan defensif ringan (Mini-HIDS: auto-firewall dari log). **Defensif murni** — ini sisi bertahan, bukan menyerang. Tool: `tools/hids.py`.

| Capability | Surface | Sifat |
|---|---|---|
| Azure / enterprise troubleshooting | KQL (Log Analytics / App Insights) | read-only investigasi |
| Mini-HIDS | parse log → deteksi → auto-firewall | defensif, gated |

---

## 1. Azure / Enterprise troubleshooting (KQL)

KQL (Kusto) = bahasa query buat Log Analytics, App Insights, Sentinel. Investigasi insiden = nulis query yang tajam, bukan scroll log.

Pola query inti:

```kql
// Top error 24 jam terakhir, grouped
AppExceptions
| where TimeGenerated > ago(24h)
| summarize count() by ProblemId, OuterMessage
| order by count_ desc
| take 20

// Latency spike — p95 per operation per 5 menit
AppRequests
| where TimeGenerated > ago(6h)
| summarize p95=percentile(DurationMs, 95) by bin(TimeGenerated, 5m), Name
| order by p95 desc

// Korelasi: request gagal → exception di trace yang sama
AppRequests
| where Success == false
| join kind=inner (AppExceptions) on OperationId
| project TimeGenerated, Name, ResultCode, OuterMessage
```

Alur troubleshooting: **scope waktu** (`ago()`) → **agregasi** (`summarize`) → **urut** (top offender) → **korelasi** (`join` on OperationId/CorrelationId) → **drill** (1 trace utuh). Operator pegang langganan; agent nulis query, operator jalankan di portal/`az monitor`. Untuk akses langsung: `az monitor log-analytics query -w <workspace-id> --analytics-query "<KQL>"`.

Combo dengan systematic-debug (systematic debugging) — KQL = sumber bukti untuk fase RCA.

## 2. Mini-HIDS — auto-firewall dari log

Host Intrusion Detection ringan: baca log (auth/nginx/syslog), deteksi pola serangan, **auto-block via firewall** dengan allowlist & TTL. Defensif, jalan di VPS operator sendiri.

```python
from hids import HIDS
h = HIDS(
    sources=["/var/log/auth.log", "/var/log/nginx/access.log"],
    rules=[
        {"name":"ssh_bruteforce", "pattern":r"Failed password.*from (\d+\.\d+\.\d+\.\d+)",
         "threshold":5, "window":300, "action":"block"},
        {"name":"path_scan", "pattern":r'"(GET|POST) /(\.env|wp-admin|admin\.php)',
         "ip_group":r"(\d+\.\d+\.\d+\.\d+)", "threshold":10, "window":60, "action":"block"},
    ],
    allowlist=["127.0.0.1", "<operator-ip>"],   # JANGAN block diri sendiri
    block_ttl=3600,                              # auto-unblock 1 jam (hindari permaban salah)
    backend="ufw",                               # ufw | iptables | nftables
)
h.watch()      # tail log, deteksi, block + alert ke TG (bots-automation)
```

Aturan keselamatan (HARD):
- **Allowlist operator IP + localhost** selalu — paling fatal: agent ngeban operator sendiri dari SSH.
- **TTL block**, bukan permanen — false positive auto-pulih.
- **Dry-run dulu** (`h.watch(dry_run=True)`) → lihat apa yang *akan* di-block sebelum live.
- Setiap block → log + alert (bots-automation Telegram), bukan diam.
- Firewall write = aksi sistem → **R9 gate sekali** saat aktivasi pertama.

Ini melengkapi security-audit (audit/security review): security-audit = nemu kelemahan, enterprise-defense = pertahanan runtime aktif.

---

## Catatan
- KQL = read-only investigasi; aman, gak ada gate.
- Mini-HIDS = defensif & gated (allowlist + TTL + R9 + alert). Bukan alat serangan.
- Combo: enterprise-defense + systematic-debug (debug RCA pakai KQL) + bots-automation (alert) + infra-deploy (VPS firewall ops).
