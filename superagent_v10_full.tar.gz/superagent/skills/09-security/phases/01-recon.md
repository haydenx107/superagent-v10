# Phase 01 — Recon

**Goal:** biggest, best-understood in-scope asset inventory (passive → active → content).

## Actions
1. Passive: `../recon/osint.md`, `../recon/subdomain.md` (cert transparency, archives, GitHub).
2. Active (within budget): brute/permute/resolve/probe; port scan; fingerprint.
3. Takeover sweep: `../recon/takeover.md`.
4. Content & JS: `../recon/content-discovery.md`, `../recon/js-mining.md`.

All requests pass through the killswitch scope fence. Log to `../templates/recon-notes.md`.

## Exit criteria
- Live-host list + tech/titles; endpoint & param corpus; takeover candidates.

**→ next: `02-surface.md`** · checklist: `../checklists/recon.md`
