# phases/ — the engagement timeline

Once the autonomy gate authorizes a field (or you supply a target manually), the engagement runs these phases in order. Each phase names the exact next file (no dead ends). `10-learn` loops back into the autonomy memory.

| Phase | File | Goal | → next |
|-------|------|------|--------|
| 00 | `00-scope.md` | Freeze & re-verify scope | 01 |
| 01 | `01-recon.md` | Asset inventory | 02 |
| 02 | `02-surface.md` | Prioritized hunt plan | 03 |
| 03 | `03-hunt.md` | Per-class discovery | 04 |
| 04 | `04-chain.md` | Escalate impact | 05 |
| 05 | `05-exploit.md` | Safe PoC | 06 |
| 06 | `06-triage.md` | 7-Gate self-triage | 07 |
| 07 | `07-report.md` | Write report | 08 |
| 08 | `08-retest.md` | Verify fix | 09 |
| 09 | `09-disclose.md` | Coordinated disclosure | 10 |
| 10 | `10-learn.md` | Extract patterns → memory | autonomy/04 (loop) |
