# Phase 07 — Report

**Goal:** a report the triager reproduces first try.

## Actions
- `../reporting/writeup.md` + `../templates/report-template.md`.
- One issue per report; lead with impact; literal repro; redacted PoC; CVSS+CWE.
- **Submission is human-gated** (autosubmit off) unless the owner enabled it for this program.
- Log to `../templates/finding-ledger.md`.

**→ next: `08-retest.md`**
