---
skill: evidence
title: "Evidence Hygiene"
category: "Security · Bug-Hunt Core"
load_when: "Phase 05-07 when confirming a finding."
pack: SUPERAGENT V10
bughunt: true
---
# Evidence Hygiene
**Capture:** raw request+response (trimmed), two labeled test accounts for cross-user, screenshots of the consequence, short video for multi-step/race, the exact ids used.
**Redact:** no real third-party PII; mask tokens/secrets.
**Reproduce:** from clean state, from scratch, ≤10 min. If you can't, it isn't ready.
**Store:** `../templates/recon-notes.md`, `../templates/finding-ledger.md`, `../templates/session-log.md`; memory via `autonomy/04`.

**→ supports `../phases/05,06,07`.**
