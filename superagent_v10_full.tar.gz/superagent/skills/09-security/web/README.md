# 09-security/web — Web exploitation (OWASP + chains)

16 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`business-logic`](business-logic.md) | Business Logic | Any multi-step flow, pricing, quotas, permissions, state mac… |
| [`cache-poison`](cache-poison.md) | Cache Poisoning / Deception | CDN/edge-cached apps; unkeyed inputs influencing responses.… |
| [`cors`](cors.md) | CORS Misconfiguration | Any API returning sensitive data with CORS headers.… |
| [`csrf`](csrf.md) | CSRF | Cookie-authed state-changing request without strong anti-CSR… |
| [`deserialization`](deserialization.md) | Insecure Deserialization | Serialized blobs in cookies/params (Java/.NET/PHP/pickle/Rub… |
| [`file-upload`](file-upload.md) | File Upload | Any upload feature (avatar/doc/import/attachment).… |
| [`idor`](idor.md) | IDOR / BOLA | Any endpoint referencing an object by id/uuid/slug — the #1 … |
| [`lfi`](lfi.md) | LFI / Path Traversal | Any param naming a file/path/template/page.… |
| [`open-redirect`](open-redirect.md) | Open Redirect | Any redirect param (next/redirect/url/return/callback).… |
| [`race-condition`](race-condition.md) | Race Conditions | Any limited/idempotency-sensitive action (redeem/withdraw/vo… |
| [`request-smuggling`](request-smuggling.md) | HTTP Request Smuggling (Desync) | Chained proxy/CDN + origin; CL/TE handling quirks.… |
| [`sqli`](sqli.md) | SQL / NoSQL Injection | Any param reaching a DB query (search/filter/sort/id/login/i… |
| [`ssrf`](ssrf.md) | SSRF | Any server-side fetch — url params, webhooks, importers, PDF… |
| [`ssti`](ssti.md) | SSTI | User input rendered through a server template (emails/PDFs/p… |
| [`xss`](xss.md) | XSS (reflected / stored / DOM / blind) | Any user input rendered in a page or reachable client-side s… |
| [`xxe`](xxe.md) | XXE | Any XML intake — SOAP, SAML, SVG, DOCX/XLSX, RSS, config imp… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).
