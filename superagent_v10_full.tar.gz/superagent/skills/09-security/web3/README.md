# 09-security/web3 — Web3 (smart-contract audit, token rug scan)

2 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`smart-contract-audit`](smart-contract-audit.md) | Smart Contract Audit | Any Solidity/EVM contract in scope (Immunefi-style).… |
| [`token-scan`](token-scan.md) | Token / Rug Scanner | A token/meme contract to assess for rug/honeypot.… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).
