# /hunt — hunt one target (manual or post-gate)

**Trigger:** "hunt <in-scope target>" or auto-called by `/autohunt` after the gate.

## Recipe
1. `../core/scope-guard.md` — confirm the 5 gates.
2. `../phases/01-recon.md` → `../phases/02-surface.md` → `../phases/03-hunt.md`.
3. Per (asset, class): open `skills/<cat>/<class>.md`; pull `../payloads/<class>.txt`.
4. Log coverage in `../templates/finding-ledger.md`; on a hit → `/chain`.

## Coverage order
authz → auth → injection → client → logic → infra → web3 → advanced.

## Output
Candidate findings. → `/chain`.
