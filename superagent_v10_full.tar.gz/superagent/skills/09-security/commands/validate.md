# /validate — the 7-Question Gate

**Trigger:** before any report.

## Recipe
`../reporting/validation-gate.md` — all 7 must pass: reproducible · in-scope · not-duplicate · real-impact · doable-NOW · scored+CWE · evidence-clean.

Kill false positives; dedupe against memory + public disclosures.

## Output
Validated, scored findings. → `/report`.
