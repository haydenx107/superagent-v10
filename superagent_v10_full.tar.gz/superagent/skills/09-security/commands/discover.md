# /discover — find fields (passive, no testing)

**Trigger:** "find bug bounty programs" / top up the queue.

## Recipe
1. `../autonomy/program-discovery.md` — search public directories, VDP indexes, `security.txt`.
2. `../autonomy/program-qualifier.md` — score/filter.
3. Write candidates to `../templates/program-queue.md`.

This never tests anything. It only builds the queue.

## Output
A ranked candidate queue ready for the gate (`/qualify` → `/autohunt`).
