# /qualify — score, filter, and gate fields

**Trigger:** after `/discover`, or to review the queue.

## Recipe
1. `../autonomy/program-qualifier.md` — apply filters + scoring.
2. `../autonomy/authorization-gate.md` — run the 5-point gate on top fields.
3. Mark queue entries: qualified / authorized / human-confirm / blacklisted.

## Output
An authorized shortlist ready for engagement, plus a clean blacklist.
