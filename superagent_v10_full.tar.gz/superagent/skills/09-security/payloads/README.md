# payloads/ — curated starter payloads
Use only against authorized, in-scope targets. Keep payloads **benign** (prove, don't damage). Adapt to context + WAF (`../references/waf-bypass.md`). The killswitch gates aggressive use.
