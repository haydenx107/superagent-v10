# ✅ Surface
- [ ] clustered by type (web/SPA/REST/GraphQL/mobile/binary/web3)
- [ ] walked in every role
- [ ] state-changing actions + auth surfaces + object-id refs cataloged
- [ ] scored (severity-matrix) + memory recommended_skills pulled
- [ ] hunt plan written (asset→classes→skills)
