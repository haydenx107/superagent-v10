# ✅ 7-Question Gate (all pass)
- [ ] reproducible from clean state
- [ ] in scope / not excluded
- [ ] not a duplicate (memory + public)
- [ ] real impact (not 200-no-data/self-only)
- [ ] attacker can do it NOW
- [ ] severity scored + CWE
- [ ] evidence clean/redacted
