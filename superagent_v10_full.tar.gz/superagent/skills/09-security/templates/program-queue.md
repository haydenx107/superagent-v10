# Program Queue (autonomy state)
The discovery/qualifier/gate pipeline writes here. Human-readable mirror of autonomy memory.

| id | name | source | invites_testing | pays | score | status | gate | discovered | notes |
|----|------|--------|-----------------|------|-------|--------|------|------------|-------|

status: candidate · qualified · authorized · human-confirm · exhausted · blacklisted
gate: pending · pass · fail · confirm

## Blacklist (never re-queue)
| id | reason | date |
