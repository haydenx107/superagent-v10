# Session Log (CYA — every autonomous action)
| timestamp | program | phase/command | action | in-scope? | result |
|-----------|---------|---------------|--------|-----------|--------|

Record gate decisions, human-confirms, killswitch trips, and every active request batch.
