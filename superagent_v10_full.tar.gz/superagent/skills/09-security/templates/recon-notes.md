# Recon Notes — <program>
## Frozen scope (from authorization gate)
- In scope: | Out of scope: | Excluded tests: | RoE:
## Assets
| Host | IP | Ports | Tech | Title | Notes |
## Endpoints / params
| Endpoint | Method | Param | Behavior |
## Test accounts (scoped)
| Account | Role | Notes |
## Takeover / secret candidates
