# 09-security/reporting — Reporting (writeup, CVSS, validation gate, disclosure)

4 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`cvss-impact`](cvss-impact.md) | CVSS & Impact | Phase 06/07, to set/justify severity.… |
| [`disclosure`](disclosure.md) | Disclosure & Triage | Phases 07-09.… |
| [`validation-gate`](validation-gate.md) | The 7-Question Validation Gate | Phase 06 — the 7-Gate before any report.… |
| [`writeup`](writeup.md) | Writing the Report | Phase 07, for every finding.… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).
