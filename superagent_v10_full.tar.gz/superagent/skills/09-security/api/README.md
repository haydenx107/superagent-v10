# 09-security/api — API security (BOLA/BFLA, GraphQL, mass-assignment)

4 playbook(s).

| Skill | What it does | Load when |
|---|---|---|
| [`graphql`](graphql.md) | GraphQL | Any /graphql,/gql,/query, or GraphQL in JS.… |
| [`mass-assignment`](mass-assignment.md) | Mass Assignment & Excessive Data Exposure | Any create/update endpoint + any JSON response (API3).… |
| [`rate-limit`](rate-limit.md) | Rate Limiting & Resource Abuse | Login/OTP/reset/invite/coupon and expensive endpoints (API4)… |
| [`rest-authz`](rest-authz.md) | REST Authorization (BOLA/BFLA) | Any REST API with ids or role-gated functions (API1/API5).… |

---
Up to [09-security](../README.md) · [registry](../../00-core/skill-registry.md).
