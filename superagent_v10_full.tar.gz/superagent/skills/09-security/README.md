> 📖 Full walkthrough: **../../BUGBOUNTY-GUIDE.md** (A-Z bug-bounty with this domain).

# 09-security — Bug-Bounty Hunting Playbooks

A full-lifecycle, from-scratch bug-bounty skill library (57 playbooks) that the **`bug-bounty-autonomy`** engine (in `../09-security/`) drives once a public program passes the Authorization Gate.

> ⚠️ Authorized testing only. See `autonomy/bug-bounty-autonomy.md` and its `autonomy/authorization-gate.md`.

## Flow
```
bug-bounty-autonomy (discover → qualify → GATE) → phases/ (00-scope..10-learn)
   → per-class playbooks below → reporting → learn
```
See `FLOWMAP.md` for the full graph. Supporting material: `phases/` `payloads/` `checklists/` `references/` `commands/`.

## Sub-categories

### core/ — Core (methodology, scope-guard, chaining, evidence) (5)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`chaining`](core/chaining.md) | Chaining Catalog | Phase 04, after any finding, to escalate impact.… |
| [`evidence`](core/evidence.md) | Evidence Hygiene | Phase 05-07 when confirming a finding.… |
| [`methodology`](core/methodology.md) | Core Methodology | Always — the mental model for every engagement.… |
| [`mindset`](core/mindset.md) | Hunter Mindset | When stuck, scanning blindly, or chasing low-value noise.… |
| [`scope-guard`](core/scope-guard.md) | Scope Guard — the 5 gates | Phase 00 and before any new host or aggressive action. Non-n… |

### recon/ — Recon & asset discovery (5)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`content-discovery`](recon/content-discovery.md) | Content & Param Discovery | Phase 01/03 per host, for hidden functionality.… |
| [`js-mining`](recon/js-mining.md) | JavaScript Mining | Phase 01/02 for SPAs — richest endpoint source.… |
| [`osint`](recon/osint.md) | Passive OSINT | Phase 01, first — passive intel, zero target noise.… |
| [`subdomain`](recon/subdomain.md) | Subdomain Enumeration | Phase 01 after OSINT, to expand surface.… |
| [`takeover`](recon/takeover.md) | Subdomain / Resource Takeover | Phase 01 after resolving — clean quick win.… |

### web/ — Web exploitation (OWASP + chains) (16)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`business-logic`](web/business-logic.md) | Business Logic | Any multi-step flow, pricing, quotas, permissions, state mac… |
| [`cache-poison`](web/cache-poison.md) | Cache Poisoning / Deception | CDN/edge-cached apps; unkeyed inputs influencing responses.… |
| [`cors`](web/cors.md) | CORS Misconfiguration | Any API returning sensitive data with CORS headers.… |
| [`csrf`](web/csrf.md) | CSRF | Cookie-authed state-changing request without strong anti-CSR… |
| [`deserialization`](web/deserialization.md) | Insecure Deserialization | Serialized blobs in cookies/params (Java/.NET/PHP/pickle/Rub… |
| [`file-upload`](web/file-upload.md) | File Upload | Any upload feature (avatar/doc/import/attachment).… |
| [`idor`](web/idor.md) | IDOR / BOLA | Any endpoint referencing an object by id/uuid/slug — the #1 … |
| [`lfi`](web/lfi.md) | LFI / Path Traversal | Any param naming a file/path/template/page.… |
| [`open-redirect`](web/open-redirect.md) | Open Redirect | Any redirect param (next/redirect/url/return/callback).… |
| [`race-condition`](web/race-condition.md) | Race Conditions | Any limited/idempotency-sensitive action (redeem/withdraw/vo… |
| [`request-smuggling`](web/request-smuggling.md) | HTTP Request Smuggling (Desync) | Chained proxy/CDN + origin; CL/TE handling quirks.… |
| [`sqli`](web/sqli.md) | SQL / NoSQL Injection | Any param reaching a DB query (search/filter/sort/id/login/i… |
| [`ssrf`](web/ssrf.md) | SSRF | Any server-side fetch — url params, webhooks, importers, PDF… |
| [`ssti`](web/ssti.md) | SSTI | User input rendered through a server template (emails/PDFs/p… |
| [`xss`](web/xss.md) | XSS (reflected / stored / DOM / blind) | Any user input rendered in a page or reachable client-side s… |
| [`xxe`](web/xxe.md) | XXE | Any XML intake — SOAP, SAML, SVG, DOCX/XLSX, RSS, config imp… |

### api/ — API security (BOLA/BFLA, GraphQL, mass-assignment) (4)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`graphql`](api/graphql.md) | GraphQL | Any /graphql,/gql,/query, or GraphQL in JS.… |
| [`mass-assignment`](api/mass-assignment.md) | Mass Assignment & Excessive Data Exposure | Any create/update endpoint + any JSON response (API3).… |
| [`rate-limit`](api/rate-limit.md) | Rate Limiting & Resource Abuse | Login/OTP/reset/invite/coupon and expensive endpoints (API4)… |
| [`rest-authz`](api/rest-authz.md) | REST Authorization (BOLA/BFLA) | Any REST API with ids or role-gated functions (API1/API5).… |

### auth/ — Auth (JWT, OAuth, SAML, MFA, session, reset) (6)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`jwt`](auth/jwt.md) | JWT Attacks | Any JWT (eyJ...).… |
| [`mfa-bypass`](auth/mfa-bypass.md) | MFA / 2FA Bypass | Any login enforcing MFA/OTP/2FA.… |
| [`oauth`](auth/oauth.md) | OAuth / OIDC | Any 'Sign in with…' / OAuth / OIDC / SSO.… |
| [`password-reset`](auth/password-reset.md) | Password Reset | Any forgot-password/reset/recovery flow.… |
| [`saml`](auth/saml.md) | SAML | Enterprise SSO using SAML (ACS, SAMLResponse).… |
| [`session`](auth/session.md) | Session Management | After any login; audit session lifecycle.… |

### mobile/ — Mobile (Android/iOS) (2)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`android`](mobile/android.md) | Android Testing | Any Android APK in scope; the app maps the backend.… |
| [`ios`](mobile/ios.md) | iOS Testing | Any iOS app in scope.… |

### reverse-engineering/ — Reverse engineering (binary/firmware/protocol) (6)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`binary-triage`](reverse-engineering/binary-triage.md) | Binary Triage | Any compiled artifact/firmware needing fast orientation.… |
| [`deobfuscation`](reverse-engineering/deobfuscation.md) | Deobfuscation & Anti-Analysis | Binary packed/obfuscated or fights the debugger.… |
| [`dynamic-re`](reverse-engineering/dynamic-re.md) | Dynamic RE | When static is ambiguous or a runtime check must be defeated… |
| [`firmware`](reverse-engineering/firmware.md) | Firmware RE | IoT/router/embedded firmware images in scope.… |
| [`protocol-re`](reverse-engineering/protocol-re.md) | Protocol & Format RE | Thick clients/games/IoT/custom binary protocols or formats.… |
| [`static-re`](reverse-engineering/static-re.md) | Static RE | After triage, to map logic & sinks without running.… |

### exploit-dev/ — Exploit dev (fuzzing, memory-corruption, ROP, PoC) (4)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`fuzzing`](exploit-dev/fuzzing.md) | Fuzzing | You have a binary/parser/protocol and want crashes.… |
| [`memory-corruption`](exploit-dev/memory-corruption.md) | Memory Corruption | You have a crash/primitive and need control.… |
| [`poc-engineering`](exploit-dev/poc-engineering.md) | PoC Engineering | Phase 05, to finalize any PoC (native or web).… |
| [`rop-chains`](exploit-dev/rop-chains.md) | ROP Chains | You control stack/return on an NX target.… |

### cloud-infra/ — Cloud & infra (misconfig, CI/CD, K8s) (3)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`ci-cd`](cloud-infra/ci-cd.md) | CI/CD & Supply Chain | Public repos, build configs, package manifests.… |
| [`cloud-misconfig`](cloud-infra/cloud-misconfig.md) | Cloud Misconfiguration | AWS/GCP/Azure target; after SSRF or when buckets/keys surfac… |
| [`container-k8s`](cloud-infra/container-k8s.md) | Container / Kubernetes | Containers/K8s; exposed kubelet/dashboard/etcd or SSRF into … |

### web3/ — Web3 (smart-contract audit, token rug scan) (2)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`smart-contract-audit`](web3/smart-contract-audit.md) | Smart Contract Audit | Any Solidity/EVM contract in scope (Immunefi-style).… |
| [`token-scan`](web3/token-scan.md) | Token / Rug Scanner | A token/meme contract to assess for rug/honeypot.… |

### reporting/ — Reporting (writeup, CVSS, validation gate, disclosure) (4)
| Skill | What it does | Load when |
|-------|--------------|-----------|
| [`cvss-impact`](reporting/cvss-impact.md) | CVSS & Impact | Phase 06/07, to set/justify severity.… |
| [`disclosure`](reporting/disclosure.md) | Disclosure & Triage | Phases 07-09.… |
| [`validation-gate`](reporting/validation-gate.md) | The 7-Question Validation Gate | Phase 06 — the 7-Gate before any report.… |
| [`writeup`](reporting/writeup.md) | Writing the Report | Phase 07, for every finding.… |

---
**Total: 57 playbooks.** Orchestrated by `autonomy/bug-bounty-autonomy.md`.
