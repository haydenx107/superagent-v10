---
skill: executive-function
title: "Executive Function & Neurodivergent"
category: "Human-Centered"
load_when: "task breakdown, executive function, ADHD, overwhelmed, fokus, context switch, prioritas"
pack: SUPERAGENT V10
---

# Executive Function & Neurodivergent

Skill yang nge-scaffold *fungsi eksekutif* operator: pecah task biar gak overwhelm, kelola context-switch, dan prioritas saat kepala penuh. Didasarkan pada riset executive function (bukan motivational fluff). **Opsional, soft skill.** Komplemen decision-support (problem shaping) & `triage.py` (v4.0).

> Nada: dukungan, bukan ceramah. Operator neurodivergent gak butuh "kamu pasti bisa!" — butuh struktur konkret yang ngurangin beban kerja kognitif. Tetap gaya SUPERAGENT: direct, tanpa fluff (SOUL).

---

## Prinsip (executive function, bukan motivasi)

Fungsi eksekutif = kemampuan *mulai*, *urut*, *fokus*, *switch*, *inget*. Yang bikin macet biasanya bukan malas — tapi **task kegedean / kabur / terlalu banyak open-loop**. Skill ini nge-tutup gap itu.

## 1. Task breakdown (anti-overwhelm / ADHD-style)

```
- Pecah sampai langkah pertama < 2 menit & KONKRET (verb + objek). "Riset" ❌ → "buka 1 tab, baca 1 paragraf" ✅
- Tunjukin SATU next action, sembunyiin sisanya (kurangi beban kerja memori).
- Tiap langkah punya "selesai" yang kelihatan — biar ada dopamin checkmark.
- Estimasi waktu kasar per langkah (bantu time-blindness).
- Body-double mode: agent nemenin per-langkah ("udah? lanjut yang ini") daripada dump semua.
```

Output:
```
🎯 sekarang (cuma ini): buka editor, bikin file kosong todo.py  (~1 mnt)
   ↓ habis itu gua kasih langkah berikutnya — sisanya gua pegang, jangan dipikirin
```

## 2. Context switching & re-entry

Switch task = mahal buat working memory. Kurangin biayanya:

```
- Sebelum switch: tulis "breadcrumb" — lagi di mana, next action apa, file/baris apa.
- Saat balik: agent restore konteks dari breadcrumb (pakai memory_engine), bukan operator nginget sendiri.
- Batasi WIP: maksimal 1-2 task aktif. Sisanya masuk "parking lot" (gak ilang, tapi gak di muka).
```

```python
from memory_engine import MemoryEngine
mem = MemoryEngine()
mem.remember("PAUSE: bot TG, lagi di webhook handler line 42, next: test dedup", "breadcrumb", tags="resume")
# balik nanti → agent recall breadcrumb → "lo tadi di line 42, next test dedup. gas?"
```

## 3. Prioritization saat overwhelmed

Kepala penuh → keputusan lumpuh. Kasih struktur, jangan nambah pilihan:

```
- Brain-dump dulu: keluarin SEMUA ke list (offload dari working memory).
- Lalu agent yang sortir: urgent×penting (Eisenhower) ATAU "1 hal yang kalau beres, sisanya lebih gampang".
- Tawarkan 1 rekomendasi, bukan 5 opsi (decision fatigue).
- "Cukup baik" > sempurna. Tutup loop kecil dulu buat momentum.
```

---

## Catatan
- Dukungan struktural, bukan diagnosis/terapi. Kalau operator nyinggung kesehatan mental serius → bantu yang praktis, jangan pura-pura jadi klinisi.
- One-action-at-a-time = default mode skill ini (lawan dari R2 "dump semua" — di sini sengaja drip).
- Combo: executive-function + decision-support (shaping tujuan kabur) + triage (daily-watchdog) + memory_engine (breadcrumb resume).
