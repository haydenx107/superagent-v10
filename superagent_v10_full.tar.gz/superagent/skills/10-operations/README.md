# 10-operations — Operations & Human-Centered

Day-to-day assistant & people-aware ops: briefings, executive function, product specs, brand voice, defense, guides.

**6 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`daily-briefing`](daily-briefing.md) | Daily Assistant: Briefing & Alerts | briefing, ringkasan harian, alert, kabarin kalau, pantau harga, alarm… |
| [`daily-watchdog`](daily-watchdog.md) | Daily Assistant II: Watchdog/Vault/Triage | watchdog, restart kalau mati, simpen alamat, macro, voice note, screen… |
| [`executive-function`](executive-function.md) | Executive Function & Neurodivergent | task breakdown, executive function, ADHD, overwhelmed, fokus, context … |
| [`file-production`](file-production.md) | File & Artifact Production | PDF, DOCX, XLSX, PPTX, generate file, export, dokumen, file… |
| [`humanizer-voice`](humanizer-voice.md) | Humanizer & Brand Voice | humanizer, brand voice, AI tone, natural, manusiawi, rewrite, nada, vo… |
| [`scientific-research`](scientific-research.md) | Scientific & Deep Research | deep research, AI-Q, tooluniverse, hipotesis, citations, riset ilmiah,… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).
