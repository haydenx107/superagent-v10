---
skill: copywriting-mastery
title: "Copywriting & Writing Mastery"
category: "Content & Marketing"
load_when: "AIDA, PAS, CHEF, copywriting framework, SEO writing, storytelling, headline, copy"
pack: SUPERAGENT V10
---

# Copywriting & Writing Mastery

Frameworks copywriting yang teruji, SEO writing, storytelling, dan lokalisasi multibahasa (termasuk RTL). **Opsional.** Inti penulisan; pasangkan humanizer-voice (humanize/brand voice), content-strategy (distribusi sosial), content-creation (voice ID/CT), product-spec (idea→spec).

---

## 1. Copywriting frameworks (pakai yang cocok, jangan asal)

| Framework | Struktur | Kapan |
|---|---|---|
| **AIDA** | Attention → Interest → Desire → Action | iklan, landing, sales post |
| **PAS** | Problem → Agitate → Solution | pain-driven, cold audience |
| **BAB** | Before → After → Bridge | transformasi, testimonial |
| **4P** | Promise → Picture → Proof → Push | email, long-form sales |
| **CHEF** | Clear · Honest · Engaging · Fitting | filter kualitas semua copy |
| **70-20-10** | 70% value · 20% share/promo curated · 10% jualan | rasio mix konten |

```
Contoh PAS (cold):
P: "Post lo udah bagus tapi gak ada yang beli."
A: "Tiap hari scroll lewat, effort lo kebuang, kompetitor yang menang."
S: "Masalahnya bukan konten — tapi hook & CTA. Ini cara benerinnya: ..."
```

Pilih framework dari tujuan & suhu audience (cold/warm/hot), bukan kebiasaan. Satu copy = satu framework dominan.

## 2. SEO-optimized writer

```
1. KEYWORD   → primary + secondary + long-tail (intent: info/transaksional/navigasi)
2. STRUCTURE → keyword di title, H1, paragraf pertama, 1-2 subheading, natural di body
3. ON-PAGE   → meta description (≤155 char) + alt text + internal link + slug bersih
4. READABLE  → tetap buat manusia dulu; keyword-stuffing = penalti & jelek dibaca
```

Untuk caption/blog: keyword natural, jangan korbankan keterbacaan demi mesin. E-E-A-T: tunjukin pengalaman & bukti.

## 3. Storytelling & narrative

```
HOOK → STAKES → STRUGGLE → SHIFT → TAKEAWAY
("ini terjadi" → "kenapa penting" → "yang susah" → "titik balik" → "pelajaran buat lo")
```

Cerita > daftar fakta: spesifik (angka/nama/momen), satu emosi dominan, personal touch (sudut pandang lo). Hindari generik — detail konkret yang bikin nyangkut. Akhiri dengan satu pelajaran yang bisa dipakai pembaca.

## 4. Multilingual & localization (termasuk RTL)

Lokalisasi ≠ translate. Adaptasi makna, idiom, referensi budaya, format (tanggal/mata uang/satuan):

```
- Idiom & humor → cari padanan budaya, jangan harfiah
- RTL (Arab/Ibrani/Farsi/Urdu) → arah teks, alignment, mirror UI, angka
- Tone per budaya → formal vs casual beda norma per bahasa/daerah
- CTA → sesuaikan ekspektasi lokal, bukan terjemahan literal
```

Indonesia: hormati gaya operator (USER.md) — `lo/gue` vs `kamu` vs daerah. Jaga istilah teknis tetap (jangan terjemahin "deploy", "swap").

## 5. Idea → konten actionable

Idea kabur → konten lengkap: handoff **Grill-Me/To-PRD (product-spec)** buat pertajam, lalu tulis di sini dengan framework yang cocok. Internal-comms/LinkedIn thought-leadership → product-spec (§internal-comms) + framework storytelling di atas.

---

## Catatan
- Framework = kerangka, bukan borgol. Bagus = CHEF lolos (clear/honest/engaging/fitting).
- Selalu humanize (humanizer-voice) + cek brand (compliance-cicd) sebelum publish.
- Combo: copywriting-mastery + humanizer-voice (humanize) + content-strategy (platform) + content-creation (voice ID) + file-production (export blog/PDF).
