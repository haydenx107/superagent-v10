# 06-ai — AI & Inference

Build AI systems and run deep research: provider-agnostic inference, scientific method.

**2 skill(s).** Loaded on demand when a task matches the keywords below.

| Skill | What it does | Trigger keywords |
|-------|--------------|------------------|
| [`ai-builder`](ai-builder.md) | Inference Systems & AI Builder | LLM, prompt, claude API, openrouter, add model, AI, agent, model, GPT… |
| [`mcp-prompt-eng`](mcp-prompt-eng.md) | MCP-Builder & Prompt Engineering | MCP server, bikin MCP, prompt engineering, fix prompt, FastMCP, tool s… |

---
Back to [structure](../../STRUCTURE.md) · [full registry](../00-core/skill-registry.md).
