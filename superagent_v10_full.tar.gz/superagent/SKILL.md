---
name: superagent-v10
title: "SUPERAGENT V10 IRONCLAW"
version: "10.0.0"
description: "Sovereign autonomous agent — 158 on-demand skills across security, web3, content, infra, engineering, AI, plus a 24/7 autonomous bug-bounty engine. Harness-agnostic."
entrypoint: true
pack: SUPERAGENT V10
---

# SUPERAGENT V10 IRONCLAW — Skill Manifest

> Single entry-point. A harness loads this file first; it bootstraps the router and loads skills **on demand** by matching intent (never preload everything — token cost).

## Boot order (what to read first)
1. **`AGENTS.md`** — the router: rules R1–R13, keyword weights, autonomous-triggers table.
2. **`IDENTITY.md`** — voice, speed tiers, character modes.
3. **`SOUL.md`** — execution doctrine, guardrails, engineering-first persona.
4. **`skills/00-core/skill-registry.md`** — the skill registry + reflection loop (match intent → load skill).

Then load individual skills **only when their keywords match** the task.

## How skills are organized
158 skills live under `skills/<NN-category>/<name>.md`, each with uniform YAML frontmatter (`skill / title / category / load_when / pack`). Match a task's intent to a skill's `load_when` keywords, then read that one file.

| Folder | Domain | # |
|--------|--------|---|
| `skills/00-core/` | Registry & reflection | 1 |
| `skills/01-meta/` | Self-audit, eval, debug, strategy | 8 |
| `skills/02-business/` | Monetization, client revenue | 3 |
| `skills/03-content/` | Content, copy, strategy, video | 7 |
| `skills/04-infra/` | Deploy, bots, AI gateway, daily ops | 4 |
| `skills/05-engineering/` | Coding, data, API, batch, MCP | 6 |
| `skills/06-ai/` | AI builder, scientific research | 2 |
| `skills/07-creative/` | Media, design, desktop/robotics | 3 |
| `skills/08-web3/` | Web3 ops, NFT, airdrop, tokenomics | 9 |
| `skills/09-security/` | ★ Unified security domain: recon·web·api·auth·mobile·RE·exploit·cloud·web3·ctf·redteam·reporting + **autonomy/** (24/7 bug-bounty engine) | 108 |
| `skills/10-operations/` | Briefing, watchdog, exec-function, compliance | 6 |
| `skills/11-team/` | Team orchestration | 1 |
| `skills/09-security/` | ★ Unified security domain: recon·web·api·auth·mobile·RE·exploit·cloud·web3·ctf·redteam·reporting + **autonomy/** (24/7 bug-bounty engine) | 108 |

Full catalog & keywords → `skills/00-core/skill-registry.md`. File index → `INDEX.md`. Folder map → `STRUCTURE.md`.

New here? Read `WHY-V10.md` then `GUIDE.md`. See `FLOWMAP.md` for the global flow graph.

## Flagship: 24/7 autonomous bug-bounty
`skills/09-security/autonomy/bug-bounty-autonomy.md` lets the agent **self-source public bug-bounty fields** on the internet and hunt them continuously behind a hard Authorization Gate. Engine modules in `skills/references/bug-bounty-autonomy/`; tools `tools/bounty_discovery.py`, `tools/bounty_gate.py`, and the runnable **`tools/hunt_orchestrator.py`** (discover→qualify→gate→hunt-plan).

## Runtime & tooling
- **Setup:** `./install.sh` (checks env, verifies, runs tests)
- **Live demo:** `./demo.sh` — runs router + gate + autopilot + hunt-plan offline.
- **Doctor:** `python3 tools/selfcheck.py` — health check (counts, integrity, links).
- **Router:** `python3 tools/skill_router.py "<request>"` — the executable keyword router.
- **Hermes runtime** (on-chain ops H1–H10): `skills/hermes/` (its own `SKILL.md`, `DISPATCH.md`).
- **76 tools**: `tools/*.py` (revenue, cost-ledger, reflection, eval, watchdog, swarm, bounty engine…).
- **Integrity**: `SKILLS.lock` (SHA256 manifest, verified at boot).

## Safety (always on)
scope-guard · Spend Governor · dry-run default · secret tripwire · simulate-before-send · SKILLS.lock integrity · (bounty) Authorization Gate + killswitch. Authorized use only — see `docs/USER.md` and `LICENSE`.

## Docs
`docs/` — ARCHITECTURE (design), CHANGELOG, DEPLOY, STANDARD, TIME, TOOLS, MEMORY, HEARTBEAT, panduan (usage guide), REVIEW, CONTRIBUTORS.
