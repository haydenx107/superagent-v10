#!/usr/bin/env bash
# install.sh — SUPERAGENT V10 local setup & verification (one command)
# Zero external deps. Checks your environment, verifies pack integrity,
# runs the test suite, and prints how to use it.
#   ./install.sh
set -euo pipefail
cd "$(dirname "$0")"

bold()  { printf "\033[1m%s\033[0m\n" "$*"; }
green() { printf "\033[32m%s\033[0m\n" "$*"; }
red()   { printf "\033[31m%s\033[0m\n" "$*"; }
cyan()  { printf "\033[36m%s\033[0m\n" "$*"; }
rule()  { printf "\033[90m────────────────────────────────────────────────────────────\033[0m\n"; }

bold "⚡ SUPERAGENT V10 IRONCLAW — Local Setup"
rule

# 1) Python check
bold "① Checking Python…"
if ! command -v python3 >/dev/null 2>&1; then
  red "  ✗ python3 not found. Install Python 3.8+ and re-run."
  exit 1
fi
PYV="$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])')"
green "  ✓ python3 $PYV found"
python3 -c 'import sys; sys.exit(0 if sys.version_info[:2] >= (3,8) else 1)' || {
  red "  ✗ Python 3.8+ required (you have $PYV)"; exit 1; }
echo

# 2) Make tools + scripts executable
bold "② Preparing scripts…"
chmod +x demo.sh tools/*.py tools/tests/run_tests.sh 2>/dev/null || true
green "  ✓ demo.sh, tools/*.py are executable"
echo

# 3) Integrity + health (doctor)
bold "③ Verifying pack health…"
rule
python3 tools/selfcheck.py || { red "  pack health check failed — see above"; exit 1; }
rule; echo

# 4) Test suite
bold "④ Running the test suite…"
if python3 -m unittest discover -s tools/tests -p 'test_*.py' >/tmp/sa_v10_tests.log 2>&1; then
  LINE="$(grep -E '^Ran ' /tmp/sa_v10_tests.log | tail -1)"
  green "  ✓ $LINE — OK"
else
  red "  ✗ some tests failed:"; tail -15 /tmp/sa_v10_tests.log; exit 1
fi
echo

# 5) Done — usage
rule
green "✅ SUPERAGENT V10 is ready."
rule
cat <<'USAGE'
  Try it:
    ./demo.sh                                   live showcase (router+gate+autopilot+plan)
    python3 tools/selfcheck.py                  health check (doctor)
    python3 tools/skill_router.py "deploy nginx VPS"   route a request → skill
    python3 tools/autopilot.py tick --demo      one autonomous bug-bounty tick (safe)
    python3 tools/hunt_orchestrator.py demo     discover→gate→hunt-plan

  Read next:
    WHY-V10.md          intro, pillars, what's different
    FLOWMAP.md          how everything connects
    docs/ARCHITECTURE.md   the design
    RELEASE.md          release & demo guide

  Note: optional heavy extras (crypto/web3) use pip; the core runs on stdlib only.
USAGE
echo
