# File Index — SUPERAGENT V10 IRONCLAW SUPREME

## Core (always loaded)
- `AGENTS.md` — router + rules R1-R12 (V10: team delegation + autonomous) + keyword weights + autonomous triggers table
- `IDENTITY.md` — voice, speed tiers, character modes, V10 signature capabilities
- `SOUL.md` — IRONCLAW V10: sovereign execution, engineering-first, team hierarchy, monetization engine
- `docs/TIME.md` — 5-layer time awareness (system inject → tool call → cache → infer → disclose)
- `docs/HEARTBEAT.md` — session continuity, time refresh, token discipline
- `docs/TOOLS.md` — execution surface map, time tool specs
- `docs/USER.md` — operator profile (customize)
- `docs/MEMORY.md` — compaction rules
- `RELEASE.md` — release - `GUIDE.md` — complete user guide (usage, prompting, update, troubleshooting)
- `BUGBOUNTY-GUIDE.md` — full bug-bounty walkthrough (engine, 108 playbooks, phases, reporting) (usage, prompting, update, troubleshooting)
- `docs/MANIFEST.md` — full file inventory
- `WHY-V10.md` demo guide (how to show it off)
- `install.sh` — one-command local setup + verify
- `GUIDE.md` — complete user guide (usage, prompting, update, troubleshooting)
- `BUGBOUNTY-GUIDE.md` — full bug-bounty walkthrough (engine, 108 playbooks, phases, reporting) (usage, prompting, update, troubleshooting)
- `docs/MANIFEST.md` — full file inventory
- `WHY-V10.md` — intro, keunggulan, pembeda V10 (baca pertama)
- `README.md` — install + overview
- `docs/CONTRIBUTORS.md` — credits
- `docs/AUDIT.md` — full audit report (security, consistency, hardening)
- `docs/ARCHITECTURE.md` — full design reference (layers, security domain, guardrails)
- `docs/CHANGELOG.md` — version history (v3.1 baseline → v4.0)
- `docs/panduan.md` — operator usage guide (real-world examples)
- `docs/DEPLOY.md` — VPS deployment guide (supersedes README quick-start) *(v4.0)*
- `docs/STANDARD.md` — open SKILL.md format, progressive disclosure, cross-platform compat *(v4.1)*

## Skills — modular (load on trigger)
### Operational
- `skills/00-core/skill-registry.md` — skill registry, reflection loop, escape hatch
- `skills/02-business/monetization.md` — monetization, business ops, pricing
- `skills/04-infra/infra-deploy.md` — VPS, deployment, nginx, pm2, screen, tmux
- `skills/03-content/content-creation.md` — content, copywriting, Indonesian voice, airdrop templates
- `skills/04-infra/bots-automation.md` — Telegram bots, anti-duplicate, webhook, multi-bot
- `skills/05-engineering/data-insight.md` — data handling, O(1) lookups, chunked reads
- `skills/05-engineering/api-integration.md` — integrations, webhooks, Midtrans, Xendit, WA Cloud
- `skills/06-ai/ai-builder.md` — AI multi-provider, streaming, fallback, tool use, caching
- `skills/10-operations/file-production.md` — DOCX/XLSX/PPTX/PDF, ReportLab, image processing
- `skills/07-creative/interface-builder.md` — frontend, Tailwind, Web3 connect, AOS/Framer
- `skills/08-web3/web3-ops.md` — Web3 ops, RPC fallback, mass wallets, mint, airdrop check
- `skills/09-security/security-audit.md` — security audit, skill safety, secret scan
- `skills/05-engineering/batch-parallel.md` — batch ops, parallel exec, rate-limit, resume-from-failure
- `skills/08-web3/nft-minter.md` — universal NFT minter, OpenSea/Manifold/Zora/Seadrop, auto-gas
- `skills/10-operations/daily-briefing.md` — daily assistant: briefing & alert engine *(v4.0)*
- `skills/10-operations/daily-watchdog.md` — daily assistant II: watchdog, vault, multimodal, triage *(v4.0)*
- `skills/05-engineering/software-engineering.md` — software engineering & general coding (backend/db/testing/scaffold) *(v4.0)*
- `skills/05-engineering/power-planner-swarm.md` — power pack: planner, swarm, automation, backtest, dashboard, voice, explain *(v4.0)*
- `skills/07-creative/creative-media.md` — creative & media: ComfyUI, Manim, Excalidraw, ASCII video, design systems, slides, aesthetic judgment *(v4.1)*
- `skills/07-creative/desktop-control.md` — desktop & physical: macOS bg control (no cursor steal), Isaac Sim/Omniverse, scene prep, mobility *(v4.1)*
- `skills/10-operations/humanizer-voice.md` — humanizer & brand voice: AI-tell removal, brand voice adaptation *(v4.1)*
- `skills/09-security/enterprise-defense.md` — enterprise & defensive: Azure/KQL troubleshooting, Mini-HIDS auto-firewall *(v4.1)*
- `skills/10-operations/scientific-research.md` — scientific & deep research: AI-Q dispatch, tool workflows, hypothesis/experiment design *(v4.1)*
- `skills/10-operations/executive-function.md` — executive function & neurodivergent: task breakdown, context-switch, prioritization *(v4.1)*
- `skills/06-ai/mcp-prompt-eng.md` — MCP-builder + prompt engineering: scaffold MCP server, audit/fix prompts *(v4.1)*
- `skills/04-infra/compliance-cicd.md` — compliance, CI/CD & code migration: regulatory review, pipelines, language porting *(v4.1)*
- `skills/05-engineering/product-spec.md` — product & spec workflows: Grill-Me, To-PRD, To-Issues, TDD, internal-comms *(v4.1)*
- `skills/03-content/content-strategy.md` — content strategy & social media: pillars, calendar, platform adapter, hooks, thread/carousel/reels *(v4.1)*
- `skills/03-content/copywriting-mastery.md` — copywriting & writing mastery: AIDA/PAS/CHEF frameworks, SEO, storytelling, localization/RTL *(v4.1)*
- `skills/03-content/content-analytics.md` — content research, analytics & pipeline: trend/competitor, social listening, A/B, full pipeline *(v4.1)*
- `skills/02-business/client-revenue.md` — Client Revenue Engine: API-first bulk gig ops (harvest/scrape API, mass on-chain, integrasi job) — browser-last orchestrator *(v4.1.2)*
- `skills/08-web3/airdrop-intel.md` — Airdrop Intelligence: eligibility scorer, sybil self-audit, claim-window calendar, exit planner — offline logic, data delegated *(v4.2)*
- `skills/09-security/ctf-toolkit.md` — CTF / Whitehat toolkit: triage, multi-decode, classic crypto, hash-id — legal/in-scope only *(v4.2)*
- `skills/08-web3/alpha-radar.md` — Pre-TGE Alpha Radar: deteksi airdrop sebelum diumumkan, scoring sinyal 0-100 + tier *(v4.2)*
- `skills/08-web3/farm-roi.md` — Farming Portfolio & ROI Optimizer: EV/ROI per posisi, keep/trim/drop, idle-wallet flag *(v4.2)*
- `skills/08-web3/guide-studio.md` — Auto Guide Studio: panduan airdrop ID full + varian TG/X, referral embed, screenshot jobs *(v4.2)*
- `skills/08-web3/tokenomics-unlock.md` — Tokenomics & Unlock Pressure Engine: kalender unlock + tekanan jual vs likuiditas *(v4.2)*
- `skills/08-web3/anti-scam-sentinel.md` — Anti-Scam Sentinel: typosquat + sinyal halaman → risiko + warning post, read-only defensif *(v4.2)*
- `skills/08-web3/contract-watcher.md` — Contract-Change & Claim-Address Watcher: diff snapshot kontrak → alert + safe_to_claim *(v4.2)*
- `skills/01-meta/community-intel.md` — Community Intelligence: topik trending, pertanyaan, sentimen, FUD, ide konten *(v4.2)*
- `skills/03-content/omni-repurpose.md` — Omni-Repurpose Engine: 1 sumber → X thread/TG/IG carousel/TikTok/YouTube *(v4.2)*
- `skills/03-content/video-pipeline.md` — Video Script-to-Screen Pipeline: script ber-timing + storyboard + voiceover + SRT *(v4.2)*
- `skills/03-content/hook-ab-lab.md` — Hook A/B Lab: generate + skor prediksi stop-scroll 0-100, ranking varian *(v4.2)*
- `skills/09-security/ctf-web-exploit.md` — CTF Web Exploitation (sub of ctf-toolkit): SQLi/SSTI/SSRF/IDOR/XXE/JWT/deserialization playbook *(v4.2)*
- `skills/09-security/ctf-pwn.md` — CTF Binary Exploitation/pwn (sub of ctf-toolkit): ret2win/ret2libc/format-string/heap, pwntools *(v4.2)*
- `skills/09-security/ctf-reverse.md` — CTF Reverse Engineering (sub of ctf-toolkit): angr/Ghidra/radare2, keygen, deobfuscation *(v4.2)*
- `skills/09-security/ctf-crypto.md` — CTF Cryptography (sub of ctf-toolkit): RSA attacks/block-cipher/PRNG, offline rsa_attacks *(v4.2)*
- `skills/09-security/ctf-forensics.md` — CTF Forensics & Stego (sub of ctf-toolkit): pcap/memory/carving/stego + file-id fallback *(v4.2)*
- `skills/09-security/ctf-llm-redteam.md` — CTF Prompt-Injection/LLM Red-Teaming (sub of ctf-toolkit): Gandalf-style password extraction, defense ladder, host-locked solver *(v4.2)*
- `skills/11-team/team-orchestration.md` — Team Orchestration & Multi-User Ops: Level 0-3 hierarchy, delegation, conflict detection, billing *(v10.0 NEW)*
- `skills/02-business/auto-monetization.md` — Autonomous Monetization Engine: treasury, P&L, revenue optimization, passive income *(v10.0 NEW)*
- `skills/09-security/autonomy/bug-bounty-autonomy.md` — 24/7 autonomous bug-bounty hunter: self-sources public programs/VDPs, authorization gate, hunt→validate→report loop (tools: bounty_discovery.py, bounty_gate.py) *(v10.0 NEW)*
- `skills/09-security/offensive-redteam.md` — Offensive Security & Red-Team Ops: exploit dev, C2, post-exploitation, MITRE ATT&CK *(v10.0 NEW)*

### Hermes Crypto Agent (deep refs, loaded via H1-H7 dispatch)
- `skills/hermes/SKILL.md` — hermes principles + capability index
- `skills/hermes/DISPATCH.md` — bridge to v3 router, env var checklist, safety rails
- `skills/hermes/README.md` — install + dependency list
- `skills/hermes/references/wallets.md` — multi-chain wallet gen + import (EVM/Solana/Sui/Aptos/TON)
- `skills/hermes/references/swap.md` — 1inch + Jupiter + DEX router fallback
- `skills/hermes/references/nft.md` — Seaport / Blur / Reservoir / Magic Eden / Tensor
- `skills/hermes/references/sniping.md` — PairCreated listener + honeypot.is + GoPlus gate
- `skills/hermes/references/airdrop_automation.md` — multi-wallet runner + jitter + resume
- `skills/hermes/references/bridge.md` — LI.FI + Stargate + Across + native L1↔L2
- `skills/hermes/references/defi.md` — Aave V3 / Lido / GMX V2 / Hyperliquid / Pendle
- `skills/hermes/references/web3_connect.md` — SIWE / WalletConnect v2 / EIP-712 / EIP-1271 / ENS
- `skills/hermes/references/monitoring.md` — mempool + smart money + NFT whale + contract listener (12 sections)
- `skills/hermes/references/security.md` — encrypted vault (scrypt + Fernet)
- `skills/hermes/references/governor.md` — spend governor / circuit breaker *(v4.0)*
- `skills/hermes/references/browser.md` — Playwright dApp automation + governed signing *(v4.0)*
- `skills/hermes/references/contract_read.md` — universal multi-chain contract reader *(v4.0)*
- `skills/hermes/references/contract_write.md` — universal contract write, gated via governor *(v4.0)*
- `skills/hermes/references/deploy.md` — crypto dev: compile/test/deploy/verify, CREATE2 *(v4.0)*
- `skills/hermes/scripts/` — 10 Python templates (wallet_manager, swap_engine, nft_engine, bridge_engine, web3_connect, monitoring, monitoring_advanced, airdrop_runner, **governor**, **mev**, **browser_engine** *(v4.0)*)

### Meta
- `skills/01-meta/self-audit.md` — self-audit, system refinement
- `skills/01-meta/deep-strategy.md` — deep decomposition, strategy, pre-mortem
- `skills/01-meta/fault-diagnosis.md` — debug, error pattern library
- `skills/01-meta/self-improvement.md` — self-improvement & autonomous problem-solving + instinct extraction *(v4.0, v4.1)*
- `skills/01-meta/agentic-eval.md` — agentic eval, self-critique & variance testing *(v4.1)*
- `skills/01-meta/systematic-debug.md` — systematic debugging (4-phase RCA→Pattern→Hypothesis→Fix) + auto-debug loop *(v4.1)*
- `skills/01-meta/decision-support.md` — problem shaping, brainstorming sign-off, decision support w/ uncertainty *(v4.1)*

## Tools *(v4.0)*
- `tools/skill_integrity.py` — SHA-256 (+Ed25519) skill manifest generate/verify
- `tools/memory_engine.py` — compounding memory, keyless local recall *(v4.0)*
- `tools/reflection.py` — self-improvement loop: learn / auto-fix / gated proposals *(v4.0)*
- `tools/model_registry.py` — dynamic LLM model registry, encrypted keys, cascade *(v4.0, frozen)*
- `tools/planner.py` — NL workflow planner *(v4.0, frozen)*
- `tools/swarm.py` — multi-agent swarm orchestrator *(v4.0, frozen)*
- `tools/automation.py` — event-driven automation engine *(v4.0, frozen)*
- `tools/skill_forge.py` — self-extending skill proposals *(v4.0, frozen)*
- `tools/backtest.py` — strategy backtester *(v4.0)*
- `tools/dashboard.py` — live web dashboard generator *(v4.0)*
- `tools/voice.py` — voice conversation mode (STT→LLM→TTS) *(v4.0)*
- `tools/explain.py` — explainability / audit trail report *(v4.0)*
- `tools/briefing.py` — proactive daily briefing (composes memory/alerts/proposals) *(v4.0)*
- `tools/alerts.py` — conditional alert engine, persistent triggers + dedup *(v4.0)*
- `tools/watchdog.py` — self-healing process monitor, rate-limited restart *(v4.0, frozen)*
- `tools/vault.py` — snippet/address vault + macros *(v4.0, frozen)*
- `tools/multimodal.py` — voice transcription (Whisper) + screenshot vision *(v4.0)*
- `tools/triage.py` — inbox/notification triage & prioritization *(v4.0)*
- `tools/eval.py` — agentic eval, self-critique & variance testing *(v4.1)*
- `tools/humanizer.py` — AI-tell detector + deterministic rewriter + brand voice *(v4.1)*
- `tools/hids.py` — Mini-HIDS: log → detect → auto-firewall (allowlist+TTL) *(v4.1, frozen)*
- `tools/desktop_control.py` — macOS background control, no cursor steal *(v4.1, frozen)*
- `tools/scene_prep.py` — USD scene assembly + ComfyUI graph patch *(v4.1)*
- `tools/skill_market.py` — skills.sh marketplace → quarantine (audit before activate) *(v4.1, frozen)*
- `tools/mcp_builder.py` — scaffold MCP server (Python/TS) + prompt auditor *(v4.1)*
- `tools/prd.py` — To-PRD / To-Issues structurer *(v4.1)*
- `tools/research_q.py` — deep research dispatcher (AI-Q style, cited) *(v4.1)*
- `tools/content.py` — social content scaffolder: calendar, platform-adapt, thread/carousel/reels, repurpose *(v4.1)*
- `tools/revenue_engine.py` — bulk job runner: token-bucket rate limit, retry/backoff, checkpoint-resume, dedupe *(v4.1.2)*
- `tools/api_harvester.py` — API-first harvest: offset/cursor pagination, JSON-path extract, cURL→RequestSpec, JSONL/CSV writers *(v4.1.2)*
- `tools/cost_ledger.py` — unified cost/usage ledger: LLM tokens + on-chain USD + API calls, per-provider/chain summary *(v4.2)*
- `tools/router_log.py` — router decision log + tie detection → keyword disambiguation tuner *(v4.2)*
- `tools/secret_tripwire.py` — output-layer secret redaction (priv key/mnemonic/API key/JWT/PEM), strict guard *(v4.2)*
- `tools/dryrun.py` — global dry-run/simulation mode (contextvars), engines plan instead of broadcast *(v4.2)*
- `tools/eligibility.py` — airdrop eligibility scorer 0-100 + gaps + flags, override-able rubric *(v4.2, airdrop-intel)*
- `tools/sybil_audit.py` — sybil-resistance self-audit across own wallets + de-correlation advice *(v4.2, airdrop-intel)*
- `tools/claim_watcher.py` — airdrop calendar & claim-window watcher (time injected, fire-once alerts) *(v4.2, airdrop-intel)*
- `tools/exit_planner.py` — post-airdrop exit ladder (conservative/balanced/degen), governor-routed *(v4.2, airdrop-intel)*
- `tools/rugcheck.py` — rug/legitimacy pre-check → SAFE/CAUTION/DANGER verdict, signals delegated *(v4.2, security-audit)*
- `tools/ctf.py` — CTF/whitehat toolkit: triage, multi-decode, caesar/xor, hash-id *(v4.2, ctf-toolkit)*
- `tools/eval.py` — +RegressionSuite: golden-set regression across releases *(v4.2)*
- `tools/alpha_radar.py` — pre-TGE project scorer 0-100 + tier (cold/watch/warm/hot), token-exists cap *(v4.2, alpha-radar)*
- `tools/farm_roi.py` — farming position EV/ROI evaluator + portfolio ranking keep/trim/drop *(v4.2, farm-roi)*
- `tools/guide_studio.py` — airdrop guide builder ID: full MD + TG/X variants + referral + screenshot jobs *(v4.2, guide-studio)*
- `tools/unlock_engine.py` — unlock/vesting calendar + sell-pressure ratio vs daily volume, time injected *(v4.2, tokenomics-unlock)*
- `tools/scam_sentinel.py` — typosquat (levenshtein) + page-signal risk scorer + warning post draft, read-only *(v4.2, anti-scam-sentinel)*
- `tools/contract_watch.py` — contract snapshot differ: proxy/claim-address/admin/code-hash/sensitive-funcs → safe_to_claim *(v4.2, contract-watcher)*
- `tools/community_intel.py` — community message analytics: topics, trending questions, sentiment, FUD, content ideas *(v4.2, community-intel)*
- `tools/repurpose.py` — one source → X thread / Telegram / IG carousel / TikTok / YouTube scripts *(v4.2, omni-repurpose)*
- `tools/video_pipeline.py` — video brief → timed script + storyboard + voiceover lines + SRT *(v4.2, video-pipeline)*
- `tools/hook_lab.py` — hook generator + deterministic stop-scroll score 0-100 + ranking *(v4.2, hook-ab-lab)*
- `tools/ctf/` — CTF Swarm framework *(v4.2, ctf-toolkit/ctf-web-exploit–ctf-llm-redteam)*:
  - `scope_guard.py` — authorization allowlist (whitehat line, deny wins), offline
  - `flag_validator.py` — strict full-match flag check + placeholder blocklist (anti-hallucination)
  - `rsa_attacks.py` — offline RSA attacks (small-e/Fermat/Wiener/common-modulus), gmpy2-optional
  - `coordinator/` — full-auto runtime: CTFd poll → model swarm (consensus-aware) → Docker sandbox → HITL/auto submit
  - `templates/` — pwntools + angr solver skeletons · `sandbox/Dockerfile.sandbox` — isolated toolchain
  - `gandalf_solver.py` — host-locked LLM red-team solver for Gandalf (static + adaptive modes), ctf-llm-redteam
  - `run.py` — entrypoint (run | status | approve) · `README.md` — package guide
- `SKILLS.lock` — integrity manifest (v10.0, 241 files), verified at boot

### V10 New Tools
- `tools/team_routing.py` — team hierarchy routing (Level 0-3), task assignment, conflict detection *(v10.0 NEW)*
- `tools/treasury.py` — treasury management, P&L ledger, revenue stream tracker *(v10.0 NEW)*
- `tools/revenue_optimizer.py` — autonomous monetization strategies optimizer *(v10.0 NEW)*
- `tools/exploit_builder.py` — exploit development lifecycle, payload gen, C2 designer *(v10.0 NEW)*
- `tools/opsec_checker.py` — operational security validation, MITRE ATT&CK mapping *(v10.0 NEW)*

## Memory
- `memory/YYYY-MM.md` — monthly rolling log

---

## V10 Rename Map (old sk-ID → new descriptive name)

| Old | New | Old | New |
|-----|-----|-----|-----|
| sk0 | skill-registry | sk30 | client-revenue |
| sk1 | monetization | sk31 | airdrop-intel |
| sk2 | infra-deploy | sk32 | ctf-toolkit |
| sk3 | content-creation | sk33 | alpha-radar |
| sk4 | bots-automation | sk34 | farm-roi |
| sk5 | data-insight | sk35 | guide-studio |
| sk6 | api-integration | sk36 | tokenomics-unlock |
| sk7 | ai-builder | sk37 | anti-scam-sentinel |
| sk8 | file-production | sk38 | contract-watcher |
| sk9 | interface-builder | sk39 | community-intel |
| sk10 | web3-ops | sk40 | omni-repurpose |
| sk11 | security-audit | sk41 | video-pipeline |
| sk12 | batch-parallel | sk42 | hook-ab-lab |
| sk13 | nft-minter | sk43 | ctf-web-exploit |
| sk14 | daily-briefing | sk44 | ctf-pwn |
| sk15 | daily-watchdog | sk45 | ctf-reverse |
| sk16 | software-engineering | sk46 | ctf-crypto |
| sk17 | power-planner-swarm | sk47 | ctf-forensics |
| sk18 | creative-media | sk48 | ctf-llm-redteam |
| sk19 | desktop-control | sk49 | team-orchestration |
| sk20 | humanizer-voice | sk50 | auto-monetization |
| sk21 | enterprise-defense | sk51 | offensive-redteam |
| sk22 | scientific-research | sk52 | self-audit |
| sk23 | executive-function | sk53 | deep-strategy |
| sk24 | mcp-prompt-eng | sk54 | fault-diagnosis |
| sk25 | compliance-cicd | sk55 | self-improvement |
| sk26 | product-spec | sk56 | agentic-eval |
| sk27 | content-strategy | sk57 | systematic-debug |
| sk28 | copywriting-mastery | sk58 | decision-support |
| sk29 | content-analytics | sk59 | ai-gateway-pool |

**Removed (legacy v4.2 duplicates):** `m0, m3, m14, m15, m27, m28, m29, m32, m43–m48, x1–x7` — merged into the descriptive skills above.

## Per-category navigation
Each `skills/<NN-category>/` folder has its own `README.md` listing its skills + trigger keywords.
See `STRUCTURE.md` for the folder map.

## Bug-Bounty Hunting sub-pack
- `skills/09-security/` — 57 from-scratch hunting playbooks (recon · web · api · auth · mobile · reverse-engineering · exploit-dev · cloud-infra · web3 · reporting · core) + `phases/` `payloads/` `checklists/` `references/` `commands/` `FLOWMAP.md`. Driven by `skills/09-security/autonomy/bug-bounty-autonomy.md`. Index: `skills/09-security/README.md`. *(v10.0 NEW)*
