# SUPERAGENT V10 IRONCLAW 🔥

> 📖 **Baru di sini? Baca [`WHY-V10.md`](WHY-V10.md)** — intro, keunggulan, dan apa yang bikin V10 beda.

> 🚀 **Setup & demo:** `./install.sh` then `./demo.sh` — see `RELEASE.md` for the full release & demo guide.
>
> ▶️ **See it work in 10 seconds:** `./demo.sh` — runs the router, legal gate, autonomous loop, and hunt-planner live (offline, zero target contact).

**Sovereign Autonomous Agent Framework** — 158 skills (descriptive-named), 76 runnable tools, 458 tests, production-grade.

## Quick Start

```bash
unzip SUPERAGENT-V10.zip && cd SUPERAGENT-V10
./install.sh          # checks Python, verifies integrity, runs 458 tests
./demo.sh             # live showcase (router, gate, autopilot, hunt-plan)
```

Core needs only **Python 3.8+** (standard library). Optional crypto/web3 tools use `pip install` where flagged. New here? Read [`WHY-V10.md`](WHY-V10.md) → [`GUIDE.md`](GUIDE.md) → [`BUGBOUNTY-GUIDE.md`](BUGBOUNTY-GUIDE.md).

## CLI Commands

```bash
superagent scan                    # Run revenue engine scan
superagent auth <challenge> <sig> # Verify team auth signature
superagent bridge status          # HermesBridge cross-chain status
superagent treasury [daily|weekly|monthly]  # P&L cost ledger report
superagent deploy-gateway         # Gateway manager deployment
superagent dashboard [--serve PORT]  # Live web dashboard
superagent eval <label>           # Agentic eval suite
superagent watchdog tick          # Self-healing watchdog check
superagent reflection cycle       # Self-improvement reflection
superagent triage                 # Inbox notification triage
superagent integrity verify       # Skill integrity checks
superagent model list|add|remove  # LLM model registry
superagent upgrade <zip> [--dry-run]  # Version upgrade
superagent version                # Version + tool summary
```

## Architecture

- **158 Skills** — On-demand modules for crypto, DevOps, content, automation, CTF, and more
- **76 Tools** — Core engine: revenue, cost ledger, reflection, eval, watchdog, swarm, model registry
- **Hermes Runtime** — Multi-chain Web3 ops: swap, bridge, DeFi, NFT, MEV
- **Zero Required Deps** — Core runs on Python stdlib; optional extras for crypto/web3

## License

Commercial license — single-buyer use. See LICENSE. Redistribution/resale of source prohibited without written permission.

## Architecture
See `docs/ARCHITECTURE.md` for the full design reference and `FLOWMAP.md` for the live flow.
