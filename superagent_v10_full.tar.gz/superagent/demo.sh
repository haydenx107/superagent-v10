#!/usr/bin/env bash
# demo.sh — SUPERAGENT V10 live showcase (zero external deps, offline, safe)
# Run this in front of anyone. It proves the whole system actually works.
#   ./demo.sh
set -euo pipefail
cd "$(dirname "$0")"

bold()  { printf "\033[1m%s\033[0m\n" "$*"; }
cyan()  { printf "\033[36m%s\033[0m\n" "$*"; }
green() { printf "\033[32m%s\033[0m\n" "$*"; }
rule()  { printf "\033[90m%s\033[0m\n" "────────────────────────────────────────────────────────────"; }
pause() { sleep "${DEMO_SLEEP:-0.6}"; }

clear 2>/dev/null || true
bold "⚡ SUPERAGENT V10 IRONCLAW — LIVE DEMO"
cyan  "   One agent · 124 skills · autonomous engine · legal gate · all runnable"
rule; pause

# ── 1. Health check ────────────────────────────────────────────────
bold "① HEALTH CHECK  —  python3 tools/selfcheck.py"
rule; python3 tools/selfcheck.py; pause; echo

# ── 2. Smart router (keyword → skill) ──────────────────────────────
bold "② SMART ROUTER  —  it picks the right skill from plain language"
rule
for q in "audit this smart contract for a rug pull" \
         "bikin telegram bot ambil airdrop dari API terus auto-post" \
         "idor on the api endpoint" \
         "deploy nginx on my VPS" \
         "write a viral twitter thread"; do
  cyan "  > $q"
  python3 tools/skill_router.py "$q" | sed 's/^/    /'
  pause
done
echo

# ── 3. Authorization gate (safety) ─────────────────────────────────
bold "③ AUTHORIZATION GATE  —  no testing without public + in-scope proof"
rule; python3 tools/bounty_gate.py demo | python3 -c '
import json,sys
for r in json.load(sys.stdin):
    icon = {"PASS":"🟢","HUMAN_CONFIRM":"🟡","FAIL":"🔴"}.get(r["decision"],"")
    pid=r["id"]; dec=r["decision"]; why=r["reasons"][0]
    print("    %s %-20s %-14s — %s" % (icon, pid, dec, why))'
pause; echo

# ── 4. Autonomous tick (discover→qualify→gate→plan) ────────────────
bold "④ AUTONOMOUS LOOP  —  one tick, strict mode (safe by default)"
rule; python3 tools/autopilot.py tick --demo --gate-mode strict --no-memory | python3 -c '
import json,sys; r=json.load(sys.stdin)
print("    counts         :", r["counts"])
print("    engaged (test) :", r["engaged_this_tick"], " <- strict = 0, awaiting human-confirm")
print("    needs_confirm  :", r["needs_confirm"])
print("    posture        :", r["posture"])'
pause; echo

# ── 5. Hunt plan (what it would actually test) ─────────────────────
bold "⑤ HUNT PLAN  —  auto mode maps scope → exact playbooks"
rule; python3 tools/hunt_orchestrator.py demo --gate-mode auto | python3 -c '
import json,sys; r=json.load(sys.stdin)
for a in r["authorized"]:
    print("    program %s (score %s) -> plan:" % (a["id"], a["score"]))
    for p in a["hunt_plan"]["playbooks"]:
        print("        - " + p)'
pause; echo

rule
green "✅ DEMO COMPLETE — router, gate, autonomy, and hunt-planning all ran live."
cyan  "   Everything above executed offline, deterministically, with zero target contact."
echo
