# Panduan Operator — Hermes + SUPERAGENT v10.0 IRONCLAW SUPREME

Cara ngomong sama Hermes setelah v10.0 OPENCLAW EDITION + hermes-crypto-agent ke-combo.
*Update v4.2 (2026-06-09): Airdrop Intelligence (airdrop-intel), CTF/Whitehat (ctf-toolkit), + observability & safety tooling.*

---

## Daftar Isi

**Operasi crypto (Hermes runtime)**

1\. [Mode default vs mode cepat](#mode-default-vs-mode-cepat)  
2\. [Mint NFT](#mint-nft)  
3\. [Swap token](#swap-token)  
4\. [Bridge cross-chain](#bridge-cross-chain)  
5\. [Sniping token launch](#sniping-token-launch)  
6\. [Airdrop farming multi-wallet](#airdrop-farming-multi-wallet)  
7\. [Mempool watch (anti-drainer)](#mempool-watch-anti-drainer)  
8\. [Beli NFT di marketplace](#beli-nft-di-marketplace)  
9\. [Whale & smart-money tracker](#whale--smart-money-tracker)

**Airdrop Intelligence & Whitehat — BARU di v10.0**

10\. [Airdrop Intelligence (airdrop-intel)](#airdrop-intelligence-airdrop-intel--baru-v42)  
11\. [CTF / Whitehat toolkit (ctf-toolkit)](#ctf--whitehat-toolkit-ctf-toolkit--baru-v42)  
12\. [CTF Swarm full-auto (ctf-toolkit → ctf-web-exploit–ctf-llm-redteam)](#ctf-swarm-full-auto-ctf-toolkit-ctf-web-exploitctf-llm-redteam-update-v42)  
13\. [Rug & legitimacy check](#rug--legitimacy-check--baru-v42)  
14\. [Observability & safety baru](#observability--safety-baru--v42)

**Growth & Protection — alpha-radar–hook-ab-lab (update v4.2, 12 Jun)**

15\. [Alpha & farming intelligence (alpha-radar · farm-roi · tokenomics-unlock)](#alpha--farming-intelligence-alpha-radar--farm-roi--tokenomics-unlock--update-v42)  
16\. [Proteksi komunitas (anti-scam-sentinel · contract-watcher)](#proteksi-komunitas-anti-scam-sentinel--contract-watcher--update-v42)  
17\. [Mesin konten & komunitas (guide-studio · community-intel–hook-ab-lab)](#mesin-konten-komunitas-guide-studio-community-intelhook-ab-lab-update-v42)

**Sesi & ops**

18\. [Session control commands](#session-control-commands)  
19\. [Background job persistence](#background-job-persistence)

**Skill non-crypto & referensi**

20\. [Skill non-crypto (v10.0) — contoh ngomong](#skill-non-crypto-v41--contoh-ngomong)  
21\. [Cheat sheet — natural language ke skill route](#cheat-sheet--natural-language-ke-skill-route)  
22\. [Yang perlu Operator siapin sebelum mulai](#yang-perlu-operator-siapin-sebelum-mulai)  
23\. [Cara cepat verify](#cara-cepat-verify-v42--hermes-udah-jalan)

---

## Mode default vs mode cepat

Hermes punya 2 mode operasi. Default = aman, mode cepat = fire and forget.

### Default — confirm before signing
Tiap tx penting dapat plan ringkas + gate `(y/n)`. Cocok buat:
- Tx pertama di sesi baru
- Wallet utama / dana besar
- Operasi yang belum pernah Operator lakuin sebelumnya
- Kontrak yang belum diaudit

### Mode cepat — `auto_confirm on`
Skip prompt per tx. Tx pertama tetap dapat 1-line summary (info only, bukan gate). Cocok buat:
- Batch ops (mass mint, multi-wallet farming)
- Wallet kecil / test wallet
- Operasi rutin yang udah biasa
- Sniping di mana speed penting

```
Operator: auto_confirm on
Hermes: [AUTO_CONFIRM] ON. tx akan fire tanpa gate sampai sesi ini berakhir atau lo set off.

Operator: auto_confirm off
Hermes: [AUTO_CONFIRM] OFF. balik ke mode safe.
```

Operational rails yang TETAP nyala walau auto_confirm on:
- Secret hygiene (gak pernah log priv key)
- Simulate before broadcast
- Drainer/scam code detection
- User-funds-only

---

## Mint NFT

### Single mint dari URL
```
Operator: mint NFT https://opensea.io/assets/base/0xABC.../1
```

Hermes auto:
- Parse URL → chain `base`, contract `0xABC...`
- Probe mint function (publicMint, mint, claim, dst)
- Detect price via `mintPrice()` / Seadrop config
- Auto-gas (estimate + buffer)
- Simulate → send → wait → report

Output:
```
[TARGET] 0xABC... on base × 1
[FN]     mintPublic(uint256) — detected
[PRICE]  0.0014 ETH
[GAS]    180k @ 0.05 gwei  →  ~$0.02
[SENT]   0xtxhash...
[OK]     block 12345678  gasUsed 142,330
[VIEW]   https://basescan.org/tx/0xtxhash...
```

### Mass mint pakai N wallet
```
Operator: auto_confirm on. mint https://opensea.io/assets/base/0xABC.../1 pakai 50 wallet
```

Output:
```
[BATCH MINT] 50 wallets × NFT 0xABC... on base
est total cost: 0.0070 ETH (50 × 0.0001 mint fee)
concurrency: 5
[SENDING]

[3/50]   0xAbC...d4F1   ✅ 0xtx1...
[7/50]   0xDeF...c2A3   ✅ 0xtx2...
[12/50]  0x123...8F9    ❌ AlreadyMinted
...
[DONE]   47/50 ok, 3 failed → mint-1748150400.json
```

### Mint Manifold / Zora
Sama, paste URL langsung:
```
Operator: mint https://app.manifold.xyz/c/12345
Operator: mint https://zora.co/collect/base:0xABC.../1
```

Hermes pakai protocol-specific handler (Manifold instanceId fetch, Zora 1155 protocol fee).

---

## Swap token

### Swap simple
```
Operator: swap 0.5 ETH ke USDC di base, pakai wallet pertama
```

Plan:
```
[PLAN]
chain:    base
wallet:   0xAbC...d4F1 (wallet#1)
action:   swap 0.5 ETH → USDC (via 1inch)
slippage: 1%
est out:  ~1,847 USDC
gas:      ~$0.02

Lanjut? (y/n)
```

`y` → fire. Tx hash + explorer link.

### Sell semua holding token
```
Operator: sell semua $PEPE di wallet#1, ke USDC
```

Hermes:
- Cek balance PEPE di wallet
- Quote via 1inch
- Tampilkan plan
- Execute (kalau approve belum ada, approve dulu otomatis)

### Swap via DEX aggregator pilihan
```
Operator: swap 1000 USDC ke ETH di arbitrum via jupiter
```
(Jupiter buat Solana. Untuk EVM, default 1inch — Hermes auto-koreksi.)

---

## Bridge cross-chain

### Bridge simple
```
Operator: bridge 500 USDC dari arbitrum ke base pakai stargate
```

Plan:
```
[BRIDGE PLAN]
from:    arbitrum  → 500 USDC
to:      base      → 499.32 USDC (after fees)
route:   Stargate V2
fee:     0.68 USDC
eta:     ~2 menit
gas:     ~$0.30
bonus:   eligible LayerZero points

Lanjut? (y/n)
```

`y` → execute → wait sampai landed di destination chain → confirm.

### Bridge dengan route otomatis (LI.FI)
```
Operator: bridge 0.1 ETH dari eth ke base, route paling murah
```

Hermes pakai LI.FI aggregator, pilih route optimal otomatis (Across / Stargate / native / Hop — mana yang termurah).

### Bridge ke non-EVM (Solana via Mayan)
```
Operator: bridge 100 USDC dari base ke solana
```

Hermes pakai Wormhole + Mayan untuk EVM ↔ Solana. Wallet Solana harus udah ke-import di vault.

---

## Sniping token launch

### Setup sniper
```
Operator: snipe token baru di base, budget 0.05 ETH per launch, max 3 launch hari ini
```

Output:
```
[SNIPER ACTIVE] base / Uniswap V3 PairCreated
filter:   WETH pair only
budget:   0.05 ETH / launch
max:      3 launches today
safety:   honeypot.is + GoPlus required
wallet:   0xAbC...d4F1
[LISTENING...]

pm2: sniper-base (id 2)
log: pm2 logs sniper-base
```

Saat pair baru terdeteksi:
```
[DETECTED] 0xNew...Token, paired with WETH at block 12345678
[SAFETY]   honeypot.is: clean | GoPlus: 1 warning (mintable)
⚠️ mintable token (owner bisa inflate supply). Lanjut snipe? (y/n)
```

`auto_confirm on` → auto-block kalau CRITICAL flag, auto-proceed kalau cuma WARN.
`auto_confirm off` → tanya per detection.

### Snipe NFT mint launch
```
Operator: snipe mint NFT collection https://opensea.io/collection/<slug>, watch dari sekarang sampai mint open
```

Hermes pantau status drop (read `getPublicDrop()` Seadrop config), fire mint detik mint window buka.

### Stop sniper
```
Operator: stop sniper-base
```

---

## Airdrop farming multi-wallet

### LayerZero farming
```
Operator: layerzero farming, 50 wallet, bridge variasi route 5 chain selama 7 hari
```

Sybil reminder (sekali per session):
```
⚠️ LayerZero punya deteksi sybil bisa blacklist semua wallet terkait.
Gua randomize timing (5-180 menit) + amount jitter (±15%) + variasi bridge per wallet.
Tetap ada risk. Lanjut? (y/n)
```

`y`:
```
[FARMING PLAN]
wallets:   50
chains:    eth, arb, base, op, polygon (5 chains)
tx/wallet: 14-21 (random)
duration:  7 days
total tx:  ~875 (estimasi)
est cost:  ~$45 total gas

[STARTED] background runner: pm2 lz-farming
[CHECK]   pm2 logs lz-farming
[STOP]    "stop lz-farming"
```

### zkSync / Linea farming pattern sama
```
Operator: zksync farming, 30 wallet, daily activity selama 14 hari
Operator: linea voyage tasks pakai 25 wallet
```

### Daily check-in airdrop
```
Operator: daily check-in airdrop X pakai semua wallet, jam 8 pagi WIB
```

Hermes setup cron job, jalan otomatis tiap hari.

---

## Mempool watch (anti-drainer)

### Setup watcher
```
Operator: pantau wallet gua 0xAbC...d4F1 dari approve mencurigakan, alert ke TG
```

Output:
```
[WATCHER ACTIVE]
target:   0xAbC...d4F1
chains:   ethereum, base, arbitrum
triggers: approve(), setApprovalForAll(), permit()
alert:    @your_alerts_channel channel
filter:   spender harus contract verified, kalau gak → CRITICAL

running as pm2: anti-drainer (id 3)
```

Saat detect approval mencurigakan di mempool (sebelum confirmed):
```
🚨 CRITICAL APPROVAL DETECTED 🚨
wallet:   0xAbC...d4F1
action:   setApprovalForAll(0xSpender..., true)
spender:  0xSus...Address (no verified contract)
tx:       0xpending...

STATUS: pending in mempool (~12s before confirm)
ACTION: kalau ini bukan elo, kirim front-run tx revoke SEKARANG
        "revoke approval 0xSus... di wallet#1"
```

### Auto-revoke mode
```
Operator: anti-drainer auto-revoke mode on untuk wallet#1
```

Kalau Hermes detect approval ke contract non-whitelist → otomatis broadcast revoke tx dengan gas lebih tinggi, race-condition dengan drainer.

---

## Beli NFT di marketplace

### OpenSea specific listing
```
Operator: beli BAYC #1234 di opensea, max 25 ETH
```

Plan:
```
[LISTING FOUND]
collection: BAYC
token id:   #1234
price:      22.5 ETH (di bawah max)
seller:     0xSeller...
protocol:   Seaport 1.6
gas:        ~$8

Lanjut? (y/n)
```

### Floor sweep
```
Operator: sweep floor Pudgy Penguins, 5 unit, max avg 10 ETH per piece
```

Hermes pakai Reservoir aggregator (cek listing terendah cross-marketplace: OpenSea, Blur, LooksRare). Bulk fulfill dalam 1 tx kalau bisa.

### List NFT buat dijual
```
Operator: list NFT #5678 dari koleksi 0xMy... di opensea, harga 1.5 ETH, expire 7 hari
```

Hermes sign EIP-712 Seaport order → post ke OpenSea API. Listing live di marketplace.

### Magic Eden / Tensor (Solana)
```
Operator: beli SMB #1234 di magic eden, max 50 SOL
```

Sama flow-nya, beda protocol (Magic Eden ME instruction, bukan Seaport).

---

## Whale & smart-money tracker

### Track wallet whale + alert TG
```
Operator: tracker smart money via nansen, alert ke TG kalau ada buy > $50k
```

Output:
```
[TRACKER ACTIVE]
source:   Nansen Smart Money label
filter:   buy size > $50k
chains:   ethereum, base, arbitrum, solana
alert:    @your_alerts_channel

pm2: smart-money-watch (id 4)
```

Alert format:
```
🐋 SMART MONEY BUY
wallet:   0xWhale... (Nansen: "Smart Trader")
action:   bought 12.5 ETH worth of $TOKEN
chain:    base
contract: 0xToken...
tx:       https://basescan.org/tx/...
```

### Copy-trade pattern
```
Operator: copy-trade wallet 0xWhale..., ukuran 5% dari ukuran mereka, max $500 per trade
```

Hermes monitor whale wallet → mirror buy ukuran kecil di wallet Operator, filter stablecoin transfer dan low-value noise.

### NFT whale alert
```
Operator: alert kalau ada whale beli NFT > 10 ETH di koleksi blue chip
```

Hermes pakai Reservoir WebSocket stream — push notif real-time.

### Floor drop alert
```
Operator: alert kalau floor BAYC drop > 5% dalam 1 jam
```

---

## Airdrop Intelligence (airdrop-intel) — BARU v4.2

Skill khusus AirdropFinder: ubah siklus airdrop jadi keputusan ber-angka. Semua tool **offline & deterministik** — data on-chain diambil dulu lewat web3-ops/hermes, airdrop-intel yang nge-judge & nyusun rencana. Fund movement (claim/exit) tetap lewat Spend Governor.

### 1. Eligibility scorer — wallet ini layak gak?
```
Operator: skor eligibility wallet 0xAbC...d4F1 buat airdrop Linea
```

Output:
```
[ELIGIBILITY] 0xAbC...d4F1 — Linea
score:   72/100  (TIER: likely)
✅ kuat:   age 210d, 47 tx, bridged 3x, 4 unique contracts
⚠️ gap:    volume $1.2k (target >$5k), belum interaksi DeFi native
🚩 flag:   gas spend rendah (bot-like? cek manual)
saran:    + 2-3 swap di native DEX, + 1 LP position → proyeksi ~85/100
```

Rubric bisa di-override per-project (kalau Operator tau kriteria spesifik proyeknya):
```
Operator: skor wallet#1 buat ZkSync, bobot: volume 40%, age 20%, kontrak unik 40%
```

### 2. Sybil self-audit — wallet farm gua aman gak?
Ini **jaring keselamatan buat wallet Operator sendiri** — cek apakah pola antar-wallet gampang ke-cluster sama sybil filter, biar bisa di-de-correlate. Bukan buat ngecoh proyek.
```
Operator: sybil audit 50 wallet farming gua
```

Output:
```
[SYBIL AUDIT] 50 wallets
risk: HIGH ⚠️
korelasi terdeteksi:
  • funding: 38 wallet didanai dari 1 sumber (0xFund...) — RED
  • timing: 22 wallet tx dalam window 5 menit yang sama — RED
  • gas pattern: amount identik di 41 wallet — YELLOW
  • contract overlap: semua wallet sentuh kontrak yang sama urut sama
saran de-correlation:
  1. Variasikan funding source (pakai CEX withdrawal beda-beda)
  2. Sebar timing (randomize 1-72 jam, jangan batch)
  3. Variasikan urutan & jenis interaksi per wallet
  4. Amount jitter ±15-30%
```

### 3. Claim-window calendar — jangan kelewat claim
`now` selalu di-inject (gak pernah nebak waktu). Alert fire-once di H-48 / H-2 / H-0.
```
Operator: tambah ke kalender airdrop: ZK claim buka 17 Jun 14:00 WIB, tutup 24 Jun
Operator: airdrop apa aja yang claim window-nya minggu ini?
```

Output:
```
[CLAIM CALENDAR] minggu ini (12-18 Jun)
🔔 ZK        — buka 17 Jun 14:00 WIB (H-5)   [alert set: H-48, H-2, H-0]
🔔 LayerZero — tutup 15 Jun 23:59 WIB (H-3)  ⚠️ belum claim di 12 wallet!
✅ Scroll    — udah di-claim semua wallet
```

### 4. Exit planner — kapan & gimana jual
```
Operator: exit plan buat 5000 $ZK, profil balanced, likuiditas tipis
```

Output:
```
[EXIT LADDER] 5000 $ZK — profil: balanced
likuiditas DEX tipis → split sell biar gak slippage parah
  • TGE +0h:   sell 30% (1500) — amankan modal
  • +24h:      sell 25% (1250) — kalau harga > TGE
  • +7d:       sell 25% (1250) — atau cut kalau dump
  • hold 20%:  moonbag (1000)
⚠️ vesting: cek dulu, kalau ada cliff sebagian sell-nya geser
eksekusi via Spend Governor (gate per leg, atau auto_confirm on)
Lanjut setup auto-sell ladder? (y/n)
```

---

## CTF / Whitehat toolkit (ctf-toolkit) — BARU v4.2

Buat Operator yang ikut CTF & bug bounty buat reward. **Legal & in-scope only** — target asing kena gate R9 (⚠️ izin? y/n), default tahan. Tool inti stdlib-only & pasif (decode/analisis); exploit aktif tetap manual + izin.

### Triage soal — ini kategori apa, serang dari mana
```
Operator: triage soal CTF: "diberikan RSA public key dengan e kecil, decrypt flag"
```
```
[TRIAGE] kategori: crypto (confidence tinggi)
arah:    RSA small-e → coba cube-root attack (e=3, no padding)
tooling: ctf-toolkit (math manual), atau sage kalau ada
```

### Decode berlapis otomatis
```
Operator: decode ini: NHZ4dnRoaXNfaXNfYmFzZTY0X2ZsYWc=
```
```
[DECODE] kupas berlapis (diurut printability):
  base64 → "4vxvthis_is_base64_flag"
  ...cek flag pattern: NAME{...}
🚩 ketemu: flag{...}
```

### Classic crypto
```
Operator: caesar bruteforce "Frperg Zrffntr"
Operator: xor single byte cari key buat hex ini: 1c0111001f...
```
26 shift / 256 key sekaligus, di-rank by englishness.

### Hash & misc
```
Operator: ini hash tipe apa: 5f4dcc3b5aa765d61d8327deb882cf99
```
```
[HASH-ID] panjang 32 hex → kandidat: MD5, NTLM, MD4
```

Recon kategori lain (web/pwn/forensics) → ctf-toolkit ngarahin ke tooling + delegasi ke security-audit (audit) / api-integration (httpx, in-scope). Mau auto-generate writeup PDF tiap flag ketemu? combo ctf-toolkit + file-production.

---

## CTF Swarm full-auto (ctf-toolkit → ctf-web-exploit–ctf-llm-redteam) — update v4.2

Naik level dari toolkit pasif: **framework CTF full-auto whitehat** di `tools/ctf/`. ctf-toolkit jadi orchestrator yang triage → cek scope → dispatch ke sub-skill kategori → validasi flag → submit. Cocok buat event CTFd dengan banyak soal sekaligus.

### Sub-skill kategori (otomatis dipilih ctf-toolkit)
| Soal | Skill |
|---|---|
| web app / URL / HTTP | **ctf-web-exploit** (SQLi, SSTI, SSRF, IDOR, JWT, deserialization) |
| binary + `nc host port` | **ctf-pwn** (ret2win, ret2libc, format string, heap, ROP) |
| binary "what does it do" | **ctf-reverse** (angr, Ghidra, radare2, keygen) |
| ciphertext / RSA / key | **ctf-crypto** (RSA attacks, block cipher, PRNG — `rsa_attacks.py`) |
| pcap / memory / image / zip | **ctf-forensics** (volatility, binwalk, stego, carving) |
| LLM / AI / jailbreak / Gandalf | **ctf-llm-redteam** (prompt-injection / LLM red-team) |

### Mode 1 — manual per soal (aman, default)
```
Operator: ini soal web, target https://chal.ctf.example/01, ada login form
```
ctf-toolkit konfirmasi scope (lihat `scope.json`) → load ctf-web-exploit → kasih playbook + script recon. Flag yang ketemu **wajib** lewat `flag_validator.py`, lalu Operator yang approve submit.

### Mode 2 — full-auto swarm (banyak soal, butuh setup)
```bash
cd tools/ctf
cp .env.example .env            # isi CTFD_URL, CTFD_TOKEN, API key per provider, MODELS (ID asli!)
cp scope.example.json scope.json # set host yang BOLEH diserang (event ini aja)
docker build -f sandbox/Dockerfile.sandbox -t ctf-sandbox .

python3 run.py          # poll CTFd → race model per soal di sandbox → solve
python3 run.py status   # lihat progress per soal
python3 run.py approve  # submit flag yang antri (kalau HITL_SUBMIT=true)
```
Tiap soal di-race beberapa model paralel di **Docker sandbox terisolasi** (default `--network none`). Lineup model bebas lintas-provider — adapter **Anthropic, OpenAI, Gemini** lengkap (`MODELS=anthropic:...,openai:...,gemini:...`, isi API key provider yang dipakai). Flag pertama yang valid menang; di mode tanpa pendamping, butuh `AUTO_SUBMIT_CONSENSUS` model setuju baru auto-submit.

### Mode 3 — LLM red-team / Gandalf (ctf-llm-redteam)
Buat soal kategori AI/LLM (Gandalf-style: peras password dari LLM tanpa kena guard). Solver **host-locked ke gandalf.lakera.ai** (nolak host lain).
```bash
cd tools/ctf
python3 gandalf_solver.py --start 1 --end 7      # static: coba ladder strategi tiap level
python3 gandalf_solver.py --adaptive --model anthropic:claude-opus-4-1   # attacker-LLM (bisa juga openai:.../gemini:..., isi API key-nya)
```
Idenya: input guard periksa prompt *kamu* (lawan: parafrase intent), output guard periksa jawaban *model* (lawan: jangan emit secret literal → encode/acrostic/eja). Detail teknik & defense ladder L1–L8 ada di `skills/09-security/ctf-llm-redteam.md`. ⚠️ API contract Gandalf gak resmi — verify dulu di DevTools sebelum jalan.

### Pengaman (kenapa ini tetap whitehat)
- **`scope_guard.py`** — cuma host di allowlist yang boleh disentuh; aturan deny menang. Out-of-scope = ditolak.
- **Sandbox** — binary soal cuma jalan di dalam Docker, default tanpa network.
- **`flag_validator.py`** — flag wajib full-match + lolos blocklist placeholder; flag diambil dari output target, **gak pernah dikarang**.
- **HITL default** — `HITL_SUBMIT=true` → flag nunggu approve Operator. Sejalan sama gate R9 ctf-toolkit.

Detail teknis: `tools/ctf/README.md`. Catatan review paket asli: `REVIEW.md`.

---

## Rug & legitimacy check — BARU v4.2

Satu command → verdict jelas. Sinyal mentah (honeypot/tax/verifikasi/holder/LP) diambil dari H4 + web3-ops, `rugcheck` yang nge-judge jadi keputusan + nampilin yang *belum* dicek (jangan diabaikan).
```
Operator: rugcheck token 0xToken... di base
```
```
[RUGCHECK] 0xToken... on base  →  ⚠️ CAUTION
🛑 critical:  (none)
⚠️ warnings:  sell-tax 9%, owner belum renounce, LP lock cuma 30 hari
✅ ok:        kontrak verified, bukan honeypot, top10 holder 28%
❓ unknown:   age kontrak belum dicek → suruh web3-ops isi dulu
verdict: boleh masuk kecil, jangan all-in. Re-check setelah LP lock & renounce.
```
Verdict: **SAFE / CAUTION / DANGER**. Cocok juga jadi bahan edukasi konten AirdropFinder ("cara baca rug signal").

---

## Observability & safety baru — v10.0

Mostly otomatis di belakang layar, tapi bisa Operator panggil:

| Command | Effect |
|---|---|
| `cost report` | Ledger biaya terpusat: token LLM + gas on-chain (USD) + API call, breakdown per provider/chain |
| `router log` / `router tune` | Liat keputusan router + deteksi *tie* (keyword nabrak) + saran retune bobot |
| `dry-run on` / `off` | Simulasi global — engine `plan()` bukan broadcast (udah ada, sekarang pakai contextvars, lebih rapi) |
| `regression run <suite>` | Golden-set regression: bandingin output sekarang vs baseline → tau kalau ada yang rusak saat upgrade |

Plus yang jalan otomatis:
- **Secret tripwire** — di output layer, redaksi priv key / mnemonic / API key / JWT / PEM sebelum ke-print/log. CTF flag tetap boleh tampil, secret nyata yang gak relevan tetap di-redact.
- **Cost ledger** — tiap operasi nyatet biayanya, jadi `cost report` selalu akurat.

---

## Alpha & farming intelligence (alpha-radar · farm-roi · tokenomics-unlock) — update v4.2

Tiga modul baru biar farming Operator dari hulu ke hilir ber-angka: nemu proyek duluan → hitung ROI → tau kapan keluar. Semua offline & deterministik, data mentah diambil web3-ops/scientific-research/hermes dulu.

### Alpha radar (alpha-radar) — nemu airdrop SEBELUM diumumkan
```
Operator: scan proyek pre-TGE yang worth difarming di Base
```
```
[ALPHA RADAR] 3 kandidat
📡 ZkProtoX  78/100 (HOT)   · points program ✅ · testnet ✅ · VC tier-1 · effort high
📡 BaseThing 52/100 (WARM)  · governance aktif tanpa token · raise $12M
📡 OldChain   8/100 (COLD)  · token udah ada → peluang airdrop utama lewat
saran: mulai ZkProtoX minggu ini, BaseThing watch dulu
```
Token udah listing? Skor otomatis di-cap 30 — jangan buang gas.

### Farm ROI (farm-roi) — lanjut, trim, atau drop?
```
Operator: hitung ROI semua posisi farming gua
```
```
[FARM ROI] 4 posisi · EV $3.2k − cost $410 = net $2.79k
💼 LayerZero  EV $1.2k · ROI 9.0x → KEEP
💼 ZkProtoX   EV $1.8k · ROI 6.2x → KEEP
💼 BridgeFarm EV $150  · ROI 0.4x → TRIM (gas udah kegedean)
💼 DeadFarm   net -$75 → DROP ⚠️ nganggur 60 hari — wallet pasif sering digugurin
```

### Unlock pressure (tokenomics-unlock) — supply makro sebelum kejebak dump
```
Operator: kalender unlock $ZK 6 bulan ke depan, worth hold gak?
```
```
[UNLOCK CALENDAR] $ZK
🔓 Investor cliff  T-10h  · $160M (40% circ) · pressure EXTREME (32x volume)
   ⚠️ tekanan jual besar <2 minggu — pertimbangkan kurangi posisi DULUAN
🔓 Team linear     T-120h · $40M (10% circ) · pressure HIGH — tandai, siapin exit
```
`now` selalu di-inject (TIME.md). Eksekusi jual tetap lewat exit planner airdrop-intel + Spend Governor.

---

## Proteksi komunitas (anti-scam-sentinel · contract-watcher) — update v4.2

Dua modul defensif **read-only** — jaga member AirdropFinder dari drainer. Gak nyerang, gak nge-exploit; sejalan prinsip whitehat.

### Anti-scam sentinel (anti-scam-sentinel) — situs ini asli atau imitasi?
```
Operator: cek zkprot0x.xyz, resminya zkprotox.xyz
```
```
[SCAM SENTINEL] zkprot0x.xyz → 🚨 LIKELY-SCAM (100/100)
• typosquat: beda 1 huruf dari domain resmi
• 🚩 minta SEED PHRASE — situs resmi GAK PERNAH minta ini
• SSL umur 3 hari + tombol claim
draft warning post udah disiapin — review dulu sebelum broadcast (false positive = fitnah)
```

### Contract watcher (contract-watcher) — aman claim gak?
Modus drainer paling sering: kontrak/claim address diganti diam-diam pas hype claim. Snapshot diambil H9/web3-ops, contract-watcher yang diff.
```
Operator: kontrak claim ZkProtoX berubah gak dari kemarin? aman claim?
```
```
[CONTRACT WATCH] 0xAbc... → 🚨 CRITICAL
🚨 claim address berubah 0xC1... → 0xEVIL... — JANGAN claim sampai verifikasi resmi
🚨 fungsi sensitif baru: setClaimAddress
safe_to_claim: FALSE → semua claim job di-hold
```
`safe_to_claim = FALSE` → claim runner otomatis nahan. No exceptions.

---

## Mesin konten & komunitas (guide-studio · community-intel–hook-ab-lab) — update v4.2

Pipeline konten AirdropFinder end-to-end: dengerin komunitas → bikin panduan → repurpose semua platform → video → hook terbaik.

### Auto guide studio (guide-studio) — 1 airdrop jadi panduan rapi
```
Operator: bikinin panduan ZkProtoX lengkap + versi telegram & X, embed referral gua
```
```
[GUIDE STUDIO] ZkProtoX (Base)
✅ panduan full Markdown ID (header, persiapan, 6 langkah, disclaimer DYOR)
✅ varian Telegram + varian X (≤280)
✅ referral ke-embed di semua varian
🖼️ 4 screenshot job → delegasi ke browser skill
gate: anti-scam-sentinel scan domain dulu sebelum publish — jangan promosiin scam
```

### Community intelligence (community-intel) — apa kata komunitas semalam
```
Operator: analisis chat grup 24 jam terakhir
```
```
[COMMUNITY INTEL] 1.840 pesan (24h) · sentimen netral (+0.05)
🔥 topik: zkprotox(214), claim(180), gas base(95)
❓ paling sering: "kapan claim ZkProtoX dibuka min?" (38x)
🚨 FUD: 12 pesan "gak cair / scam" → cek fakta (anti-scam-sentinel/contract-watcher) dulu, baru klarifikasi
💡 ide: thread FAQ claim ZkProtoX, edukasi gas Base
```

### Omni-repurpose (omni-repurpose) + video pipeline (video-pipeline) + hook lab (hook-ab-lab)
```
Operator: artikel ini jadiin thread X, post TG, carousel IG, script tiktok & youtube
Operator: bikinin paket video 45 detik soal 3 airdrop Base
Operator: kasih 8 varian hook buat konten ini, ranking
```
```
[REPURPOSE] 5 format ✅ — thread 6 tweet (semua ≤280) · TG · 5 slide IG · tiktok 36s · YT 6 mnt
[VIDEO PIPELINE] 45s · hook 6.8s → 3 poin → CTA · storyboard 5 shot · voiceover ID · subtitle .srt
[HOOK LAB] top-3:
  [76] 3 Airdrop Base yang wajib kamu tau sekarang   (angka, urgency)
  [70] Rahasia airdrop Base yang bikin cuan 🔥        (curiosity, emosi)
  [64] Jangan farming Base sebelum nonton ini 👀      (emosi, urgency)
```
Render video = skill `remotion_video`; TTS = `voice.py`. Skor hook = prediksi heuristik, bukan jaminan viral — feed balik performa aktual biar makin akurat.

---

## Session control commands

Cukup ngomong langsung ke Hermes, gak perlu syntax khusus:

| Command | Effect |
|---|---|
| `auto_confirm on` | Mode cepat — skip per-tx gate |
| `auto_confirm off` | Mode safe (default) |
| `status` | Liat semua background job aktif |
| `stop <jobname>` | Matikan background job (sniper, farming, watcher) |
| `resume <jobname>` | Lanjut job yang ke-pause |
| `audit` | Trigger self-audit — system self-check |
| `debug` | Trigger fault-diagnosis — kalau ada error/bug |
| `upgrade brain` | Trigger self-audit deep review (analisa skill coverage, gap, redundancy) |
| `dry-run on` | Semua tx jadi simulate-only, gak broadcast (buat testing) |
| `dry-run off` | Kembali ke broadcast mode |
| `wallet list` | Liat semua wallet di vault |
| `balance <wallet>` | Liat balance multi-chain wallet |
| `revoke approval <spender> di <wallet>` | Revoke ERC-20/721 approval |
| `cost report` | **v10.0** — biaya terpusat: token + gas (USD) + API, per provider/chain |
| `router log` / `router tune` | **v10.0** — log keputusan router + deteksi tie + saran retune |
| `regression run <suite>` | **v10.0** — golden-set regression lintas rilis |
| `skor eligibility <wallet> buat <proyek>` | **v10.0 (airdrop-intel)** — skor 0-100 + gap + flags |
| `sybil audit <N wallet>` | **v10.0 (airdrop-intel)** — cek korelasi antar-wallet sendiri |
| `kalender airdrop` / `claim window minggu ini` | **v10.0 (airdrop-intel)** — alert H-48/H-2/H-0 |
| `exit plan <amount> <token>` | **v10.0 (airdrop-intel)** — exit ladder, via governor |
| `rugcheck <token> di <chain>` | **v10.0** — verdict SAFE/CAUTION/DANGER |
| `triage soal CTF ...` / `decode ...` | **v10.0 (ctf-toolkit)** — whitehat, in-scope only |
| `scan proyek pre-TGE di <chain>` | **v10.0 (alpha-radar)** — alpha radar, skor + tier |
| `hitung ROI posisi farming` | **v10.0 (farm-roi)** — EV/ROI, keep/trim/drop |
| `bikinin panduan <proyek>` | **v10.0 (guide-studio)** — guide ID + varian TG/X + referral |
| `kalender unlock <token>` | **v10.0 (tokenomics-unlock)** — tekanan jual per event |
| `cek domain <situs> resminya <situs>` | **v10.0 (anti-scam-sentinel)** — typosquat + drainer signals |
| `kontrak <proyek> berubah gak? aman claim?` | **v10.0 (contract-watcher)** — diff + safe_to_claim gate |
| `analisis chat grup <window>` | **v10.0 (community-intel)** — topik, FUD, sentimen, ide |
| `repurpose konten ini ke semua platform` | **v10.0 (omni-repurpose)** — X/TG/IG/TikTok/YT |
| `bikinin paket video <durasi> soal <topik>` | **v10.0 (video-pipeline)** — script+storyboard+SRT |
| `kasih varian hook + ranking` | **v10.0 (hook-ab-lab)** — skor stop-scroll 0-100 |

### Per-wallet alias
```
Operator: rename wallet 0xAbC...d4F1 jadi "farming-base-1"
Operator: swap 100 USDC pakai farming-base-1
```

Hermes pakai alias mulai sesi berikutnya.

---

## Background job persistence

Sniper, farming, watcher — semua jalan background via pm2. Survive reboot kalau pakai systemd.

### Liat job aktif
```bash
pm2 ls
```

Sample output:
```
┌─────┬────────────────────┬─────────────┬──────┬─────────┐
│ id  │ name               │ status      │ cpu  │ memory  │
├─────┼────────────────────┼─────────────┼──────┼─────────┤
│ 0   │ hermes (main)      │ online      │ 2%   │ 142 MB  │
│ 1   │ lz-farming         │ online      │ 0.5% │ 48 MB   │
│ 2   │ sniper-base        │ online      │ 1%   │ 36 MB   │
│ 3   │ anti-drainer       │ online      │ 0.3% │ 22 MB   │
│ 4   │ smart-money-watch  │ online      │ 0.4% │ 28 MB   │
└─────┴────────────────────┴─────────────┴──────┴─────────┘
```

### Log per job
```bash
pm2 logs sniper-base --lines 50
pm2 logs lz-farming -f          # follow real-time
```

### Restart / stop
```bash
pm2 restart sniper-base
pm2 stop lz-farming
pm2 delete anti-drainer         # hapus dari list
```

### Auto-start saat VPS reboot
```bash
pm2 save                        # save current state
pm2 startup systemd             # generate systemd unit
# follow instruksi yang muncul
```

---

## Cheat sheet — natural language ke skill route

Tabel cepat: Operator ngomong apa → skill apa yang fire.

| Operator ngomong | Route | File yang load |
|---|---|---|
| "mint NFT [URL]" | nft-minter | `skills/08-web3/nft-minter.md` |
| "mass mint pakai N wallet" | nft-minter + batch-parallel + web3-ops | mint + batch + Web3 |
| "swap X ke Y di [chain]" | H1 | `hermes/references/swap.md` |
| "jual semua $TOKEN" | H1 | swap.md |
| "bridge dari A ke B" | H2 | `hermes/references/bridge.md` |
| "stake ETH di lido" | H3 | `hermes/references/defi.md` |
| "supply USDC ke aave" | H3 | defi.md |
| "open long ETH di GMX" | H3 | defi.md (perp section) |
| "snipe token baru di [chain]" | H4 + web3-ops | sniping.md + Web3 |
| "snipe mint NFT [URL]" | H4 + nft-minter | sniping + minter |
| "pantau wallet [addr]" | H5 | `hermes/references/monitoring.md` |
| "alert kalau whale beli > $X" | H5 + bots-automation | monitoring + TG bot |
| "mempool watch [wallet]" | H5 | monitoring (sniffer section) |
| "tracker smart money" | H5 | monitoring (Nansen/Arkham) |
| "beli NFT [token] di [marketplace]" | H6 | `hermes/references/nft.md` |
| "list NFT gua dijual" | H6 | nft.md |
| "floor sweep [collection]" | H6 | nft.md (Reservoir) |
| "sign in dApp pakai SIWE" | H7 | `hermes/references/web3_connect.md` |
| "resolve ENS [name].eth" | H7 | web3_connect.md |
| "layerzero farming N wallet" | H2 + H1 + batch-parallel | bridge + swap + batch |
| "zksync / linea farming" | H2 + H1 + batch-parallel | sama pattern |
| "buat wallet baru di [chain]" | web3-ops / hermes/wallets.md | tergantung chain |
| "import wallet dari seed" | hermes/wallets.md | (security strict mode) |
| "audit kontrak [addr]" | security-audit | `skills/09-security/security-audit.md` |
| "kenapa bot gua duplikat" | fault-diagnosis + bots-automation | debug + telegram |
| "deploy ke VPS" | infra-deploy | `skills/04-infra/infra-deploy.md` |
| "buat landing page web3" | interface-builder + web3-ops | frontend + Web3 connect |
| "bikin animasi penjelasan / diagram" | creative-media | `skills/07-creative/creative-media.md` (Manim/Excalidraw) |
| "bikin gambar pakai comfyui" | creative-media | creative-media + `scene_prep.py` |
| "kontrol Notes/Safari di Mac gua" | desktop-control | desktop-control + `desktop_control.py` (no cursor steal) |
| "latih robot di Isaac Sim" | desktop-control | desktop-control + `scene_prep.py` |
| "bikin tulisan gua gak kaya AI" | humanizer-voice | humanizer-voice + `humanizer.py` |
| "blokir IP yang nyerang dari log" | enterprise-defense | enterprise-defense + `hids.py` |
| "investigasi error pakai KQL" | enterprise-defense + systematic-debug | enterprise-defense + systematic debug |
| "riset mendalam soal X + sumber" | scientific-research | scientific-research + `research_q.py` |
| "pecahin task ini, gua overwhelmed" | executive-function | `skills/10-operations/executive-function.md` |
| "bikin MCP server" | mcp-prompt-eng | mcp-prompt-eng + `mcp_builder.py` |
| "cek prompt gua ada masalah gak" | mcp-prompt-eng | mcp-prompt-eng (`audit_prompt`) |
| "review compliance / CI-CD / port kode" | compliance-cicd | `skills/04-infra/compliance-cicd.md` |
| "ubah obrolan ini jadi PRD / issues" | product-spec | product-spec + `prd.py` |
| "grill ide gua biar konkret" | product-spec + decision-support | shaping → spec |
| "eval / variance test fitur ini" | agentic-eval | agentic-eval + `eval.py` |
| "debug bug aneh yang kadang muncul" | systematic-debug | `skills/01-meta/systematic-debug.md` (4-fase + variance) |
| "tujuan gua masih kabur, bantu rapihin" | decision-support | `skills/01-meta/decision-support.md` |
| "bikin content calendar 30 hari" | content-strategy | content-strategy + `content.py` |
| "adaptasi post ini ke X/LinkedIn/IG/TikTok" | content-strategy | content-strategy (`adapt`) |
| "bikin thread / carousel / script reels" | content-strategy | content-strategy + `content.py` |
| "bikin caption + hashtag IG" | content-strategy | content-strategy (`caption`/`hashtags`) |
| "tulis pakai framework AIDA/PAS" | copywriting-mastery | `skills/03-content/copywriting-mastery.md` |
| "tulis blog SEO-friendly" | copywriting-mastery | copywriting-mastery (SEO writer) |
| "lokalisasi konten ke bahasa lain" | copywriting-mastery | copywriting-mastery (localization/RTL) |
| "riset tren & kompetitor di niche gua" | content-analytics | content-analytics (+ scientific-research buat dalam) |
| "analisis komentar / performa post" | content-analytics | content-analytics + `content.py` (butuh data real) |
| "1 artikel jadi thread+carousel+reels" | content-analytics | content-analytics (`repurpose`) |
| "full pipeline konten otomatis" | content-analytics + bots-automation/power-planner-swarm | research→draft→visual→schedule→analyze |
| "riset ilmiah genomics/forecasting" | scientific-research | dispatch ke library (scanpy/prophet/dll) |
| "robot lihat & ambil objek (VLA)" | desktop-control | desktop-control (VLA, sim dulu) |
| "skor eligibility wallet buat [proyek]" | airdrop-intel | `skills/08-web3/airdrop-intel.md` + `eligibility.py` |
| "sybil audit N wallet farming gua" | airdrop-intel | airdrop-intel + `sybil_audit.py` |
| "kalender / claim window airdrop" | airdrop-intel | airdrop-intel + `claim_watcher.py` |
| "exit plan / kapan jual [token]" | airdrop-intel | airdrop-intel + `exit_planner.py` |
| "rugcheck / token ini aman gak" | security-audit + H4 + web3-ops | `rugcheck.py` (verdict) |
| "triage soal CTF / decode flag" | ctf-toolkit | `skills/09-security/ctf-toolkit.md` + `ctf.py` |
| "caesar / xor / hash tipe apa" | ctf-toolkit | ctf-toolkit + `ctf.py` |
| "solve CTF web (SQLi/SSTI/JWT)" | ctf-toolkit → ctf-web-exploit | `skills/09-security/ctf-web-exploit.md` + `tools/ctf/` |
| "pwn binary / ret2libc / heap" | ctf-toolkit → ctf-pwn | `skills/09-security/ctf-pwn.md` + pwntools template |
| "reverse binary / angr / keygen" | ctf-toolkit → ctf-reverse | `skills/09-security/ctf-reverse.md` + angr template |
| "RSA attack / crypto challenge" | ctf-toolkit → ctf-crypto | `skills/09-security/ctf-crypto.md` + `tools/ctf/rsa_attacks.py` |
| "forensics / stego / pcap / memdump" | ctf-toolkit → ctf-forensics | `skills/09-security/ctf-forensics.md` + sandbox tools |
| "prompt injection / jailbreak / Gandalf" | ctf-toolkit → ctf-llm-redteam | `skills/09-security/ctf-llm-redteam.md` + `tools/ctf/gandalf_solver.py` |
| "full-auto solve CTFd (swarm)" | ctf-toolkit | `tools/ctf/run.py` (coordinator + sandbox) |
| "scan proyek pre-TGE / alpha airdrop" | alpha-radar | `skills/08-web3/alpha-radar.md` + `alpha_radar.py` |
| "ROI farming / farm mana di-drop" | farm-roi | farm-roi + `farm_roi.py` |
| "bikin panduan airdrop [proyek]" | guide-studio | guide-studio + `guide_studio.py` (+browser buat SS) |
| "kalender unlock / tekanan jual [token]" | tokenomics-unlock | tokenomics-unlock + `unlock_engine.py` |
| "situs ini palsu gak / cek domain" | anti-scam-sentinel | anti-scam-sentinel + `scam_sentinel.py` |
| "kontrak berubah gak / aman claim?" | contract-watcher | contract-watcher + `contract_watch.py` (+H9 snapshot) |
| "apa yang lagi rame di grup / FUD" | community-intel | community-intel + `community_intel.py` (+bots-automation tarik pesan) |
| "repurpose ke X/TG/IG/TikTok/YT" | omni-repurpose | omni-repurpose + `repurpose.py` |
| "bikin paket video / storyboard / srt" | video-pipeline | video-pipeline + `video_pipeline.py` |
| "varian hook / prediksi judul" | hook-ab-lab | hook-ab-lab + `hook_lab.py` |
| "biaya / cost report sesi ini" | core | `cost_ledger.py` |
| "router nabrak / tune keyword" | core | `router_log.py` |
| "regression test antar rilis" | agentic-eval | `eval.py` (RegressionSuite) |

---

## Skill v10.0 — contoh ngomong (Airdrop Intelligence & Whitehat)

Net-new di v10.0. Semua tool offline+deterministik; data on-chain didelegasi ke web3-ops/hermes; fund movement lewat Spend Governor.

### Airdrop Intelligence (airdrop-intel)
```
Operator: skor eligibility wallet#1 buat Linea, kasih gap & saran
Operator: sybil audit 50 wallet farming gua, mana yang bahaya
Operator: claim window airdrop apa aja minggu ini, alert H-48/H-2/H-0
Operator: exit plan 5000 $ZK profil balanced, likuiditas tipis
```

### CTF / Whitehat (ctf-toolkit) — legal & in-scope only
```
Operator: triage soal CTF ini: [deskripsi]
Operator: decode berlapis: [blob base64/hex]
Operator: caesar bruteforce "[ciphertext]"
Operator: ini hash tipe apa: [hash]
```
Target asing / out-of-scope → gate R9 dulu (⚠️ izin? y/n). Exploit aktif = manual + izin.

### Safety & observability
```
Operator: cost report sesi ini       → token + gas + API breakdown
Operator: rugcheck 0xToken... di base → verdict SAFE/CAUTION/DANGER
Operator: regression run mint-detector → cek ada yang rusak gak abis upgrade
```

---

## Skill non-crypto (v10.0) — contoh ngomong

Semua di bawah ini **modul opsional**. Identitas inti tetap crypto+dev — skill ini cuma nyala kalau Operator nyebut. Gak nyentuh dana, jadi gak ada gate governor (kecuali aksi OS/desktop/robot fisik & firewall → satu kali gate R9).

### Media & kreatif (creative-media)
```
Operator: bikinin animasi Manim buat jelasin gradient descent
Operator: generate 10 variasi gambar pakai comfyui, seed beda-beda
Operator: bikin diagram arsitektur sistem gua di excalidraw
Operator: bikin OG card 1200x630 buat artikel ini
```
Output = file artefak (MP4/PNG/SVG). Butuh engine lokal (ffmpeg/Manim/ComfyUI) — deploy via infra-deploy kalau di VPS.

### Desktop & robotik (desktop-control)
```
Operator: catat ini ke Notes gua          → app-drive, kursor Operator GAK kerebut
Operator: latih grasp robot di Isaac Sim, 200 step headless
```
macOS control = background-first (no cursor steal). Robot fisik / aksi destruktif desktop → gate R9 sekali.

### Humanizer (humanizer-voice)
```
Operator: tulisan ini kaku banget, bikin natural   → buang AI-tell
Operator: tune ke brand voice "ct_degen"
```

### Enterprise & defensif (enterprise-defense)
```
Operator: pantau auth.log, auto-block IP brute-force SSH (dry-run dulu)
Operator: tulis KQL buat cari spike latency 6 jam terakhir
```
HIDS selalu allowlist IP Operator + TTL block (gak permaban). Aktivasi firewall → gate R9.

### Riset, fokus, produk (scientific-research/executive-function/product-spec)
```
Operator: riset mendalam dampak EIP-4844 ke L2, kasih sumber
Operator: gua overwhelmed, pecahin task ini satu-satu, kasih yang pertama doang
Operator: dari obrolan tadi, bikinin PRD + breakdown jadi issues
```

### Meta-dev & quality (mcp-prompt-eng/compliance-cicd/agentic-eval/systematic-debug/decision-support)
```
Operator: scaffold MCP server "weather" di Python
Operator: audit prompt system ini, ada masalah apa
Operator: variance test fungsi mint-detector 10x, stabil gak
Operator: bug ini kadang muncul kadang enggak — debug sistematis
Operator: tujuan "cuan dari web3" masih kabur, bantu shaping
```

### Konten & social media (content-strategy/copywriting-mastery/content-analytics)
Suite marketing lengkap. Identitas inti tetap crypto+dev — ini modul opsional buat bikin & nyebarin konten.
```
Operator: bikin content strategy: pillar, audience, positioning buat akun gua
Operator: bikinin content calendar 30 hari, 5 post/minggu, X + IG
Operator: pesan ini adaptasi ke X thread, LinkedIn, IG carousel, sama reels script
Operator: bikin 5 hook scroll-stopper buat topik [X]
Operator: tulis ulang pakai framework PAS, terus humanize (humanizer-voice) biar gak bau AI
Operator: 1 artikel ini repurpose jadi thread + carousel + reels
Operator: riset tren & kompetitor di niche [X], kasih peluang konten
Operator: analisis komentar ini — sentimen, pertanyaan, objection
Operator: bikin 3 variasi A/B buat caption ini (ubah hook doang)
Operator: jalanin full pipeline: research → draft → visual → schedule → analyze
```
Catatan jujur:
- **Analitik & best-time butuh data real** akun Operator (export/API). Tanpa itu → estimasi bertanda, bukan angka karangan.
- **Publish & balas komentar = aksi keluar** → default human-in-the-loop (draft → Operator ACC → kirim). Hal sensitif gak auto-reply.
- Alur juara: content-analytics (riset) → copywriting-mastery (copy) → content-strategy (format) → humanizer-voice (humanize) → creative-media (visual) → bots-automation/power-planner-swarm (schedule).

### Riset & robotik (scientific-research/desktop-control)
```
Operator: riset mendalam [topik ilmiah], dispatch ke library yang tepat + sumber
Operator: cari dataset/model di Hugging Face buat [task]
Operator: robot di Isaac Sim lihat botol merah terus ambil (VLA, latih di sim dulu)
```
Robot fisik / VLA real = gate R9 + meta-action STOP selalu menang. Sains = dispatch ke library tervalidasi + verifikasi, bukan ngarang hasil.

---

## Yang perlu Operator siapin sebelum mulai

1. **VPS akses** — ✅ udah punya `root@your-vps`
2. **Master password vault** — buat sekarang, minimum 16 char, simpan di password manager
3. **RPC primary + fallback per chain** — minimum 2 endpoint per chain (rotating biar gak rate-limit). Recommended: Alchemy / Infura / QuickNode + 1 public RPC sebagai fallback
4. **Test wallet kecil dulu** — generate wallet baru via Hermes, isi $20-50 buat smoke test, jangan langsung pakai wallet utama
5. **Telegram bot baru buat alert** — bikin via @BotFather, taro token-nya di `HERMES_TG_BOT_TOKEN`. Jangan pakai bot yang sama dengan channel publik Operator
6. **API key opsional** — skip dulu kalau belum, Hermes auto-fallback:
   - 1inch (swap): free tier OK
   - Reservoir (NFT): free tier OK
   - Nansen (smart money): paid, paling akurat — opsional
   - Arkham: free tier OK
   - Zerion / Birdeye (portfolio): free tier OK

Setelah 6 hal ini ready → Hermes bisa langsung run. Mau gua bikin **bootstrap script** otomatis (install + env setup + first wallet gen + smoke test), atau Operator prefer setup manual step-by-step?

---

## Cara cepat verify v10.0 + hermes udah jalan

Setelah install + restart, cek 5 hal:

```bash
# 1. Agent boot tanpa error
pm2 logs hermes --lines 20
# harus muncul: [BOOT] v10.0 IRONCLAW SUPREME loaded

# 2. Env var ke-load
env | grep -E "HERMES_|RPC_|ARKHAM_" | head -10

# 3. Skill ke-baca (sekarang monetization-ctf-toolkit + self-audit-decision-support)
ls ~/.openclaw/workspace/openclaw/skills/
# harus liat: skill-registry-ctf-toolkit, self-audit-decision-support, hermes/

# 4. Integrity OK (PENTING — boot rail)
python3 tools/skill_integrity.py verify
# harus: "✅ Integritas OK — 150 file cocok" (exit 0)

# 5. Test offline hijau (zero leak)
bash tools/tests/run_tests.sh           # 85 tests OK
bash skills/hermes/tests/run_tests.sh   # 44 tests OK
# total 129 pass, 0 ResourceWarning di -W error::ResourceWarning
```

Kalau 5 hal di atas ✅, SUPERAGENT v10.0 siap eksekusi.

> Catatan: tiap habis edit/tambah file `.md` atau `.py`, jalanin `python3 tools/skill_integrity.py generate` lalu `verify`. Verify gagal (exit≠0) = boot rail nahan operasi on-chain sampai diaudit.
