<!-- BAGIAN 5/5 — tempel berurutan. Jangan minta ringkasan. -->
- `hermes/references/wallets.md` — Reference untuk membuat wallet baru, import dari seed phrase / private key, list wallet tersimpan, dan cek balance linta
- `hermes/references/web3_connect.md` — Web3 Connect & Sign-in

Total skill terindeks: 215
