#!/usr/bin/env python3
"""
tools/selfcheck.py — SUPERAGENT health check ("doctor")
(V10 — one command to prove the whole system is intact)

Runs a battery of checks and prints a clean report:
  * counts   — skills, tools, tests, category folders
  * integrity— SKILLS.lock present, parseable, file_count sane
  * links    — broken relative markdown links across the pack
  * router   — AGENTS.md keyword table parses and routes
  * engine   — the autonomy tools import and a demo tick runs

Exit code 0 = healthy, 1 = problems found. Zero external deps.

Usage:
    python3 selfcheck.py            # pretty report
    python3 selfcheck.py --json     # machine-readable
"""
from __future__ import annotations

import json
import os
import pathlib
import re
import sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent


def _count_skills():
    general = len([p for p in (ROOT / "skills").glob("[0-9][0-9]-*/*.md")
                   if p.name != "README.md" and "09-security" not in str(p)])
    sec_subs = ("core recon web api auth mobile reverse-engineering exploit-dev "
                "cloud-infra web3 reporting ctf redteam autonomy llm").split()
    security = 0
    for sub in sec_subs:
        security += len([p for p in (ROOT / "skills/09-security" / sub).glob("*.md")
                         if p.name != "README.md"])
    return general, security


def _count_tools():
    return len(list((ROOT / "tools").glob("*.py")))


def _count_tests():
    return len(list((ROOT / "tools/tests").glob("test_*.py")))


def _count_categories():
    return len([d for d in (ROOT / "skills").glob("[0-9][0-9]-*") if d.is_dir()])


def check_integrity():
    lock = ROOT / "SKILLS.lock"
    if not lock.exists():
        return False, "SKILLS.lock missing"
    try:
        data = json.loads(lock.read_text())
    except Exception as e:
        return False, f"SKILLS.lock unparseable: {e}"
    fc = data.get("file_count", 0)
    if fc < 100:
        return False, f"file_count suspiciously low ({fc})"
    return True, f"v{data.get('version')} · {fc} files tracked"


def check_links():
    broken = []
    for f in ROOT.rglob("*.md"):
        if "/.git" in str(f):
            continue
        fdir = f.parent
        s = f.read_text(encoding="utf-8", errors="ignore")
        for m in re.finditer(r'\]\(([^)]+?\.(?:md|txt))\)', s):
            t = m.group(1)
            if t.startswith(("http", "#", "/")):
                continue
            if not (fdir / t).resolve().is_file():
                broken.append(f"{f.relative_to(ROOT)} → {t}")
    return len(broken) == 0, broken


def check_router():
    try:
        sys.path.insert(0, str(HERE))
        import skill_router as R
        table = R.parse_table()
        res = R.route("deploy nginx on my VPS", table)
        ok = res["primary"] and res["primary"]["skill"] == "infra-deploy"
        return ok, f"{len(table)} skills in keyword table; sample route OK={bool(ok)}"
    except Exception as e:
        return False, f"router error: {e}"


def check_engine():
    try:
        sys.path.insert(0, str(HERE))
        import autopilot as A
        import bounty_discovery as BD
        out = A.tick([f.__dict__ for f in BD._demo()], gate_mode="strict",
                     write_memory=False)
        ok = out["engaged_this_tick"] == 0 and out["counts"]["qualified"] >= 1
        return ok, f"demo tick ran; strict engaged={out['engaged_this_tick']} (expected 0)"
    except Exception as e:
        return False, f"engine error: {e}"


def check_docs_counts():
    """Detect documentation drift: reader docs claiming a skill/tool/test count
    that no longer matches reality. Catches the common 'added skills, forgot to
    update the docs' problem. Scans only clearly current-state claims."""
    general, security = _count_skills()
    total = general + security
    tools = _count_tools()
    # the set of 'correct' numbers that may legitimately appear near these words
    valid = {
        "skill": {str(total), str(security), str(general)},
        "tool":  {str(tools)},
    }
    # a stale number is any 2-3 digit count sitting next to skill/tool wording
    # that is NOT one of the valid current numbers.
    docs = ["README.md", "GUIDE.md", "WHY-V10.md", "BUGBOUNTY-GUIDE.md",
            "RELEASE.md", "STRUCTURE.md", "SKILL.md", "INDEX.md",
            "docs/MANIFEST.md", "docs/ARCHITECTURE.md"]
    stale = []
    # A count is "<number> skills/tools" where the number is a standalone word
    # (not part of a path like 09-security or a heading like "19."). We require
    # the number to be immediately followed by whitespace, then the noun within
    # a few words — and NOT followed by '-' or '.' or '/' (path/heading markers).
    skill_re = re.compile(r"(?<![\w./-])(\d{2,3})(?![\d./-])\s+(?:\w+\s+){0,3}?(?:on-demand\s+|specialized\s+|runnable\s+)?skills?\b", re.I)
    tool_re = re.compile(r"(?<![\w./-])(\d{2,3})(?![\d./-])\s+(?:\w+\s+){0,2}?(?:runnable\s+|python\s+)?tools?\b", re.I)
    secdom_re = re.compile(r"security domain[^\n]{0,24}?\(?(?<![\w./-])(\d{2,3})(?![\d./-])\s*(?:skills?)?\)?", re.I)
    for rel in docs:
        p = ROOT / rel
        if not p.is_file():
            continue
        for i, line in enumerate(p.read_text(errors="ignore").splitlines(), 1):
            low = line.lower()
            # skip historical/changelog-style and comparison ("→", "was", "V7") lines
            if any(w in low for w in ("v7", "was ", "previously", "→", "stale count",
                                      "finding", "evolution", "rename")):
                continue
            for m in skill_re.finditer(line):
                if m.group(1) not in valid["skill"]:
                    stale.append(f"{rel}:{i} skills={m.group(1)}")
            for m in tool_re.finditer(line):
                if m.group(1) not in valid["tool"]:
                    stale.append(f"{rel}:{i} tools={m.group(1)}")
            for m in secdom_re.finditer(line):
                if m.group(1) not in valid["skill"]:
                    stale.append(f"{rel}:{i} security-domain={m.group(1)}")
    # de-dupe, cap
    stale = sorted(set(stale))
    if stale:
        return False, stale
    return True, f"doc counts consistent ({total} skills / {tools} tools)"


def run():
    general, security = _count_skills()
    report = {"counts": {
        "skills_total": general + security,
        "skills_general": general,
        "skills_security": security,
        "tools": _count_tools(),
        "test_files": _count_tests(),
        "category_folders": _count_categories(),
    }, "checks": {}}

    for name, fn in (("integrity", check_integrity), ("links", check_links),
                     ("router", check_router), ("engine", check_engine),
                     ("doc_counts", check_docs_counts)):
        ok, detail = fn()
        report["checks"][name] = {"ok": bool(ok), "detail": detail}

    report["healthy"] = all(c["ok"] for c in report["checks"].values())
    return report


def main(argv):
    report = run()
    if "--json" in argv:
        print(json.dumps(report, indent=2, default=str))
        return 0 if report["healthy"] else 1

    c = report["counts"]
    print("🩺  SUPERAGENT V10 — Health Check")
    print("─" * 44)
    print(f"  skills      : {c['skills_total']}  ({c['skills_general']} general + {c['skills_security']} security)")
    print(f"  tools       : {c['tools']}")
    print(f"  test files  : {c['test_files']}")
    print(f"  categories  : {c['category_folders']}")
    print("─" * 44)
    for name, res in report["checks"].items():
        mark = "✅" if res["ok"] else "❌"
        detail = res["detail"]
        if name == "links" and not res["ok"]:
            detail = f"{len(detail)} broken: " + "; ".join(detail[:3])
        if name == "doc_counts" and not res["ok"]:
            detail = f"{len(detail)} stale: " + "; ".join(detail[:4])
        print(f"  {mark}  {name:<10}: {detail}")
    print("─" * 44)
    print("  STATUS:", "🟢 HEALTHY" if report["healthy"] else "🔴 PROBLEMS FOUND")
    return 0 if report["healthy"] else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
