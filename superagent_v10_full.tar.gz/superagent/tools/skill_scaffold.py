#!/usr/bin/env python3
"""
tools/skill_scaffold.py — Generate a new skill, fully wired (runnable)
(V10 — makes the pack extensible: friends can add their own skills in one command)

Creates a new skill with the correct V10 frontmatter, drops it in the right
category folder, and tells you exactly how to register it in the router and
registry. Use --apply to also auto-insert the router keyword row and the
registry line (otherwise it prints what to add — dry-run by default).

Zero external deps (stdlib). Usage:
    python3 skill_scaffold.py --name seo-growth --category 03-content \
        --title "SEO & Organic Growth" \
        --keywords "seo, keyword research, serp, backlinks, technical seo"
    python3 skill_scaffold.py --name seo-growth --category 03-content \
        --title "SEO & Organic Growth" --keywords "seo, serp" --apply
"""
from __future__ import annotations

import argparse
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SKILLS = ROOT / "skills"
AGENTS = ROOT / "AGENTS.md"
REGISTRY = SKILLS / "00-core" / "skill-registry.md"

VALID_CATEGORIES = [
    "00-core", "01-meta", "02-business", "03-content", "04-infra",
    "05-engineering", "06-ai", "07-creative", "08-web3", "10-operations",
    "11-team",
]

TEMPLATE = """---
skill: {name}
title: "{title}"
category: "{category_label}"
load_when: "{keywords}"
pack: SUPERAGENT V10
---

# {title}

## Operator Profile
<!-- One or two sentences: what kind of specialist this skill makes the agent. -->

## When to use
{keywords}

## Methodology
1.
2.
3.

## Output contract
- Deliver working output first, theory after.
- End with a concrete next step.

→ Next: suggest the follow-up action.
"""


def _slugish(s: str) -> str:
    return re.sub(r"[^a-z0-9-]", "", s.lower().replace(" ", "-"))


def category_label(folder: str) -> str:
    return {
        "00-core": "Core", "01-meta": "Meta & Self-Improvement",
        "02-business": "Business & Monetization", "03-content": "Content & Marketing",
        "04-infra": "Infrastructure & DevOps", "05-engineering": "Engineering",
        "06-ai": "AI & Inference", "07-creative": "Design & Media",
        "08-web3": "Web3 & Crypto", "10-operations": "Operations",
        "11-team": "Team & Collaboration",
    }.get(folder, "Operations")


def build(name, category, title, keywords):
    name = _slugish(name)
    if not name:
        raise ValueError("name must be a slug (letters/digits/dashes)")
    if category not in VALID_CATEGORIES:
        raise ValueError(f"category must be one of {VALID_CATEGORIES}")
    target = SKILLS / category / f"{name}.md"
    content = TEMPLATE.format(
        name=name, title=title or name, category_label=category_label(category),
        keywords=keywords or name,
    )
    # router row + registry line to add
    kws = [k.strip() for k in keywords.split(",") if k.strip()] or [name]
    high = ", ".join(kws[:5])
    med = ", ".join(kws[5:8]) or "—"
    low = ", ".join(kws[8:10]) or "—"
    router_row = f"{name}   | {high} | {med} | {low}"
    registry_row = f"{name}  | {title or name}  | {high}"
    return name, target, content, router_row, registry_row


def apply_router(router_row):
    s = AGENTS.read_text()
    # insert before the closing ``` of the keyword table (after decision-support row)
    anchor = "decision-support    | problem shaping"
    if anchor in s and router_row.split("|")[0].strip() not in s:
        line = [l for l in s.splitlines() if anchor in l][0]
        s = s.replace(line, line + "\n" + router_row, 1)
        AGENTS.write_text(s)
        return True
    return False


def apply_registry(name, title, keywords):
    s = REGISTRY.read_text()
    kws = ", ".join([k.strip() for k in keywords.split(",")][:6]) or name
    line = f"{name:<20} | {(title or name):<35} | {kws}"
    if f"\n{name} " not in s and f"\n{name:<20}" not in s:
        # append inside the registry block (after the last skill row in the code fence)
        s = s.rstrip() + f"\n\n> Added by scaffold: `{name}` — {title}\n"
        REGISTRY.write_text(s)
        return True
    return False


def main(argv):
    ap = argparse.ArgumentParser(description="Scaffold a new SUPERAGENT skill.")
    ap.add_argument("--name", required=True, help="slug, e.g. seo-growth")
    ap.add_argument("--category", required=True, choices=VALID_CATEGORIES)
    ap.add_argument("--title", default="", help='e.g. "SEO & Organic Growth"')
    ap.add_argument("--keywords", default="", help="comma-separated trigger keywords")
    ap.add_argument("--apply", action="store_true", help="write file + wire router/registry")
    ap.add_argument("--force", action="store_true", help="overwrite if the skill exists")
    args = ap.parse_args(argv[1:])

    try:
        name, target, content, router_row, registry_row = build(
            args.name, args.category, args.title, args.keywords)
    except ValueError as e:
        print(f"✗ {e}")
        return 1

    print(f"skill:    {name}")
    print(f"path:     {target.relative_to(ROOT)}")
    print(f"router +  {router_row}")
    print(f"registry+ {registry_row}")

    if not args.apply:
        print("\n(dry-run) re-run with --apply to create the file and wire it in.")
        return 0

    if target.exists() and not args.force:
        print(f"\n✗ {target.relative_to(ROOT)} already exists (use --force).")
        return 1
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)
    r = apply_router(router_row)
    g = apply_registry(name, args.title, args.keywords)
    print(f"\n✓ created {target.relative_to(ROOT)}")
    print(f"✓ router row {'added' if r else 'skipped (already present)'}")
    print(f"✓ registry note {'added' if g else 'skipped'}")
    print("→ Next: edit the skill body, then regenerate SKILLS.lock and run the tests.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
