#!/usr/bin/env python3
"""
tools/skill_router.py — Keyword-weighted skill router (runnable)
(V10 core — the executable form of the AGENTS.md keyword table)

Turns the keyword weight table in AGENTS.md into a real scorer: given an
operator request, it computes a weighted score per skill and returns the
PRIMARY match (+ any SUPPORTING skills above 50% of the top score). This is the
executable version of the "SKILL ROUTER" section — no guessing, deterministic.

Scoring (per the table): HIGH keyword = 3pt, MED = 2pt, LOW = 1pt, summed over
occurrences (word-boundary, case-insensitive). Ties are reported, not silently
resolved.

Zero external deps (stdlib). Usage:
    python3 skill_router.py "audit this smart contract for a rug"
    echo "bikin telegram bot airdrop" | python3 skill_router.py
    python3 skill_router.py --json "idor on the api"
"""
from __future__ import annotations

import json
import pathlib
import re
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

ROOT = pathlib.Path(__file__).resolve().parent.parent
AGENTS = ROOT / "AGENTS.md"

WEIGHTS = {"high": 3, "med": 2, "low": 1}


@dataclass
class SkillKeywords:
    skill: str
    high: List[str] = field(default_factory=list)
    med: List[str] = field(default_factory=list)
    low: List[str] = field(default_factory=list)


def _split_kw(cell: str) -> List[str]:
    return [k.strip().lower() for k in cell.split(",") if k.strip()]


def parse_table(agents_path: pathlib.Path = AGENTS) -> List[SkillKeywords]:
    """Parse the keyword-weight table out of AGENTS.md."""
    text = agents_path.read_text(encoding="utf-8")
    rows: List[SkillKeywords] = []
    in_table = False
    for line in text.splitlines():
        if line.startswith("SKILL |") and "HIGH WEIGHT" in line:
            in_table = True
            continue
        if not in_table:
            continue
        if line.startswith("```") or line.strip() == "":
            if rows:  # table ended
                break
            continue
        if line.startswith("----") or line.startswith("------"):
            continue
        parts = [p.strip() for p in line.split("|")]
        if len(parts) < 2:
            continue
        name = parts[0].strip()
        if not name or " " in name:  # skip malformed / prose lines
            # allow names with internal dashes but not spaces
            if not re.match(r"^[A-Za-z0-9_-]+$", name):
                continue
        high = _split_kw(parts[1]) if len(parts) > 1 else []
        med = _split_kw(parts[2]) if len(parts) > 2 else []
        low = _split_kw(parts[3]) if len(parts) > 3 else []
        rows.append(SkillKeywords(name, high, med, low))
    return rows


def _count(term: str, text: str) -> int:
    # word-boundary-ish match; handles multiword terms
    pat = r"(?<![a-z0-9])" + re.escape(term) + r"(?![a-z0-9])"
    return len(re.findall(pat, text))


def score(query: str, table: List[SkillKeywords]) -> List[Tuple[str, int, List[str]]]:
    q = query.lower()
    results = []
    for sk in table:
        s = 0
        hits: List[str] = []
        for tier, kws in (("high", sk.high), ("med", sk.med), ("low", sk.low)):
            for kw in kws:
                c = _count(kw, q)
                if c:
                    s += c * WEIGHTS[tier]
                    hits.append(f"{kw}({WEIGHTS[tier]})")
        if s > 0:
            results.append((sk.skill, s, hits))
    # Sort by score desc; on ties prefer a specific security playbook ("sec:…")
    # over a generic skill — a request naming a specific vuln should route to it.
    results.sort(key=lambda r: (r[1], r[0].startswith("sec:")), reverse=True)
    return results


def route(query: str, table: List[SkillKeywords] = None) -> Dict:
    table = table if table is not None else parse_table()
    ranked = score(query, table)
    if not ranked:
        return {"query": query, "primary": None, "supporting": [],
                "note": "no keyword match → answer from core, load nothing"}
    top_name, top_score, top_hits = ranked[0]
    ties = [r for r in ranked if r[1] == top_score]
    supporting = [{"skill": n, "score": s} for n, s, _ in ranked[1:]
                  if s >= top_score * 0.5]
    out = {
        "query": query,
        "primary": {"skill": top_name, "score": top_score, "matched": top_hits},
        "supporting": supporting,
        "all": [{"skill": n, "score": s} for n, s, _ in ranked[:8]],
    }
    if len(ties) > 1:
        out["tie"] = [t[0] for t in ties]
        out["note"] = "tie → ask once: which to focus on first?"
    return out


def main(argv: List[str]) -> int:
    as_json = "--json" in argv
    args = [a for a in argv[1:] if a != "--json"]
    if args:
        query = " ".join(args)
    elif not sys.stdin.isatty():
        query = sys.stdin.read().strip()
    else:
        print(__doc__)
        return 0

    result = route(query)
    if as_json:
        print(json.dumps(result, indent=2))
        return 0

    # pretty
    p = result["primary"]
    if not p:
        print(f"'{query}'\n  → no match; answer from core (load nothing)")
        return 0
    print(f"'{query}'")
    print(f"  PRIMARY:    {p['skill']}  (score {p['score']})  ← matched {', '.join(p['matched'])}")
    if result.get("tie"):
        print(f"  TIE:        {', '.join(result['tie'])}  (ask which first)")
    if result["supporting"]:
        sup = ", ".join(f"{s['skill']}({s['score']})" for s in result["supporting"])
        print(f"  SUPPORTING: {sup}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
