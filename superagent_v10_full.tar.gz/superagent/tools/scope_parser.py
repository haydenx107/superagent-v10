#!/usr/bin/env python3
"""
tools/scope_parser.py — Program scope parser & target validator (runnable)
(V10 bug-bounty — never test an out-of-scope target by accident)

Parses a bug-bounty program's in-scope / out-of-scope lists (wildcards like
*.example.com supported) and tells you whether a given target is IN, OUT, or
UNKNOWN — the machine check behind "confirm scope every time".

⚠️ A tool's "IN" is necessary but NOT sufficient authorization — always confirm
against the live program policy. This prevents accidents; it is not consent.

Zero external deps (stdlib). Usage:
    python3 scope_parser.py check api.example.com \
        --in "*.example.com, example.com" --out "blog.example.com, *.dev.example.com"
    echo '{"in":["*.example.com"],"out":["test.example.com"]}' | \
        python3 scope_parser.py check api.example.com
    python3 scope_parser.py filter a.example.com,b.other.com --in "*.example.com" --json
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import sys
import urllib.parse


def _host(target: str) -> str:
    t = target.strip().lower()
    if "://" in t:
        t = urllib.parse.urlparse(t).netloc or t
    if "/" in t:
        t = t.split("/", 1)[0]
    if "@" in t:
        t = t.split("@", 1)[1]
    if ":" in t and not t.count(":") > 1:  # strip port, keep IPv6-ish alone
        t = t.split(":", 1)[0]
    return t


def _match(host: str, patterns: list) -> str | None:
    for p in patterns:
        p = p.strip().lower()
        if not p:
            continue
        if "://" in p:
            p = _host(p)
        if fnmatch.fnmatch(host, p) or host == p:
            return p
        # bare domain pattern also matches its subdomains via explicit *.d
        if p.startswith("*.") and host == p[2:]:
            return p
    return None


def verdict(target: str, in_scope: list, out_scope: list) -> dict:
    host = _host(target)
    out_hit = _match(host, out_scope)
    in_hit = _match(host, in_scope)
    # out-of-scope always wins (explicit exclusion)
    if out_hit:
        v = "OUT"
    elif in_hit:
        v = "IN"
    else:
        v = "UNKNOWN"
    return {"target": target, "host": host, "verdict": v,
            "matched_in": in_hit, "matched_out": out_hit,
            "note": "IN means it matches the in-scope list and is not excluded — "
                    "still confirm against the live program policy."}


def _load_scope(args) -> tuple:
    in_scope = [s for s in args.in_scope.split(",")] if args.in_scope else []
    out_scope = [s for s in args.out_scope.split(",")] if args.out_scope else []
    if not in_scope and not sys.stdin.isatty():
        try:
            data = json.loads(sys.stdin.read() or "{}")
            in_scope = data.get("in", in_scope)
            out_scope = data.get("out", out_scope)
        except json.JSONDecodeError as e:
            print(f"✗ invalid JSON scope on stdin: {e}", file=sys.stderr)
            raise SystemExit(1)
    return in_scope, out_scope


def main(argv):
    ap = argparse.ArgumentParser(description="Parse scope & validate targets.")
    ap.add_argument("cmd", choices=["check", "filter"])
    ap.add_argument("target", help="host/url (check) or comma list (filter)")
    ap.add_argument("--in", dest="in_scope", default="")
    ap.add_argument("--out", dest="out_scope", default="")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv[1:])

    in_scope, out_scope = _load_scope(args)
    if not in_scope:
        print("✗ no in-scope list provided (--in or stdin JSON {\"in\":[...]})", file=sys.stderr)
        return 1

    if args.cmd == "check":
        r = verdict(args.target, in_scope, out_scope)
        if args.json:
            print(json.dumps(r, indent=2)); return 0
        icon = {"IN": "🟢", "OUT": "🔴", "UNKNOWN": "🟡"}[r["verdict"]]
        print(f"{icon} {r['verdict']}  {r['host']}")
        if r["matched_in"]:  print(f"   in-scope match : {r['matched_in']}")
        if r["matched_out"]: print(f"   out-scope match: {r['matched_out']}")
        print(f"   {r['note']}")
        return 0 if r["verdict"] != "OUT" else 2

    # filter
    targets = [t for t in args.target.split(",") if t.strip()]
    results = [verdict(t, in_scope, out_scope) for t in targets]
    if args.json:
        print(json.dumps(results, indent=2)); return 0
    for r in results:
        icon = {"IN": "🟢", "OUT": "🔴", "UNKNOWN": "🟡"}[r["verdict"]]
        print(f"  {icon} {r['verdict']:<8} {r['host']}")
    inc = sum(1 for r in results if r["verdict"] == "IN")
    print(f"\n  {inc}/{len(results)} in-scope")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
