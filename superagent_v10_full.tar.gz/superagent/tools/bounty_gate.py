#!/usr/bin/env python3
"""
tools/bounty_gate.py — Authorization Gate for autonomous bug-bounty testing
(V10, skill: bug-bounty-autonomy)

The HARD legal checkpoint between "found a field" and "allowed to test it."
Deterministic, offline. Returns PASS / HUMAN_CONFIRM / FAIL. The autonomous
scheduler MUST route every field through here and MUST NOT test on anything
that is not PASS. Ambiguity resolves to HUMAN_CONFIRM, never to proceed.

Gate test (ALL must be true to PASS):
  1 public testing invitation exists
  2 scope explicit and the intended asset is covered
  3 intended asset not excluded; technique not excluded
  4 automated/agentic testing allowed by RoE
  5 no conflicting signal (private/invite-only/login-wall/takedown)
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from typing import List, Optional


PASS = "PASS"
CONFIRM = "HUMAN_CONFIRM"
FAIL = "FAIL"


@dataclass
class GateInput:
    id: str
    invites_testing: Optional[bool] = None
    scope_assets: List[str] = field(default_factory=list)
    out_of_scope: List[str] = field(default_factory=list)
    excluded_tests: List[str] = field(default_factory=list)
    intended_asset: str = ""
    intended_technique: str = ""
    private_or_invite_only: bool = False
    login_required_for_policy: bool = False
    takedown_or_stop_notice: bool = False
    roe_allows_automation: Optional[bool] = None  # True/None/False
    gate_mode: str = "strict"                      # strict|auto|paused


def _asset_in_scope(asset: str, scope: List[str]) -> bool:
    a = asset.lower().strip()
    for s in scope:
        s = s.lower().strip()
        if s == a:
            return True
        if s.startswith("*."):
            dom = s[2:]
            if a == dom or a.endswith("." + dom):
                return True
    return False


def evaluate(g: GateInput) -> dict:
    reasons: List[str] = []

    if g.gate_mode == "paused":
        return {"id": g.id, "decision": FAIL, "reasons": ["gate_mode=paused: no testing"]}

    # Immediate FAIL signals
    if g.private_or_invite_only:
        return {"id": g.id, "decision": FAIL, "reasons": ["private/invite-only program"]}
    if g.login_required_for_policy:
        return {"id": g.id, "decision": FAIL, "reasons": ["login required to even read policy"]}
    if g.takedown_or_stop_notice:
        return {"id": g.id, "decision": FAIL, "reasons": ["takedown/stop notice present"]}

    # 1 invitation
    if g.invites_testing is False:
        return {"id": g.id, "decision": FAIL, "reasons": ["no public testing invitation"]}
    invite_ok = g.invites_testing is True
    if not invite_ok:
        reasons.append("invitation unclear")

    # 2 scope covers intended asset
    if not g.scope_assets:
        return {"id": g.id, "decision": FAIL, "reasons": ["no explicit scope"]}
    if g.intended_asset:
        if _asset_in_scope(g.intended_asset, g.out_of_scope):
            return {"id": g.id, "decision": FAIL,
                    "reasons": [f"intended asset '{g.intended_asset}' is out-of-scope"]}
        if not _asset_in_scope(g.intended_asset, g.scope_assets):
            return {"id": g.id, "decision": FAIL,
                    "reasons": [f"intended asset '{g.intended_asset}' not in scope"]}
    else:
        reasons.append("no specific intended asset set")

    # 3 technique not excluded
    tech = g.intended_technique.lower()
    for ex in g.excluded_tests:
        if ex.lower() in tech and tech:
            return {"id": g.id, "decision": FAIL,
                    "reasons": [f"technique '{tech}' is excluded"]}

    # 4 automation allowed
    if g.roe_allows_automation is False:
        return {"id": g.id, "decision": FAIL, "reasons": ["RoE forbids automated testing"]}
    if g.roe_allows_automation is None:
        reasons.append("automation permission unclear")

    # Decision
    clean = not reasons
    if clean and g.gate_mode == "auto":
        return {"id": g.id, "decision": PASS, "reasons": ["all 5 gate checks clear"]}
    if clean and g.gate_mode == "strict":
        return {"id": g.id, "decision": CONFIRM,
                "reasons": ["all checks clear; strict mode requires human-confirm"]}
    # any ambiguity -> human-confirm (never silent proceed)
    return {"id": g.id, "decision": CONFIRM, "reasons": reasons}


def _demo() -> List[GateInput]:
    return [
        GateInput(id="demo:acme", invites_testing=True,
                  scope_assets=["*.acme.example"], intended_asset="api.acme.example",
                  intended_technique="idor", roe_allows_automation=True, gate_mode="auto"),
        GateInput(id="demo:ambiguous", invites_testing=None,
                  scope_assets=["blog.example"], intended_asset="blog.example",
                  gate_mode="strict"),
        GateInput(id="demo:private", private_or_invite_only=True,
                  scope_assets=["x.example"]),
    ]


def main(argv: List[str]) -> int:
    if len(argv) > 1 and argv[1] in ("-h", "help", "--help"):
        print(__doc__)
        print("usage: bounty_gate.py check [--file F]   (reads GateInput JSON; stdin or --file)")
        print("       bounty_gate.py demo")
        return 0

    cmd = argv[1] if len(argv) > 1 else "demo"
    if cmd == "demo":
        inputs = _demo()
    else:
        path = None
        if "--file" in argv:
            path = argv[argv.index("--file") + 1]
        try:
            raw = open(path).read() if path else sys.stdin.read()
            data = json.loads(raw)
        except FileNotFoundError:
            print(f"✗ file not found: {path}"); return 1
        except json.JSONDecodeError as e:
            print(f"✗ invalid JSON input: {e}"); return 1
        if isinstance(data, dict):
            data = [data]
        inputs = [GateInput(**d) for d in data]

    results = [evaluate(g) for g in inputs]
    print(json.dumps(results, indent=2))
    # exit non-zero if nothing PASSed (useful for scripting)
    return 0 if any(r["decision"] == PASS for r in results) else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
