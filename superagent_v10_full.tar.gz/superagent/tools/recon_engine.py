#!/usr/bin/env python3
"""
tools/recon_engine.py — Recon plan generator (runnable)
(V10 bug-bounty — target domain in, a phased recon command plan out)

Produces a structured, phased recon plan (passive → active → content → analysis)
with ready-to-run commands using standard tooling (subfinder, httpx, nuclei,
ffuf, katana, …). It PLANS; it runs nothing and contacts no target. You review,
confirm scope, then execute the commands yourself.

⚠️ Authorized, in-scope targets only. This emits a command list — running it is
your decision and your responsibility. Passive steps first; active steps need
explicit authorization.

Zero external deps (stdlib). Usage:
    python3 recon_engine.py example.com
    python3 recon_engine.py example.com --active --json
    python3 recon_engine.py example.com --phase content
"""
from __future__ import annotations

import argparse
import json
import re
import sys

PHASES = {
    "passive": {
        "title": "Passive recon (no target contact)",
        "cmds": [
            ("subfinder", "subfinder -d {d} -all -silent > subs.txt"),
            ("amass-passive", "amass enum -passive -d {d} >> subs.txt"),
            ("crtsh", "curl -s 'https://crt.sh/?q=%25.{d}&output=json' | jq -r '.[].name_value' | sort -u"),
            ("wayback", "curl -s 'http://web.archive.org/cdx/search/cdx?url=*.{d}/*&output=text&fl=original&collapse=urlkey' | sort -u > wayback.txt"),
            ("github-dork", "# manual: search github for '{d}' secrets/keys, use trufflehog on any repo"),
        ],
    },
    "active": {
        "title": "Active recon (needs authorization)",
        "cmds": [
            ("resolve", "cat subs.txt | sort -u | dnsx -silent -a -resp > resolved.txt"),
            ("httpx", "cat subs.txt | httpx -silent -title -tech-detect -status-code -o live.txt"),
            ("ports", "naabu -silent -top-ports 1000 -list resolved.txt -o ports.txt"),
            ("nuclei", "cat live.txt | nuclei -severity low,medium,high,critical -o nuclei.txt"),
        ],
    },
    "content": {
        "title": "Content & endpoint discovery",
        "cmds": [
            ("crawl", "katana -list live.txt -jc -o crawl.txt"),
            ("js-endpoints", "cat crawl.txt | grep '\\.js$' | while read u; do curl -s $u | grep -oE '\"/[a-zA-Z0-9_/?=.-]+\"'; done | sort -u"),
            ("dir-brute", "ffuf -u https://{d}/FUZZ -w /path/wordlist.txt -mc 200,204,301,302,403 -o ffuf.json"),
            ("params", "cat crawl.txt | gf xss; cat crawl.txt | gf ssrf; cat crawl.txt | gf sqli"),
        ],
    },
    "analysis": {
        "title": "Analysis & prioritization",
        "cmds": [
            ("takeover", "cat subs.txt | subzy run --targets - # dangling CNAME takeover"),
            ("secrets", "cat crawl.txt | grep -E '\\.(js|json|env|map)$' | nuclei -t exposures/ -o secrets.txt"),
            ("prioritize", "# rank live.txt by: auth surface, API endpoints, upload, admin, graphql"),
        ],
    },
}

SKILL_HINTS = [
    ("graphql endpoint found", "sec:api/graphql"),
    ("login / oauth / saml surface", "sec:auth/oauth, sec:auth/jwt, sec:auth/saml"),
    ("object ids in URLs", "sec:web/idor, sec:api/rest-authz"),
    ("file upload form", "sec:web/file-upload"),
    ("url/webhook params", "sec:web/ssrf"),
    ("search/reflected params", "sec:web/xss"),
    ("dangling CNAME", "sec:recon/takeover"),
    ("websocket (ws://)", "sec:web/websocket"),
    ("TLS/cert issues", "sec:web/ssl-tls"),
]

_DOMAIN = re.compile(r"^(?!-)[a-z0-9-]{1,63}(?<!-)(\.[a-z0-9-]{1,63})+$")


def valid_domain(d: str) -> bool:
    d = d.strip().lower()
    if "://" in d or "/" in d:
        return False
    return bool(_DOMAIN.match(d))


def plan(domain: str, phases: list) -> dict:
    out = {"target": domain, "phases": [], "next_skills": SKILL_HINTS}
    for ph in phases:
        meta = PHASES[ph]
        out["phases"].append({
            "phase": ph,
            "title": meta["title"],
            "commands": [{"tool": t, "cmd": c.format(d=domain)} for t, c in meta["cmds"]],
        })
    out["note"] = ("Plan only — nothing was run. Confirm scope (scope_parser.py), "
                   "then run passive first; active/content need authorization.")
    return out


def main(argv):
    ap = argparse.ArgumentParser(description="Generate a recon plan for a domain.")
    ap.add_argument("domain")
    ap.add_argument("--active", action="store_true", help="include active phases")
    ap.add_argument("--phase", choices=list(PHASES), help="only this phase")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv[1:])

    if not valid_domain(args.domain):
        print(f"✗ not a bare domain: {args.domain!r} (use example.com, not a URL)", file=sys.stderr)
        return 1

    if args.phase:
        phases = [args.phase]
    elif args.active:
        phases = ["passive", "active", "content", "analysis"]
    else:
        phases = ["passive"]

    p = plan(args.domain, phases)
    if args.json:
        print(json.dumps(p, indent=2)); return 0

    print(f"🗺️  Recon plan — {p['target']}\n")
    for ph in p["phases"]:
        print(f"── {ph['phase'].upper()}: {ph['title']}")
        for c in ph["commands"]:
            print(f"   [{c['tool']}] {c['cmd']}")
        print()
    print("Likely next skills once you see the surface:")
    for sig, sk in p["next_skills"]:
        print(f"   • {sig:<28} → {sk}")
    print(f"\n⚠️  {p['note']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
