import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import skill_router as R  # noqa: E402


class SkillRouterTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.table = R.parse_table()

    # ---- parsing ----
    def test_table_parses_many_skills(self):
        self.assertGreater(len(self.table), 40)

    def test_known_skills_present(self):
        names = {s.skill for s in self.table}
        for n in ("monetization", "infra-deploy", "web3-ops", "bots-automation"):
            self.assertIn(n, names)

    def test_weights_loaded(self):
        infra = next(s for s in self.table if s.skill == "infra-deploy")
        self.assertIn("vps", infra.high)

    # ---- scoring ----
    def test_high_keyword_scores_3(self):
        res = R.route("deploy", self.table)
        self.assertEqual(res["primary"]["skill"], "infra-deploy")
        self.assertGreaterEqual(res["primary"]["score"], 3)

    def test_multiword_keyword_matches(self):
        res = R.route("set up a telegram bot", self.table)
        self.assertEqual(res["primary"]["skill"], "bots-automation")

    def test_documented_orchestration_example(self):
        # the exact example from AGENTS.md multi-skill orchestration
        res = R.route("bikin telegram bot yang ambil data airdrop dari API terus auto-post",
                      self.table)
        self.assertEqual(res["primary"]["skill"], "bots-automation")
        sup = {s["skill"] for s in res["supporting"]}
        self.assertTrue({"api-integration", "web3-ops"} & sup)

    def test_vps_deploy_nginx_stacks_score(self):
        res = R.route("deploy nginx on my VPS", self.table)
        self.assertEqual(res["primary"]["skill"], "infra-deploy")
        self.assertGreaterEqual(res["primary"]["score"], 9)  # vps+deploy+nginx = 3+3+3

    # ---- no-match ----
    def test_no_match_returns_none(self):
        res = R.route("xyzzy qwerty foobar nonsense", self.table)
        self.assertIsNone(res["primary"])
        self.assertIn("no keyword match", res["note"])

    # ---- supporting threshold ----
    def test_supporting_above_half_of_primary(self):
        res = R.route("bikin telegram bot ambil airdrop dari API", self.table)
        if res["supporting"]:
            top = res["primary"]["score"]
            for s in res["supporting"]:
                self.assertGreaterEqual(s["score"], top * 0.5)

    # ---- determinism ----
    def test_deterministic(self):
        a = R.route("deploy nginx VPS", self.table)
        b = R.route("deploy nginx VPS", self.table)
        self.assertEqual(a["primary"], b["primary"])

    # ---- json serializable ----
    def test_route_is_json_serializable(self):
        import json
        json.dumps(R.route("audit security vulnerability", self.table))


    # ---- security playbook routing (granular) ----
    def test_security_rows_parsed(self):
        names = {s.skill for s in self.table}
        self.assertGreaterEqual(len([n for n in names if n.startswith("sec:")]), 40)

    def test_routes_specific_vulns_to_playbooks(self):
        cases = {
            "graphql introspection bola": "sec:api/graphql",
            "idor on orders endpoint": "sec:web/idor",
            "xxe in soap xml": "sec:web/xxe",
            "lfi path traversal": "sec:web/lfi",
            "oauth redirect_uri takeover": "sec:auth/oauth",
            "saml signature wrapping": "sec:auth/saml",
            "subdomain takeover": "sec:recon/takeover",
            "rop chain exploit": "sec:exploit/rop-chains",
            "s3 bucket misconfig": "sec:cloud/cloud-misconfig",
            "kubernetes exposed kubelet": "sec:cloud/container-k8s",
            "token rug pull honeypot": "sec:web3/token-scan",
        }
        for q, want in cases.items():
            res = R.route(q, self.table)
            self.assertIsNotNone(res["primary"], f"no match for {q!r}")
            self.assertEqual(res["primary"]["skill"], want, f"{q!r} -> {res['primary']['skill']}")

    def test_tiebreak_prefers_security_playbook(self):
        # "ssrf via webhook": webhook ties bots-automation vs sec:web/ssrf -> sec wins
        res = R.route("ssrf via webhook", self.table)
        self.assertEqual(res["primary"]["skill"], "sec:web/ssrf")
        # "smart contract reentrancy audit": audit ties -> specific audit playbook wins
        res2 = R.route("smart contract reentrancy audit", self.table)
        self.assertEqual(res2["primary"]["skill"], "sec:web3/smart-contract-audit")

    def test_general_routing_not_regressed(self):
        self.assertEqual(R.route("deploy nginx VPS", self.table)["primary"]["skill"], "infra-deploy")
        self.assertEqual(R.route("write viral thread", self.table)["primary"]["skill"], "content-creation")


if __name__ == "__main__":
    unittest.main()
