import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import scope_parser as S  # noqa: E402


class ScopeParserTest(unittest.TestCase):
    def test_in_scope_wildcard(self):
        r = S.verdict("api.example.com", ["*.example.com"], [])
        self.assertEqual(r["verdict"], "IN")

    def test_exact_in_scope(self):
        r = S.verdict("example.com", ["example.com"], [])
        self.assertEqual(r["verdict"], "IN")

    def test_out_scope_wins(self):
        r = S.verdict("blog.example.com", ["*.example.com"], ["blog.example.com"])
        self.assertEqual(r["verdict"], "OUT")

    def test_unknown_when_no_match(self):
        r = S.verdict("evil.com", ["*.example.com"], [])
        self.assertEqual(r["verdict"], "UNKNOWN")

    def test_out_wildcard(self):
        r = S.verdict("x.dev.example.com", ["*.example.com"], ["*.dev.example.com"])
        self.assertEqual(r["verdict"], "OUT")

    def test_host_extraction_from_url(self):
        self.assertEqual(S._host("https://api.example.com/path?q=1"), "api.example.com")

    def test_host_strips_port(self):
        self.assertEqual(S._host("api.example.com:8443"), "api.example.com")

    def test_host_strips_userinfo(self):
        self.assertEqual(S._host("https://user@api.example.com/"), "api.example.com")

    def test_url_target_in_scope(self):
        r = S.verdict("https://api.example.com/orders", ["*.example.com"], [])
        self.assertEqual(r["verdict"], "IN")

    def test_case_insensitive(self):
        r = S.verdict("API.Example.COM", ["*.example.com"], [])
        self.assertEqual(r["verdict"], "IN")

    def test_note_warns_confirm(self):
        r = S.verdict("api.example.com", ["*.example.com"], [])
        self.assertIn("confirm", r["note"].lower())

    def test_json_serializable(self):
        import json
        json.dumps(S.verdict("api.example.com", ["*.example.com"], ["x.example.com"]))


if __name__ == "__main__":
    unittest.main()
