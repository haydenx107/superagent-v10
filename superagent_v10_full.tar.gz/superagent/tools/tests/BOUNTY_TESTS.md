bounty tests: test_bounty_discovery.py (10), test_bounty_gate.py (17)
