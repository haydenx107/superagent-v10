import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import selfcheck as S  # noqa: E402


class SelfcheckTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = S.run()

    def test_report_has_counts_and_checks(self):
        self.assertIn("counts", self.report)
        self.assertIn("checks", self.report)
        self.assertIn("healthy", self.report)

    def test_skill_count_is_124(self):
        self.assertEqual(self.report["counts"]["skills_total"], 158)

    def test_general_and_security_split(self):
        c = self.report["counts"]
        self.assertEqual(c["skills_general"], 50)
        self.assertEqual(c["skills_security"], 108)

    def test_twelve_category_folders(self):
        self.assertEqual(self.report["counts"]["category_folders"], 12)

    def test_integrity_ok(self):
        self.assertTrue(self.report["checks"]["integrity"]["ok"])

    def test_no_broken_links(self):
        self.assertTrue(self.report["checks"]["links"]["ok"],
                        f"broken: {self.report['checks']['links']['detail'][:5]}")

    def test_router_check_ok(self):
        self.assertTrue(self.report["checks"]["router"]["ok"])

    def test_engine_check_ok(self):
        self.assertTrue(self.report["checks"]["engine"]["ok"])

    def test_overall_healthy(self):
        self.assertTrue(self.report["healthy"])

    def test_report_json_serializable(self):
        import json
        json.dumps(self.report, default=str)


if __name__ == "__main__":
    unittest.main()


class SelfcheckDocCountsTest(unittest.TestCase):
    def setUp(self):
        import selfcheck
        self.S = selfcheck

    def test_doc_counts_check_exists_and_passes(self):
        ok, detail = self.S.check_docs_counts()
        self.assertTrue(ok, f"doc drift detected: {detail}")

    def test_doc_counts_in_report(self):
        rep = self.S.run()
        self.assertIn("doc_counts", rep["checks"])

    def test_doc_counts_detects_stale(self):
        # monkeypatch the real counts so current docs look 'stale'
        import selfcheck as S
        orig = S._count_skills
        S._count_skills = lambda: (999, 999)   # pretend reality is 999/999
        try:
            ok, detail = S.check_docs_counts()
            self.assertFalse(ok)              # now the real doc numbers are 'wrong'
            self.assertIsInstance(detail, list)
            self.assertGreater(len(detail), 0)
        finally:
            S._count_skills = orig
