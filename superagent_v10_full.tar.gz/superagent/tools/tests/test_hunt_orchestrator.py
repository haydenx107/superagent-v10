import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import hunt_orchestrator as H  # noqa: E402
import bounty_gate as BG       # noqa: E402


class HuntOrchestratorTest(unittest.TestCase):
    def _field(self, **kw):
        base = dict(id="t:x", name="X", scope_assets=["x.example"],
                    invites_testing=True, pays_bounty=True, freshness_days=5,
                    competition="low")
        base.update(kw)
        return base

    # ---- plan mapping ----
    def test_plan_includes_baseline(self):
        plan = H.plan_for_field(self._field())
        self.assertTrue(any("recon/subdomain.md" in p for p in plan["playbooks"]))
        self.assertTrue(any("web/idor.md" in p for p in plan["playbooks"]))

    def test_graphql_surface_adds_graphql_skill(self):
        plan = H.plan_for_field(self._field(name="GraphQL API",
                                            scope_assets=["api.x.example", "graphql"]))
        self.assertTrue(any("api/graphql.md" in p for p in plan["playbooks"]))

    def test_web3_surface_adds_contract_skill(self):
        plan = H.plan_for_field(self._field(name="DeFi contract",
                                            scope_assets=["contract.x.example"]))
        self.assertTrue(any("web3/smart-contract-audit.md" in p for p in plan["playbooks"]))

    def test_playbook_paths_are_under_security_domain(self):
        plan = H.plan_for_field(self._field())
        for p in plan["playbooks"]:
            self.assertTrue(p.startswith("skills/09-security/"))

    def test_no_duplicate_playbooks(self):
        plan = H.plan_for_field(self._field(name="api graphql", scope_assets=["api", "graphql"]))
        self.assertEqual(len(plan["playbooks"]), len(set(plan["playbooks"])))

    # ---- full run ----
    def test_run_auto_authorizes_clean_field(self):
        rep = H.run([self._field(id="t:ok", scope_assets=["*.x.example", "api.x.example", "graphql"])],
                    gate_mode="auto", min_score=1)
        self.assertEqual(rep["stages"]["authorized"], 1)
        self.assertEqual(rep["stages"]["rejected"], 0)
        self.assertIn("hunt_plan", rep["authorized"][0])

    def test_run_strict_sends_to_confirm_not_authorized(self):
        rep = H.run([self._field(id="t:s", scope_assets=["*.x.example", "api.x.example"])],
                    gate_mode="strict", min_score=1)
        self.assertEqual(rep["stages"]["authorized"], 0)
        self.assertGreaterEqual(rep["stages"]["needs_confirm"], 1)

    def test_run_rejects_private_field(self):
        f = self._field(id="t:priv", invites_testing=False)
        rep = H.run([f], gate_mode="auto", min_score=1)
        # invites_testing False -> dropped at qualify OR rejected at gate; never authorized
        self.assertEqual(rep["stages"]["authorized"], 0)

    def test_run_never_authorizes_without_scope(self):
        f = self._field(id="t:noscope", scope_assets=[])
        rep = H.run([f], gate_mode="auto", min_score=1)
        self.assertEqual(rep["stages"]["authorized"], 0)

    def test_report_carries_safety_note_and_no_contact(self):
        rep = H.run([self._field()], gate_mode="auto", min_score=1)
        self.assertIn("No target was contacted", rep["note"])

    # ---- safety invariant ----
    def test_authorized_entries_are_only_PASS(self):
        rep = H.run([self._field(id="t:a", scope_assets=["*.x.example", "api.x.example", "graphql"])],
                    gate_mode="auto", min_score=1)
        for a in rep["authorized"]:
            self.assertEqual(a["decision"], BG.PASS)

    def test_demo_runs_and_is_json_serializable(self):
        import json
        rep = H.run(H._demo_fields(), gate_mode="auto")
        json.dumps(rep)  # must not raise
        self.assertIn("stages", rep)


if __name__ == "__main__":
    unittest.main()
