import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import report_builder as R  # noqa: E402


class ReportBuilderTest(unittest.TestCase):
    def test_build_structure(self):
        r = R.build("idor", "api.example.com", "1. x", "impact here")
        for k in ("title", "class", "cwe", "cvss", "severity", "remediation", "markdown"):
            self.assertIn(k, r)

    def test_cvss_and_cwe_for_known_class(self):
        r = R.build("sqli", "example.com", "", "")
        self.assertEqual(r["cwe"], "CWE-89")
        self.assertEqual(r["severity"], "Critical")
        self.assertTrue(r["cvss"].startswith("CVSS:3.1/"))

    def test_markdown_has_all_sections(self):
        md = R.build("xss", "example.com", "steps", "impact")["markdown"]
        for sec in ("## Summary", "## Severity", "## Affected Asset",
                    "## Steps to Reproduce", "## Proof of Concept", "## Impact",
                    "## Remediation", "## References"):
            self.assertIn(sec, md)

    def test_unknown_class_falls_back(self):
        r = R.build("totally-unknown", "x", "", "")
        self.assertEqual(r["cwe"], "CWE-Unknown")
        self.assertIn("## Summary", r["markdown"])

    def test_new_classes_covered(self):
        # the 4 new skill classes should have report metadata
        for cls in ("ssl-tls", "websocket"):
            r = R.build(cls, "example.com", "", "")
            self.assertNotEqual(r["cwe"], "CWE-Unknown", f"{cls} missing meta")

    def test_steps_rendered(self):
        md = R.build("idor", "x", "1. first\n2. second", "")["markdown"]
        self.assertIn("1. first", md)
        self.assertIn("2. second", md)

    def test_title_override(self):
        r = R.build("idor", "x", "", "", title="Custom Title")
        self.assertEqual(r["title"], "Custom Title")
        self.assertIn("# Custom Title", r["markdown"])

    def test_platform_in_footer(self):
        md = R.build("idor", "x", "", "", platform="Bugcrowd")["markdown"]
        self.assertIn("Bugcrowd", md)

    def test_cwe_reference_link(self):
        md = R.build("sqli", "x", "", "")["markdown"]
        self.assertIn("89.html", md)

    def test_json_serializable(self):
        import json
        json.dumps(R.build("ssrf", "x", "s", "i"))

    def test_all_class_meta_valid_vectors(self):
        for cls, (cwe, vec, band, rem) in R.CLASS_META.items():
            self.assertTrue(vec.startswith("AV:"), f"{cls} bad vector")
            self.assertIn(band, R.BAND_SCORE)


if __name__ == "__main__":
    unittest.main()
