import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import cost_estimator as C  # noqa: E402


class CostEstimatorTest(unittest.TestCase):
    def test_est_tokens_reasonable(self):
        self.assertEqual(C.est_tokens("abcd"), 1)      # 4 chars → 1 token
        self.assertGreaterEqual(C.est_tokens("a" * 40), 10)

    def test_estimate_structure(self):
        r = C.estimate("deploy nginx VPS")
        for k in ("prompt", "skills_loaded", "tokens", "cost_usd"):
            self.assertIn(k, r)
        for k in ("boot", "skills", "prompt", "input_total", "output_est", "grand_total"):
            self.assertIn(k, r["tokens"])

    def test_boot_tokens_included(self):
        r = C.estimate("hello")
        self.assertGreaterEqual(r["tokens"]["input_total"], C.BOOT_TOKENS)

    def test_router_counts_skills(self):
        r = C.estimate("audit this smart contract for reentrancy")
        self.assertGreaterEqual(r["skills_loaded"], 1)
        # grand total = input + output
        self.assertEqual(r["tokens"]["grand_total"],
                         r["tokens"]["input_total"] + r["tokens"]["output_est"])

    def test_cost_table_all_providers(self):
        r = C.estimate("write a thread")
        for model in C.PRICES:
            self.assertIn(model, r["cost_usd"])

    def test_local_is_free(self):
        r = C.estimate("anything")
        self.assertEqual(r["cost_usd"]["ollama-local"], 0.0)

    def test_cost_sorted_cheapest_first(self):
        r = C.estimate("test prompt here")
        vals = list(r["cost_usd"].values())
        self.assertEqual(vals, sorted(vals))

    def test_more_skills_costs_more(self):
        one = C.estimate("hello", response_tokens=500)
        # a multi-skill security prompt loads >= as many skills
        multi = C.estimate("audit smart contract reentrancy", response_tokens=500)
        self.assertGreaterEqual(multi["skills_loaded"], one["skills_loaded"])

    def test_response_tokens_affects_output(self):
        a = C.estimate("x", response_tokens=500)
        b = C.estimate("x", response_tokens=2000)
        self.assertLess(a["tokens"]["output_est"], b["tokens"]["output_est"])

    def test_json_serializable(self):
        import json
        json.dumps(C.estimate("deploy a bot"))


if __name__ == "__main__":
    unittest.main()


class CostEstimatorEdgeTest(unittest.TestCase):
    def test_negative_response_tokens_clamped(self):
        r = C.estimate("x", response_tokens=-100)
        self.assertEqual(r["tokens"]["output_est"], 0)
        self.assertGreaterEqual(r["tokens"]["grand_total"], 0)
