import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import recon_engine as R  # noqa: E402


class ReconEngineTest(unittest.TestCase):
    def test_valid_domain(self):
        self.assertTrue(R.valid_domain("example.com"))
        self.assertTrue(R.valid_domain("api.sub.example.co.uk"))

    def test_invalid_domain_rejected(self):
        self.assertFalse(R.valid_domain("https://example.com"))
        self.assertFalse(R.valid_domain("example.com/path"))
        self.assertFalse(R.valid_domain("not a domain"))
        self.assertFalse(R.valid_domain(""))

    def test_passive_only_default(self):
        p = R.plan("example.com", ["passive"])
        self.assertEqual(len(p["phases"]), 1)
        self.assertEqual(p["phases"][0]["phase"], "passive")

    def test_all_phases(self):
        p = R.plan("example.com", ["passive", "active", "content", "analysis"])
        self.assertEqual(len(p["phases"]), 4)

    def test_domain_interpolated_in_commands(self):
        p = R.plan("acme.io", ["passive"])
        cmds = " ".join(c["cmd"] for c in p["phases"][0]["commands"])
        self.assertIn("acme.io", cmds)
        self.assertNotIn("{d}", cmds)

    def test_skill_hints_present(self):
        p = R.plan("example.com", ["passive"])
        self.assertTrue(len(p["next_skills"]) >= 5)
        flat = " ".join(sk for _, sk in p["next_skills"])
        self.assertIn("sec:", flat)

    def test_note_warns_plan_only(self):
        p = R.plan("example.com", ["passive"])
        self.assertIn("Plan only", p["note"])

    def test_all_phase_keys_valid(self):
        for ph in ("passive", "active", "content", "analysis"):
            self.assertIn(ph, R.PHASES)
            self.assertTrue(len(R.PHASES[ph]["cmds"]) > 0)

    def test_json_serializable(self):
        import json
        json.dumps(R.plan("example.com", ["passive", "active"]))

    def test_new_skill_hints_included(self):
        # websocket + ssl-tls should appear in hints (new skills)
        flat = " ".join(sk for _, sk in R.SKILL_HINTS)
        self.assertIn("websocket", flat)
        self.assertIn("ssl-tls", flat)


if __name__ == "__main__":
    unittest.main()
