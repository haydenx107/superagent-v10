import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import bounty_gate as G  # noqa: E402


class BountyGateTest(unittest.TestCase):
    def _gi(self, **kw):
        base = dict(id="g:x", invites_testing=True,
                    scope_assets=["*.acme.example"],
                    intended_asset="api.acme.example",
                    intended_technique="idor",
                    roe_allows_automation=True)
        base.update(kw)
        return G.GateInput(**base)

    # ---- PASS ----
    def test_clean_auto_mode_passes(self):
        r = G.evaluate(self._gi(gate_mode="auto"))
        self.assertEqual(r["decision"], G.PASS)

    # ---- strict forces confirm ----
    def test_clean_strict_mode_requires_confirm(self):
        r = G.evaluate(self._gi(gate_mode="strict"))
        self.assertEqual(r["decision"], G.CONFIRM)

    # ---- FAIL conditions ----
    def test_no_invitation_fails(self):
        r = G.evaluate(self._gi(invites_testing=False, gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_private_program_fails(self):
        r = G.evaluate(self._gi(private_or_invite_only=True, gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_login_wall_fails(self):
        r = G.evaluate(self._gi(login_required_for_policy=True, gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_takedown_notice_fails(self):
        r = G.evaluate(self._gi(takedown_or_stop_notice=True, gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_asset_out_of_scope_fails(self):
        r = G.evaluate(self._gi(intended_asset="evil.example", gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_asset_not_in_scope_fails(self):
        r = G.evaluate(self._gi(scope_assets=["only.other.example"],
                                intended_asset="api.acme.example", gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_explicit_out_of_scope_list_fails(self):
        r = G.evaluate(self._gi(out_of_scope=["api.acme.example"], gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_excluded_technique_fails(self):
        r = G.evaluate(self._gi(excluded_tests=["idor"], gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_automation_forbidden_fails(self):
        r = G.evaluate(self._gi(roe_allows_automation=False, gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_no_scope_fails(self):
        r = G.evaluate(self._gi(scope_assets=[], gate_mode="auto"))
        self.assertEqual(r["decision"], G.FAIL)

    def test_paused_mode_fails(self):
        r = G.evaluate(self._gi(gate_mode="paused"))
        self.assertEqual(r["decision"], G.FAIL)

    # ---- ambiguity -> human-confirm, never silent pass ----
    def test_unknown_invitation_confirms_not_pass(self):
        r = G.evaluate(self._gi(invites_testing=None, gate_mode="auto"))
        self.assertEqual(r["decision"], G.CONFIRM)

    def test_unknown_automation_confirms_not_pass(self):
        r = G.evaluate(self._gi(roe_allows_automation=None, gate_mode="auto"))
        self.assertEqual(r["decision"], G.CONFIRM)

    # ---- wildcard scope matching ----
    def test_wildcard_subdomain_in_scope(self):
        self.assertTrue(G._asset_in_scope("api.acme.example", ["*.acme.example"]))
        self.assertTrue(G._asset_in_scope("acme.example", ["*.acme.example"]))
        self.assertFalse(G._asset_in_scope("acme.evil.example", ["*.acme.example"]))

    # ---- safety invariant: a non-PASS field must never read as authorized ----
    def test_demo_has_pass_confirm_fail(self):
        results = [G.evaluate(g) for g in G._demo()]
        decisions = {r["decision"] for r in results}
        self.assertIn(G.PASS, decisions)
        self.assertIn(G.CONFIRM, decisions)
        self.assertIn(G.FAIL, decisions)


if __name__ == "__main__":
    unittest.main()
