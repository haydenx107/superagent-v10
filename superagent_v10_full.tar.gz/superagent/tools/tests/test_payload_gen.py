import pathlib
import sys
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import payload_gen as P  # noqa: E402


class PayloadGenTest(unittest.TestCase):
    def test_all_classes_generate(self):
        for cls in P.CLASSES:
            r = P.generate(cls, [])
            self.assertGreater(r["count"], 0, f"{cls} empty")
            self.assertEqual(r["class"], cls)

    def test_unknown_class_raises(self):
        with self.assertRaises(KeyError):
            P.generate("nope", [])

    def test_encoders_produce_variants(self):
        r = P.generate("xss", ["url", "base64"])
        self.assertIn("encoded", r)
        self.assertIn("url", r["encoded"])
        self.assertIn("base64", r["encoded"])
        self.assertEqual(len(r["encoded"]["url"]), r["count"])

    def test_unknown_encoder_raises(self):
        with self.assertRaises(ValueError):
            P.generate("xss", ["rot13-nope"])

    def test_url_encoder_escapes(self):
        enc = P.ENCODERS["url"]("a b/c")
        self.assertNotIn(" ", enc)
        self.assertNotIn("/", enc)

    def test_base64_roundtrip(self):
        import base64
        enc = P.ENCODERS["base64"]("hello")
        self.assertEqual(base64.b64decode(enc).decode(), "hello")

    def test_pulls_from_pack_payload_file_when_present(self):
        # ssrf.txt exists in the pack → should have several real payloads
        r = P.generate("ssrf", [])
        self.assertGreaterEqual(r["count"], 3)

    def test_fallback_for_no_file_class(self):
        # cmdi has no file → uses fallback list
        r = P.generate("cmdi", [])
        self.assertGreater(r["count"], 0)

    def test_note_present(self):
        self.assertIn("Authorized", P.generate("sqli", [])["note"])

    def test_json_serializable(self):
        import json
        json.dumps(P.generate("ssti", ["html", "case"]))


if __name__ == "__main__":
    unittest.main()


class PayloadGenNewClassesTest(unittest.TestCase):
    def test_new_classes_present(self):
        for cls in ("nosql", "crlf", "ldap", "xpath", "prototype"):
            self.assertIn(cls, P.CLASSES)

    def test_new_classes_generate(self):
        for cls in ("nosql", "crlf", "ldap", "xpath", "prototype"):
            r = P.generate(cls, [])
            self.assertGreater(r["count"], 0, f"{cls} empty")

    def test_nosql_has_operator_payload(self):
        payloads = " ".join(P.generate("nosql", [])["payloads"])
        self.assertIn("$ne", payloads)

    def test_prototype_has_proto(self):
        payloads = " ".join(P.generate("prototype", [])["payloads"])
        self.assertIn("__proto__", payloads)
