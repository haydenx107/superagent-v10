#!/usr/bin/env python3
"""
tools/workflow_runner.py — Multi-skill workflow runner (runnable)
(V10 — shows skills collaborating, not just existing)

Workflows are named recipes that chain multiple skills into a repeatable
pipeline (e.g. "idea → PRD → code → deploy", or "recon → hunt → report").
This runner lists them, prints a step-by-step plan, and VALIDATES that every
skill a workflow references actually exists in the pack — so a recipe can never
point to a missing skill.

It plans; it doesn't execute (the AI agent executes each step). Deterministic,
offline, zero deps.

Usage:
    python3 workflow_runner.py list
    python3 workflow_runner.py show bug-bounty
    python3 workflow_runner.py validate          # check all workflows resolve
    python3 workflow_runner.py plan ship-product --json
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
WF_FILE = ROOT / "workflows" / "workflows.json"
SKILLS = ROOT / "skills"


class WorkflowError(Exception):
    pass


def load():
    try:
        return json.loads(WF_FILE.read_text())["workflows"]
    except FileNotFoundError:
        raise WorkflowError(f"workflows file not found: {WF_FILE}")
    except json.JSONDecodeError as e:
        raise WorkflowError(f"workflows.json is invalid JSON: {e}")
    except KeyError:
        raise WorkflowError("workflows.json missing top-level 'workflows' key")


def skill_path(skill: str) -> pathlib.Path:
    """Resolve a workflow skill ref to a file path.
    'sec:web/idor' → skills/09-security/web/idor.md
    'monetization' → skills/<NN-cat>/monetization.md (searched)
    """
    if skill.startswith("sec:"):
        sub = skill[4:]  # e.g. web/idor or core/scope-guard
        return SKILLS / "09-security" / f"{sub}.md"
    hits = list(SKILLS.glob(f"[0-9][0-9]-*/{skill}.md"))
    return hits[0] if hits else SKILLS / "__missing__" / f"{skill}.md"


def validate_all():
    wfs = load()
    problems = []
    for name, wf in wfs.items():
        for step in wf["steps"]:
            p = skill_path(step["skill"])
            if not p.is_file():
                problems.append(f"{name}: missing skill '{step['skill']}' ({p.relative_to(ROOT) if ROOT in p.parents else p})")
    return problems


def plan(name):
    wfs = load()
    if name not in wfs:
        raise KeyError(name)
    wf = wfs[name]
    steps = []
    for i, step in enumerate(wf["steps"], 1):
        p = skill_path(step["skill"])
        steps.append({
            "n": i, "skill": step["skill"], "do": step["do"],
            "path": str(p.relative_to(ROOT)) if p.is_file() else None,
            "exists": p.is_file(),
        })
    return {"name": name, "title": wf["title"], "description": wf["description"],
            "steps": steps, "all_resolve": all(s["exists"] for s in steps)}


def main(argv):
    ap = argparse.ArgumentParser(description="Run (plan) multi-skill workflows.")
    ap.add_argument("cmd", choices=["list", "show", "plan", "validate"])
    ap.add_argument("name", nargs="?")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv[1:])

    try:
        load()  # validate the workflows file up front
    except WorkflowError as e:
        print(f"✗ {e}")
        return 1

    if args.cmd == "list":
        wfs = load()
        if args.json:
            print(json.dumps({k: v["title"] for k, v in wfs.items()}, indent=2)); return 0
        print("Available workflows:")
        for k, v in wfs.items():
            print(f"  {k:<16} {v['title']}  ({len(v['steps'])} steps)")
        print("\nRun: python3 workflow_runner.py show <name>")
        return 0

    if args.cmd == "validate":
        problems = validate_all()
        if args.json:
            print(json.dumps({"ok": not problems, "problems": problems}, indent=2))
        else:
            if problems:
                print("✗ problems:")
                for p in problems: print("  -", p)
            else:
                print(f"✓ all {len(load())} workflows resolve — every skill exists.")
        return 0 if not problems else 1

    if args.cmd in ("show", "plan"):
        if not args.name:
            print("name required"); return 1
        try:
            pl = plan(args.name)
        except KeyError:
            print(f"unknown workflow: {args.name}"); return 1
        if args.json:
            print(json.dumps(pl, indent=2)); return 0
        print(f"🔗 {pl['title']}  ({args.name})")
        print(f"   {pl['description']}\n")
        for s in pl["steps"]:
            mark = "✓" if s["exists"] else "✗"
            print(f"   {s['n']}. [{mark}] {s['skill']:<32} — {s['do']}")
        print(f"\n   all steps resolve: {'yes ✓' if pl['all_resolve'] else 'NO ✗'}")
        print("   (the agent executes each step in order; this is the plan)")
        return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
