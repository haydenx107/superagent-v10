#!/usr/bin/env python3
"""
tools/cve_mapper.py — Technology → known-CVE mapper (runnable)
(V10 bug-bounty — a fingerprinted tech stack suggests which CVEs to check)

Given a technology (and optional version) seen during recon, returns a curated
set of well-known, high-impact CVEs to check, each with a class and a one-line
hint. Offline knowledge base of famous CVEs — a starting checklist, not a
vulnerability scanner.

⚠️ Authorized testing only. Confirm the actual version and exploitability; many
targets are patched. This points you at *what to verify*, not proof of a bug.

Zero external deps (stdlib). Usage:
    python3 cve_mapper.py list
    python3 cve_mapper.py apache
    python3 cve_mapper.py log4j --json
    python3 cve_mapper.py confluence
"""
from __future__ import annotations

import argparse
import json
import sys

# tech -> list of (cve, title, class, hint)
KB = {
    "log4j": [
        ("CVE-2021-44228", "Log4Shell", "rce", "JNDI lookup in logged input: ${jndi:ldap://collab/x}"),
        ("CVE-2021-45046", "Log4j follow-up", "rce", "Incomplete fix; context map lookups."),
    ],
    "apache": [
        ("CVE-2021-41773", "Apache 2.4.49 path traversal", "lfi", "/cgi-bin/.%2e/..%2e → file read / RCE if cgi."),
        ("CVE-2021-42013", "2.4.50 traversal bypass", "lfi", "Double-encoded %%32%65 bypass of the 41773 fix."),
    ],
    "struts": [
        ("CVE-2017-5638", "Struts2 OGNL (Equifax)", "rce", "Content-Type header OGNL injection → RCE."),
        ("CVE-2018-11776", "Struts2 namespace OGNL", "rce", "Crafted namespace → OGNL eval."),
    ],
    "confluence": [
        ("CVE-2022-26134", "Confluence OGNL", "rce", "OGNL in URL path → unauth RCE."),
        ("CVE-2023-22515", "Confluence broken access", "account-takeover", "Create admin via setup endpoint."),
    ],
    "spring": [
        ("CVE-2022-22965", "Spring4Shell", "rce", "classLoader data-binding → webshell on Tomcat."),
        ("CVE-2022-22963", "Spring Cloud Function SpEL", "rce", "spring.cloud.function.routing-expression header."),
    ],
    "jenkins": [
        ("CVE-2024-23897", "Jenkins CLI arg file read", "lfi", "@/etc/passwd via CLI arg expansion."),
        ("CVE-2018-1000861", "Jenkins Stapler RCE", "rce", "Unauth RCE via crafted URL routing."),
    ],
    "gitlab": [
        ("CVE-2021-22205", "GitLab ExifTool RCE", "rce", "Unauth image upload → DjVu → RCE."),
    ],
    "citrix": [
        ("CVE-2019-19781", "Citrix ADC path traversal", "lfi", "/vpn/../vpns/ template → RCE."),
        ("CVE-2023-4966", "Citrix Bleed", "session", "Session token leak via buffer over-read."),
    ],
    "fortinet": [
        ("CVE-2018-13379", "FortiOS SSL-VPN traversal", "lfi", "Pre-auth read of sslvpn_websession creds."),
    ],
    "wordpress": [
        ("CVE-2022-21661", "WP WP_Query SQLi", "sqli", "Blind SQLi via crafted query vars."),
        ("generic", "WP plugin sprawl", "mixed", "Enumerate plugins/versions; check wpscan DB."),
    ],
    "drupal": [
        ("CVE-2018-7600", "Drupalgeddon2", "rce", "Form API render array → RCE, unauth."),
    ],
    "exchange": [
        ("CVE-2021-26855", "ProxyLogon SSRF", "ssrf", "SSRF → auth bypass chain to RCE."),
        ("CVE-2021-34473", "ProxyShell", "rce", "Autodiscover path confusion → RCE."),
    ],
    "vmware": [
        ("CVE-2021-21972", "vCenter vSphere upload", "rce", "Unauth file upload → webshell."),
    ],
    "f5": [
        ("CVE-2020-5902", "F5 BIG-IP TMUI RCE", "rce", "/tmui/..;/ path → unauth RCE."),
        ("CVE-2022-1388", "F5 iControl auth bypass", "rce", "X-F5-Auth-Token bypass → command exec."),
    ],
    "openssl": [
        ("CVE-2014-0160", "Heartbleed", "ssl-tls", "TLS heartbeat over-read → memory/key leak."),
    ],
    "php": [
        ("CVE-2019-11043", "PHP-FPM + nginx RCE", "rce", "Misconfig path_info → remote code exec."),
    ],
}

ALIASES = {
    "log4shell": "log4j", "spring4shell": "spring", "proxylogon": "exchange",
    "proxyshell": "exchange", "bigip": "f5", "big-ip": "f5", "wp": "wordpress",
    "heartbleed": "openssl",
}


def lookup(tech: str) -> dict:
    t = tech.strip().lower()
    t = ALIASES.get(t, t)
    entries = KB.get(t)
    if not entries:
        # fuzzy: substring match on keys
        for k in KB:
            if k in t or t in k:
                entries = KB[k]; t = k; break
    if not entries:
        return {"tech": tech, "found": False, "cves": [],
                "note": "No curated CVEs for that tech. Check version against NVD/ExploitDB manually."}
    return {
        "tech": t, "found": True, "count": len(entries),
        "cves": [{"cve": c, "title": ti, "class": cl, "hint": h} for c, ti, cl, h in entries],
        "note": "Confirm the running version — many targets are patched. Authorized testing only.",
    }


def main(argv):
    ap = argparse.ArgumentParser(description="Map a technology to known CVEs to check.")
    ap.add_argument("tech", nargs="?", help="technology name, or 'list'")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv[1:])

    if not args.tech or args.tech == "list":
        print("Known technologies:", ", ".join(sorted(KB)))
        print("Aliases:", ", ".join(sorted(ALIASES)))
        return 0

    r = lookup(args.tech)
    if args.json:
        print(json.dumps(r, indent=2)); return 0
    if not r["found"]:
        print(f"🟡 {r['note']}"); return 0
    print(f"🔎 {r['tech']} — {r['count']} CVE(s) to check:")
    for c in r["cves"]:
        print(f"   {c['cve']:<18} [{c['class']:<16}] {c['title']}")
        print(f"      → {c['hint']}")
    print(f"\n⚠️  {r['note']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
