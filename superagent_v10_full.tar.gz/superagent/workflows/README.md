# 🔗 workflows/ — multi-skill recipes

Named pipelines that chain several skills into one repeatable flow — showing that SUPERAGENT's skills **collaborate**, not just coexist.

| Workflow | Does | Steps |
|----------|------|:-----:|
| `ship-product` | Idea → PRD → architecture → code → UI → deploy → CI/CD | 6 |
| `content-machine` | Research → strategy → write → hooks → repurpose → video | 6 |
| `bug-bounty` | Scope → recon → hunt → chain → PoC → validate → report (gated) | 9 |
| `airdrop-farm` | Discover → verify → farm → ROI → exit plan | 6 |
| `launch-money` | Price → copy → landing → outreach → P&L | 5 |

## Run (plan) a workflow
```bash
python3 tools/workflow_runner.py list              # see all
python3 tools/workflow_runner.py show bug-bounty   # step-by-step plan
python3 tools/workflow_runner.py validate          # verify every skill exists
```

The runner **plans**; the AI agent executes each step in order. Every workflow is validated so it can never reference a missing skill. Add your own in `workflows.json`.
